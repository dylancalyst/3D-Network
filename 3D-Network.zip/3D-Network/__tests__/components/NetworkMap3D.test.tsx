import React from 'react'
import { render, screen } from '@testing-library/react'
import '@testing-library/jest-dom'
import NetworkMap3D from '@/components/NetworkMap3D'

// Mock the fetch function
global.fetch = jest.fn(() =>
  Promise.resolve({
    json: () => Promise.resolve({ nodes: [], links: [] }),
  })
) as jest.Mock;

describe('NetworkMap3D', () => {
  it('renders loading state initially', () => {
    render(<NetworkMap3D />)
    expect(screen.getByText('Loading...')).toBeInTheDocument()
  })

  // Add more tests as needed
})

