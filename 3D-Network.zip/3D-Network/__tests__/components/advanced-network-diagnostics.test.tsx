import React from 'react'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import '@testing-library/jest-dom'
import AdvancedNetworkDiagnostics from '@/components/advanced-network-diagnostics'

// Mock the fetch function
global.fetch = jest.fn(() =>
  Promise.resolve({
    ok: true,
    json: () => Promise.resolve({ result: 'Diagnostic result' }),
  })
) as jest.Mock

describe('AdvancedNetworkDiagnostics', () => {
  beforeEach(() => {
    jest.clearAllMocks()
  })

  it('renders the component', () => {
    render(<AdvancedNetworkDiagnostics />)
    expect(screen.getByText('Advanced Network Diagnostics')).toBeInTheDocument()
  })

  it('allows input of target and selection of diagnostic tool', () => {
    render(<AdvancedNetworkDiagnostics />)
    const targetInput = screen.getByLabelText('Target IP or Hostname')
    const toolSelect = screen.getByLabelText('Diagnostic Tool')

    fireEvent.change(targetInput, { target: { value: '192.168.1.1' } })
    fireEvent.change(toolSelect, { target: { value: 'traceroute' } })

    expect(targetInput).toHaveValue('192.168.1.1')
    expect(toolSelect).toHaveValue('traceroute')
  })

  it('runs diagnostic and displays result', async () => {
    render(<AdvancedNetworkDiagnostics />)
    const targetInput = screen.getByLabelText('Target IP or Hostname')
    const runButton = screen.getByText('Run Diagnostic')

    fireEvent.change(targetInput, { target: { value: '192.168.1.1' } })
    fireEvent.click(runButton)

    await waitFor(() => {
      expect(screen.getByText('Diagnostic Result:')).toBeInTheDocument()
      expect(screen.getByText('Diagnostic result')).toBeInTheDocument()
    })
  })

  it('displays error message when diagnostic fails', async () => {
    global.fetch = jest.fn(() =>
      Promise.resolve({
        ok: false,
        json: () => Promise.resolve({ error: 'Diagnostic failed' }),
      })
    ) as jest.Mock

    render(<AdvancedNetworkDiagnostics />)
    const targetInput = screen.getByLabelText('Target IP or Hostname')
    const runButton = screen.getByText('Run Diagnostic')

    fireEvent.change(targetInput, { target: { value: '192.168.1.1' } })
    fireEvent.click(runButton)

    await waitFor(() => {
      expect(screen.getByText('Error')).toBeInTheDocument()
      expect(screen.getByText('An error occurred while running diagnostics')).toBeInTheDocument()
    })
  })
})

