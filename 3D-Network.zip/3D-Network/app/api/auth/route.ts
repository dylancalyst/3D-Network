import { NextResponse } from 'next/server'
import { sign } from 'jsonwebtoken'

const SECRET_KEY = process.env.JWT_SECRET || 'your-secret-key'

export async function POST(request: Request) {
  const body = await request.json()
  const { username, password } = body

  // In a real application, you would verify the username and password against a database
  if (username === 'admin' && password === 'password') {
    const token = sign({ username }, SECRET_KEY, { expiresIn: '1h' })
    return NextResponse.json({ token })
  } else {
    return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 })
  }
}

