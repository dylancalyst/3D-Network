import { NextResponse } from 'next/server'

export async function GET() {
  // In a real application, this data would come from your database or monitoring system
  const data = {
    activeDevices: {
      count: 573,
      change: 20.1,
      details: [
        { type: 'Switches', count: 120 },
        { type: 'Routers', count: 45 },
        { type: 'Servers', count: 89 },
        { type: 'Endpoints', count: 319 },
      ]
    },
    monitoredServers: {
      count: 89,
      change: 10.5,
      details: [
        { type: 'Web Servers', count: 30 },
        { type: 'Database Servers', count: 25 },
        { type: 'Application Servers', count: 20 },
        { type: 'File Servers', count: 14 },
      ]
    },
    activeAlerts: {
      count: 17,
      change: -25,
      details: [
        { severity: 'Critical', count: 3 },
        { severity: 'High', count: 5 },
        { severity: 'Medium', count: 6 },
        { severity: 'Low', count: 3 },
      ]
    },
    networkTraffic: {
      total: 2350,
      change: 35,
      details: [
        { protocol: 'HTTP', volume: 850 },
        { protocol: 'HTTPS', volume: 1200 },
        { protocol: 'FTP', volume: 150 },
        { protocol: 'Other', volume: 150 },
      ]
    },
    cpuUsage: 65,
    memoryUsage: 78,
    diskUsage: 52,
    trafficOverview: [
      { name: "Jan", total: 1200 },
      { name: "Feb", total: 1900 },
      { name: "Mar", total: 2400 },
      { name: "Apr", total: 1800 },
      { name: "May", total: 2800 },
      { name: "Jun", total: 2350 },
      { name: "Jul", total: 3000 },
      { name: "Aug", total: 2900 },
      { name: "Sep", total: 2700 },
      { name: "Oct", total: 2600 },
      { name: "Nov", total: 3100 },
      { name: "Dec", total: 2350 },
    ]
  }

  return NextResponse.json(data)
}

