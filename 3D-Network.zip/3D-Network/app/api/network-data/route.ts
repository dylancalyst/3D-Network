import { NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'
import { getSocket } from '@/utils/websocket';
import { logger } from '@/lib/logger';

const prisma = new PrismaClient()

export async function GET(request: Request) {
  try {
    const devices = await prisma.device.findMany()
    const links = await prisma.networkLink.findMany()

    await updateNetworkTopology();

    const nodes = devices.map(device => ({
      id: device.id,
      name: device.name,
      type: device.type,
      status: device.status,
      x: Math.random() * 4 - 2,
      y: Math.random() * 4 - 2,
      z: Math.random() * 4 - 2,
      load: device.cpuUsage,
    }))

    const formattedLinks = links.map(link => ({
      source: link.sourceDeviceId,
      target: link.targetDeviceId,
      status: link.status,
    }))

    const socket = getSocket();
    socket.emit('topologyUpdate', { nodes, formattedLinks });

    return NextResponse.json({ nodes, links: formattedLinks })
  } catch (error) {
    logger.error('Error fetching network data:', error)
    return NextResponse.json({ error: 'Failed to fetch network data' }, { status: 500 })
  }
}

export async function updateNetworkTopology() {
  try {
    const devices = await prisma.device.findMany();
    const links = await prisma.networkLink.findMany();

    const nodes = devices.map(device => ({
      id: device.id,
      name: device.name,
      type: device.type,
      status: device.status,
      x: Math.random() * 4 - 2, // Random x position
      y: Math.random() * 4 - 2, // Random y position
      z: Math.random() * 4 - 2, // Random z position
      load: device.cpuUsage, // Using CPU usage as load
    }))

    const formattedLinks = links.map(link => ({
      source: link.sourceDeviceId,
      target: link.targetDeviceId,
      status: link.status,
    }))

    const socket = getSocket();
    socket.emit('topologyUpdate', { nodes, links: formattedLinks });
  } catch (error) {
    logger.error('Error updating network topology:', error);
  }
}

