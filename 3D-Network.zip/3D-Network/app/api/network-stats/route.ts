import { NextResponse } from 'next/server'

let lastBandwidth = 50
let lastLatency = 20
let lastPacketLoss = 0.5

export async function GET(request: Request) {
  // Simulate network stats with some randomness and trends
  lastBandwidth = Math.max(0, Math.min(100, lastBandwidth + (Math.random() - 0.5) * 10))
  lastLatency = Math.max(1, Math.min(100, lastLatency + (Math.random() - 0.5) * 5))
  lastPacketLoss = Math.max(0, Math.min(5, lastPacketLoss + (Math.random() - 0.5) * 0.2))

  const stats = {
    timestamp: Date.now(),
    bandwidth: parseFloat(lastBandwidth.toFixed(2)),
    latency: parseFloat(lastLatency.toFixed(2)),
    packetLoss: parseFloat(lastPacketLoss.toFixed(2)),
  }

  return NextResponse.json(stats)
}

