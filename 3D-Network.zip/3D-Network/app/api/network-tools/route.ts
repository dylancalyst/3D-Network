import { NextResponse } from 'next/server'
import { exec } from 'child_process'
import util from 'util'

const execAsync = util.promisify(exec)

export async function GET(request: Request) {
 const { searchParams } = new URL(request.url)
 const tool = searchParams.get('tool')
 const target = searchParams.get('target')

 if (!tool || !target) {
   return NextResponse.json({ error: 'Tool and target are required' }, { status: 400 })
 }

 try {
   let result: string
   switch (tool) {
     case 'ping':
       result = await runPing(target)
       break
     case 'traceroute':
       result = await runTraceroute(target)
       break
     case 'whois':
       result = await runWhois(target)
       break
     case 'portscan':
       result = await runPortscan(target)
       break
     default:
       return NextResponse.json({ error: 'Invalid tool' }, { status: 400 })
   }

   return NextResponse.json({ result })
 } catch (error) {
   console.error(`Error running ${tool}:`, error)
   return NextResponse.json({ error: `Failed to run ${tool}: ${error instanceof Error ? error.message : String(error)}` }, { status: 500 })
 }
}

async function runPing(target: string): Promise<string> {
 const { stdout, stderr } = await execAsync(`ping -c 4 ${target}`)
 return stdout || stderr
}

async function runTraceroute(target: string): Promise<string> {
 const { stdout, stderr } = await execAsync(`traceroute ${target}`)
 return stdout || stderr
}

async function runWhois(target: string): Promise<string> {
 const { stdout, stderr } = await execAsync(`whois ${target}`)
 return stdout || stderr
}

async function runPortscan(target: string): Promise<string> {
 const { stdout, stderr } = await execAsync(`nmap -p- -T4 ${target}`)
 return stdout || stderr
}

