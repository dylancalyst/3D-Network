import { NextResponse } from 'next/server'

export async function GET(request: Request) {
 // Placeholder Wi-Fi data - replace with actual data from your Wi-Fi monitoring system
 const wifiData = [
   { ssid: 'Rede Wi-Fi 1', channel: 6, signalStrength: 80, connectedDevices: 10, latitude: -23.5505, longitude: -46.6333 }, // São Paulo
   { ssid: 'Rede Wi-Fi 2', channel: 11, signalStrength: 90, connectedDevices: 5, latitude: -22.9068, longitude: -43.1729 }, // Rio de Janeiro
   // ... more Wi-Fi networks
 ]

 return NextResponse.json(wifiData)
}

