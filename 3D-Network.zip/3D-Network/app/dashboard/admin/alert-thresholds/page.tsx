'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { withAdminAccess } from '@/components/with-admin-access'
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

interface AlertThresholds {
  cpuWarning: number
  cpuCritical: number
  memoryWarning: number
  memoryCritical: number
  diskWarning: number
  diskCritical: number
  bandwidthWarning: number
  bandwidthCritical: number
}

function AlertThresholdsPage() {
  const [thresholds, setThresholds] = useState<AlertThresholds>({
    cpuWarning: 70,
    cpuCritical: 90,
    memoryWarning: 70,
    memoryCritical: 90,
    diskWarning: 80,
    diskCritical: 95,
    bandwidthWarning: 70,
    bandwidthCritical: 90,
  })

  useEffect(() => {
    fetchThresholds()
  }, [])

  const fetchThresholds = async () => {
    try {
      const response = await fetch('/api/alert-thresholds')
      if (response.ok) {
        const data = await response.json()
        setThresholds(data)
      }
    } catch (error) {
      console.error('Failed to fetch alert thresholds:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/alert-thresholds', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(thresholds),
      })
      if (!response.ok) throw new Error('Failed to update alert thresholds')
      alert('Alert thresholds updated successfully')
    } catch (err) {
      alert('Failed to update alert thresholds')
    }
  }

  return (
    <div className="space-y-6">
      <div className='flex items-center mb-4'>
        <Link href="/dashboard/admin">
          <Button variant="ghost"><ArrowLeft className="mr-2 h-4 w-4" /> Voltar à Administração</Button>
        </Link>
      </div>
      <h1 className="text-2xl font-bold">Configurações Globais de Alertas</h1>
      <form onSubmit={handleSubmit} className="space-y-4 bg-white rounded-lg shadow p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="cpuWarning">CPU - Aviso (%)</Label>
            <Input
              id="cpuWarning"
              type="number"
              value={thresholds.cpuWarning}
              onChange={(e) => setThresholds({ ...thresholds, cpuWarning: Number(e.target.value) })}
              min={0}
              max={100}
              required
            />
          </div>
          <div>
            <Label htmlFor="cpuCritical">CPU - Crítico (%)</Label>
            <Input
              id="cpuCritical"
              type="number"
              value={thresholds.cpuCritical}
              onChange={(e) => setThresholds({ ...thresholds, cpuCritical: Number(e.target.value) })}
              min={0}
              max={100}
              required
            />
          </div>
          <div>
            <Label htmlFor="memoryWarning">Memória - Aviso (%)</Label>
            <Input
              id="memoryWarning"
              type="number"
              value={thresholds.memoryWarning}
              onChange={(e) => setThresholds({ ...thresholds, memoryWarning: Number(e.target.value) })}
              min={0}
              max={100}
              required
            />
          </div>
          <div>
            <Label htmlFor="memoryCritical">Memória - Crítico (%)</Label>
            <Input
              id="memoryCritical"
              type="number"
              value={thresholds.memoryCritical}
              onChange={(e) => setThresholds({ ...thresholds, memoryCritical: Number(e.target.value) })}
              min={0}
              max={100}
              required
            />
          </div>
          <div>
            <Label htmlFor="diskWarning">Disco - Aviso (%)</Label>
            <Input
              id="diskWarning"
              type="number"
              value={thresholds.diskWarning}
              onChange={(e) => setThresholds({ ...thresholds, diskWarning: Number(e.target.value) })}
              min={0}
              max={100}
              required
            />
          </div>
          <div>
            <Label htmlFor="diskCritical">Disco - Crítico (%)</Label>
            <Input
              id="diskCritical"
              type="number"
              value={thresholds.diskCritical}
              onChange={(e) => setThresholds({ ...thresholds, diskCritical: Number(e.target.value) })}
              min={0}
              max={100}
              required
            />
          </div>
          <div>
            <Label htmlFor="bandwidthWarning">Largura de Banda - Aviso (%)</Label>
            <Input
              id="bandwidthWarning"
              type="number"
              value={thresholds.bandwidthWarning}
              onChange={(e) => setThresholds({ ...thresholds, bandwidthWarning: Number(e.target.value) })}
              min={0}
              max={100}
              required
            />
          </div>
          <div>
            <Label htmlFor="bandwidthCritical">Largura de Banda - Crítico (%)</Label>
            <Input
              id="bandwidthCritical"
              type="number"
              value={thresholds.bandwidthCritical}
              onChange={(e) => setThresholds({ ...thresholds, bandwidthCritical: Number(e.target.value) })}
              min={0}
              max={100}
              required
            />
          </div>
        </div>
        <Button type="submit">Salvar Configurações</Button>
      </form>
    </div>
  )
}

export default withAdminAccess(AlertThresholdsPage)

