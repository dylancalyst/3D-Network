'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Select } from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import { withAdminAccess } from '@/components/with-admin-access'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { CloudUpload, CloudDownload, HardDrive } from 'lucide-react'
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';


function BackupRestorePage() {
 const [backupOptions, setBackupOptions] = useState({
   includeConfigurations: true,
   includeHistory: true,
   includeReports: true,
   storageLocation: 'cloud',
 })
 const [restoreFile, setRestoreFile] = useState<File | null>(null)
 const [restoreOptions, setRestoreOptions] = useState({
   restoreType: 'full',
 })
 const [operation, setOperation] = useState<'idle' | 'backup' | 'restore'>('idle')
 const [progress, setProgress] = useState(0)
 const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)

 const handleBackup = async () => {
   setOperation('backup')
   setProgress(0)
   setMessage(null)

   try {
     const response = await fetch('/api/admin/backup', {
       method: 'POST',
       headers: { 'Content-Type': 'application/json' },
       body: JSON.stringify(backupOptions),
     })

     if (!response.ok) throw new Error('Backup failed')

     const reader = response.body?.getReader()
     if (!reader) throw new Error('Unable to read response')

     while (true) {
       const { done, value } = await reader.read()
       if (done) break
       const chunk = new TextDecoder().decode(value)
       const { progress, message } = JSON.parse(chunk)
       setProgress(progress)
       if (message) setMessage({ type: 'success', text: message })
     }

     setMessage({ type: 'success', text: 'Backup completed successfully' })
   } catch (error) {
     setMessage({ type: 'error', text: 'Backup failed: ' + (error as Error).message })
   } finally {
     setOperation('idle')
   }
 }

 const handleRestore = async () => {
   if (!restoreFile) return

   setOperation('restore')
   setProgress(0)
   setMessage(null)

   const formData = new FormData()
   formData.append('file', restoreFile)
   formData.append('options', JSON.stringify(restoreOptions))

   try {
     const response = await fetch('/api/admin/restore', {
       method: 'POST',
       body: formData,
     })

     if (!response.ok) throw new Error('Restore failed')

     const reader = response.body?.getReader()
     if (!reader) throw new Error('Unable to read response')

     while (true) {
       const { done, value } = await reader.read()
       if (done) break
       const chunk = new TextDecoder().decode(value)
       const { progress, message } = JSON.parse(chunk)
       setProgress(progress)
       if (message) setMessage({ type: 'success', text: message })
     }

     setMessage({ type: 'success', text: 'Restore completed successfully' })
   } catch (error) {
     setMessage({ type: 'error', text: 'Restore failed: ' + (error as Error).message })
   } finally {
     setOperation('idle')
   }
 }

 return (
   <div className="space-y-6">
     <div className='flex items-center mb-4'>
       <Link href="/dashboard/admin">
         <Button variant="ghost"><ArrowLeft className="mr-2 h-4 w-4" /> Voltar à Administração</Button>
       </Link>
     </div>
     <h1 className="text-2xl font-bold">Backup e Restauração</h1>

     <div className="bg-white rounded-lg shadow p-6 space-y-4">
       <h2 className="text-xl font-semibold">Criar Novo Backup</h2>
       <div className="space-y-2">
         <Checkbox
           id="includeConfigurations"
           checked={backupOptions.includeConfigurations}
           onCheckedChange={(checked) => setBackupOptions(prev => ({ ...prev, includeConfigurations: checked as boolean }))}
         />
         <Label htmlFor="includeConfigurations">Incluir Configurações</Label>
       </div>
       <div className="space-y-2">
         <Checkbox
           id="includeHistory"
           checked={backupOptions.includeHistory}
           onCheckedChange={(checked) => setBackupOptions(prev => ({ ...prev, includeHistory: checked as boolean }))}
         />
         <Label htmlFor="includeHistory">Incluir Histórico</Label>
       </div>
       <div className="space-y-2">
         <Checkbox
           id="includeReports"
           checked={backupOptions.includeReports}
           onCheckedChange={(checked) => setBackupOptions(prev => ({ ...prev, includeReports: checked as boolean }))}
         />
         <Label htmlFor="includeReports">Incluir Relatórios</Label>
       </div>
       <div className="space-y-2">
         <Label htmlFor="storageLocation">Local de Armazenamento</Label>
         <Select
           id="storageLocation"
           value={backupOptions.storageLocation}
           onValueChange={(value) => setBackupOptions(prev => ({ ...prev, storageLocation: value }))}
           options={[
             { value: 'local', label: 'Local' },
             { value: 'cloud', label: 'Nuvem' },
           ]}
         />
       </div>
       <Button onClick={handleBackup} disabled={operation !== 'idle'}>
         {backupOptions.storageLocation === 'cloud' ? <CloudUpload className="mr-2 h-4 w-4" /> : <HardDrive className="mr-2 h-4 w-4" />}
         Iniciar Backup
       </Button>
     </div>

     <div className="bg-white rounded-lg shadow p-6 space-y-4">
       <h2 className="text-xl font-semibold">Restaurar Backup</h2>
       <div className="space-y-2">
         <Label htmlFor="restoreFile">Arquivo de Backup</Label>
         <Input
           id="restoreFile"
           type="file"
           onChange={(e) => setRestoreFile(e.target.files?.[0] || null)}
         />
       </div>
       <div className="space-y-2">
         <Label htmlFor="restoreType">Tipo de Restauração</Label>
         <Select
           id="restoreType"
           value={restoreOptions.restoreType}
           onValueChange={(value) => setRestoreOptions(prev => ({ ...prev, restoreType: value }))}
           options={[
             { value: 'full', label: 'Completa' },
             { value: 'partial', label: 'Parcial' },
           ]}
         />
       </div>
       <Button onClick={handleRestore} disabled={!restoreFile || operation !== 'idle'}>
         <CloudDownload className="mr-2 h-4 w-4" />
         Iniciar Restauração
       </Button>
     </div>

     {operation !== 'idle' && (
       <div className="space-y-2">
         <Progress value={progress} className="w-full" />
         <p className="text-center">{operation === 'backup' ? 'Backup' : 'Restauração'} em progresso: {progress}%</p>
       </div>
     )}

     {message && (
       <Alert variant={message.type === 'success' ? 'default' : 'destructive'}>
         <AlertTitle>{message.type === 'success' ? 'Sucesso' : 'Erro'}</AlertTitle>
         <AlertDescription>{message.text}</AlertDescription>
       </Alert>
     )}
   </div>
 )
}

export default withAdminAccess(BackupRestorePage)

