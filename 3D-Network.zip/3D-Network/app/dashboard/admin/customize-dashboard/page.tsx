'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd'
import { withAdminAccess } from '@/components/with-admin-access'

interface Widget {
  id: string
  name: string
  enabled: boolean
}

function CustomizeDashboardPage() {
  const [widgets, setWidgets] = useState<Widget[]>([])
  const [status, setStatus] = useState<string | null>(null)

  useEffect(() => {
    fetchWidgets()
  }, [])

  const fetchWidgets = async () => {
    try {
      const response = await fetch('/api/admin/dashboard-widgets')
      if (!response.ok) throw new Error('Falha ao buscar widgets')
      const data = await response.json()
      setWidgets(data)
    } catch (error) {
      console.error('Erro ao buscar widgets:', error)
    }
  }

  const handleCheckboxChange = (id: string) => {
    setWidgets(widgets.map(widget =>
      widget.id === id ? { ...widget, enabled: !widget.enabled } : widget
    ))
  }

  const onDragEnd = (result: any) => {
    if (!result.destination) return

    const items = Array.from(widgets)
    const [reorderedItem] = items.splice(result.source.index, 1)
    items.splice(result.destination.index, 0, reorderedItem)

    setWidgets(items)
  }

  const saveChanges = async () => {
    try {
      const response = await fetch('/api/admin/dashboard-widgets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(widgets),
      })
      if (!response.ok) throw new Error('Falha ao salvar configurações')
      setStatus('Configurações salvas com sucesso!')
    } catch (error) {
      setStatus(`Erro ao salvar configurações: ${(error as Error).message}`)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Personalizar Dashboard</h1>
      <DragDropContext onDragEnd={onDragEnd}>
        <Droppable droppableId="widgets">
          {(provided) => (
            <ul {...provided.droppableProps} ref={provided.innerRef} className="space-y-2">
              {widgets.map((widget, index) => (
                <Draggable key={widget.id} draggableId={widget.id} index={index}>
                  {(provided) => (
                    <li
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      className="flex items-center space-x-2 p-2 bg-white rounded-lg shadow"
                    >
                      <Checkbox
                        id={widget.id}
                        checked={widget.enabled}
                        onCheckedChange={() => handleCheckboxChange(widget.id)}
                      />
                      <Label htmlFor={widget.id}>{widget.name}</Label>
                    </li>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </ul>
          )}
        </Droppable>
      </DragDropContext>
      <Button onClick={saveChanges}>Salvar Alterações</Button>
      {status && <p className="text-sm text-gray-500">{status}</p>}
    </div>
  )
}

export default withAdminAccess(CustomizeDashboardPage)

