'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { withAdminAccess } from '@/components/with-admin-access'

interface NetworkMapSettings {
  deviceColors: {
    [key: string]: string
  }
  deviceSizes: {
    [key: string]: number
  }
  showLabels: boolean
  labelSize: number
  connectionColor: string
  connectionWidth: number
  backgroundColor: string
}

function CustomizeNetworkMapPage() {
  const [settings, setSettings] = useState<NetworkMapSettings>({
    deviceColors: {},
    deviceSizes: {},
    showLabels: true,
    labelSize: 12,
    connectionColor: '#999999',
    connectionWidth: 2,
    backgroundColor: '#ffffff',
  })
  const [status, setStatus] = useState<string | null>(null)

  useEffect(() => {
    fetchSettings()
  }, [])

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/admin/network-map-settings')
      if (!response.ok) throw new Error('Falha ao buscar configurações')
      const data = await response.json()
      setSettings(data)
    } catch (error) {
      console.error('Erro ao buscar configurações:', error)
    }
  }

  const handleChange = (field: string, value: any) => {
    setSettings(prev => ({ ...prev, [field]: value }))
  }

  const handleDeviceColorChange = (deviceType: string, color: string) => {
    setSettings(prev => ({
      ...prev,
      deviceColors: { ...prev.deviceColors, [deviceType]: color }
    }))
  }

  const handleDeviceSizeChange = (deviceType: string, size: number) => {
    setSettings(prev => ({
      ...prev,
      deviceSizes: { ...prev.deviceSizes, [deviceType]: size }
    }))
  }

  const saveChanges = async () => {
    try {
      const response = await fetch('/api/admin/network-map-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      })
      if (!response.ok) throw new Error('Falha ao salvar configurações')
      setStatus('Configurações salvas com sucesso!')
    } catch (error) {
      setStatus(`Erro ao salvar configurações: ${(error as Error).message}`)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Personalizar Mapa de Rede</h1>
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Cores dos Dispositivos</h2>
        {Object.entries(settings.deviceColors).map(([deviceType, color]) => (
          <div key={deviceType} className="flex items-center space-x-2">
            <Label htmlFor={`color-${deviceType}`}>{deviceType}</Label>
            <Input
              id={`color-${deviceType}`}
              type="color"
              value={color}
              onChange={(e) => handleDeviceColorChange(deviceType, e.target.value)}
            />
          </div>
        ))}
      </div>
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Tamanhos dos Dispositivos</h2>
        {Object.entries(settings.deviceSizes).map(([deviceType, size]) => (
          <div key={deviceType} className="flex items-center space-x-2">
            <Label htmlFor={`size-${deviceType}`}>{deviceType}</Label>
            <Input
              id={`size-${deviceType}`}
              type="number"
              value={size}
              onChange={(e) => handleDeviceSizeChange(deviceType, Number(e.target.value))}
              min={1}
              max={50}
            />
          </div>
        ))}
      </div>
      <div className="space-y-2">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="showLabels"
            checked={settings.showLabels}
            onCheckedChange={(checked) => handleChange('showLabels', checked)}
          />
          <Label htmlFor="showLabels">Mostrar Rótulos</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Label htmlFor="labelSize">Tamanho dos Rótulos</Label>
          <Input
            id="labelSize"
            type="number"
            value={settings.labelSize}
            onChange={(e) => handleChange('labelSize', Number(e.target.value))}
            min={8}
            max={24}
          />
        </div>
      </div>
      <div className="space-y-2">
        <div className="flex items-center space-x-2">
          <Label htmlFor="connectionColor">Cor das Conexões</Label>
          <Input
            id="connectionColor"
            type="color"
            value={settings.connectionColor}
            onChange={(e) => handleChange('connectionColor', e.target.value)}
          />
        </div>
        <div className="flex items-center space-x-2">
          <Label htmlFor="connectionWidth">Largura das Conexões</Label>
          <Input
            id="connectionWidth"
            type="number"
            value={settings.connectionWidth}
            onChange={(e) => handleChange('connectionWidth', Number(e.target.value))}
            min={1}
            max={10}
          />
        </div>
      </div>
      <div className="space-y-2">
        <Label htmlFor="backgroundColor">Cor de Fundo</Label>
        <Input
          id="backgroundColor"
          type="color"
          value={settings.backgroundColor}
          onChange={(e) => handleChange('backgroundColor', e.target.value)}
        />
      </div>
      <Button onClick={saveChanges}>Salvar Alterações</Button>
      {status && <p className="text-sm text-gray-500">{status}</p>}
    </div>
  )
}

export default withAdminAccess(CustomizeNetworkMapPage)

