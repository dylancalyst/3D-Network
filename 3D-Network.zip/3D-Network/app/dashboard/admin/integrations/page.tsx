'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select } from '@/components/ui/select'
import { withAdminAccess } from '@/components/with-admin-access'
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

interface Integration {
  id: string
  name: string
  type: 'SIEM' | 'ServiceNow' | 'Other'
  url: string
  apiKey: string
  isActive: boolean
}

function IntegrationsPage() {
  const [integrations, setIntegrations] = useState<Integration[]>([])
  const [newIntegration, setNewIntegration] = useState<Omit<Integration, 'id'>>({
    name: '',
    type: 'SIEM',
    url: '',
    apiKey: '',
    isActive: true,
  })

  useEffect(() => {
    fetchIntegrations()
  }, [])

  const fetchIntegrations = async () => {
    try {
      const response = await fetch('/api/integrations')
      if (response.ok) {
        const data = await response.json()
        setIntegrations(data)
      }
    } catch (error) {
      console.error('Failed to fetch integrations:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/integrations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newIntegration),
      })
      if (!response.ok) throw new Error('Failed to add integration')
      alert('Integration added successfully')
      fetchIntegrations()
      setNewIntegration({
        name: '',
        type: 'SIEM',
        url: '',
        apiKey: '',
        isActive: true,
      })
    } catch (err) {
      alert('Failed to add integration')
    }
  }

  const testConnection = async (integration: Integration) => {
    try {
      const response = await fetch(`/api/integrations/${integration.id}/test`, {
        method: 'POST',
      })
      if (!response.ok) throw new Error('Connection test failed')
      alert('Connection test successful')
    } catch (err) {
      alert('Connection test failed')
    }
  }

  const toggleIntegration = async (id: string, isActive: boolean) => {
    try {
      const response = await fetch(`/api/integrations/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive }),
      })
      if (!response.ok) throw new Error('Failed to update integration')
      fetchIntegrations()
    } catch (err) {
      alert('Failed to update integration')
    }
  }

  return (
    <div className="space-y-6">
      <div className='flex items-center mb-4'>
        <Link href="/dashboard/admin">
          <Button variant="ghost"><ArrowLeft className="mr-2 h-4 w-4" /> Voltar à Administração</Button>
        </Link>
      </div>
      <h1 className="text-2xl font-bold">Integrações</h1>
      <div className="bg-white rounded-lg shadow p-4">
        <h2 className="text-xl font-semibold mb-4">Adicionar Nova Integração</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Nome da Integração</Label>
            <Input
              id="name"
              value={newIntegration.name}
              onChange={(e) => setNewIntegration({ ...newIntegration, name: e.target.value })}
              required
            />
          </div>
          <div>
            <Label htmlFor="type">Tipo de Integração</Label>
            <Select
              id="type"
              value={newIntegration.type}
              onValueChange={(value: 'SIEM' | 'ServiceNow' | 'Other') => setNewIntegration({ ...newIntegration, type: value })}
              options={[
                { value: 'SIEM', label: 'SIEM' },
                { value: 'ServiceNow', label: 'ServiceNow' },
                { value: 'Other', label: 'Outro' },
              ]}
            />
          </div>
          <div>
            <Label htmlFor="url">URL</Label>
            <Input
              id="url"
              value={newIntegration.url}
              onChange={(e) => setNewIntegration({ ...newIntegration, url: e.target.value })}
              required
            />
          </div>
          <div>
            <Label htmlFor="apiKey">Chave API</Label>
            <Input
              id="apiKey"
              type="password"
              value={newIntegration.apiKey}
              onChange={(e) => setNewIntegration({ ...newIntegration, apiKey: e.target.value })}
              required
            />
          </div>
          <Button type="submit">Adicionar Integração</Button>
        </form>
      </div>
      <div className="bg-white rounded-lg shadow p-4">
        <h2 className="text-xl font-semibold mb-4">Integrações Existentes</h2>
        <ul className="space-y-4">
          {integrations.map((integration) => (
            <li key={integration.id} className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-semibold">{integration.name}</h3>
                <p className="text-sm text-gray-500">{integration.type}</p>
              </div>
              <div className="space-x-2">
                <Button onClick={() => testConnection(integration)} variant="outline" size="sm">
                  Testar Conexão
                </Button>
                <Button
                  onClick={() => toggleIntegration(integration.id, !integration.isActive)}
                  variant={integration.isActive ? "destructive" : "default"}
                  size="sm"
                >
                  {integration.isActive ? 'Desativar' : 'Ativar'}
                </Button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

export default withAdminAccess(IntegrationsPage)

