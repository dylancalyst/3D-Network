'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { withAdminAccess } from '@/components/with-admin-access'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { RotateCw, Trash2, FileText } from 'lucide-react'
import LogViewer from '@/components/log-viewer'

function MaintenancePage() {
  const [updateStatus, setUpdateStatus] = useState<string | null>(null)
  const [cleanupStatus, setCleanupStatus] = useState<string | null>(null)
  const [retentionPeriod, setRetentionPeriod] = useState('30')

  const handleSoftwareUpdate = async () => {
    setUpdateStatus('Iniciando atualização...')
    try {
      const response = await fetch('/api/admin/update-software', { method: 'POST' })
      if (!response.ok) throw new Error('Falha na atualização')
      setUpdateStatus('Atualização concluída com sucesso!')
    } catch (error) {
      setUpdateStatus(`Erro na atualização: ${(error as Error).message}`)
    }
  }

  const handleDataCleanup = async () => {
    setCleanupStatus('Iniciando limpeza de dados...')
    try {
      const response = await fetch('/api/admin/cleanup-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ retentionPeriod: parseInt(retentionPeriod) })
      })
      if (!response.ok) throw new Error('Falha na limpeza de dados')
      setCleanupStatus('Limpeza de dados concluída com sucesso!')
    } catch (error) {
      setCleanupStatus(`Erro na limpeza de dados: ${(error as Error).message}`)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Manutenção do Sistema</h1>

      <Tabs defaultValue="logs">
        <TabsList>
          <TabsTrigger value="logs">Logs do Sistema</TabsTrigger>
          <TabsTrigger value="updates">Atualizações de Software</TabsTrigger>
          <TabsTrigger value="cleanup">Limpeza de Dados</TabsTrigger>
        </TabsList>

        <TabsContent value="logs">
          <div className="bg-white rounded-lg shadow p-6 space-y-4">
            <h2 className="text-xl font-semibold">Visualização de Logs</h2>
            <LogViewer />
          </div>
        </TabsContent>

        <TabsContent value="updates">
          <div className="bg-white rounded-lg shadow p-6 space-y-4">
            <h2 className="text-xl font-semibold">Atualizações de Software</h2>
            <p>Clique no botão abaixo para verificar e instalar atualizações de software.</p>
            <Button onClick={handleSoftwareUpdate}>
              <RotateCw className="mr-2 h-4 w-4" />
              Verificar e Atualizar
            </Button>
            {updateStatus && (
              <Alert variant={updateStatus.includes('sucesso') ? 'default' : 'destructive'}>
                <AlertTitle>Status da Atualização</AlertTitle>
                <AlertDescription>{updateStatus}</AlertDescription>
              </Alert>
            )}
          </div>
        </TabsContent>

        <TabsContent value="cleanup">
          <div className="bg-white rounded-lg shadow p-6 space-y-4">
            <h2 className="text-xl font-semibold">Limpeza de Dados Antigos</h2>
            <div className="space-y-2">
              <Label htmlFor="retentionPeriod">Período de Retenção (dias)</Label>
              <Select
                id="retentionPeriod"
                value={retentionPeriod}
                onValueChange={setRetentionPeriod}
                options={[
                  { value: '30', label: '30 dias' },
                  { value: '60', label: '60 dias' },
                  { value: '90', label: '90 dias' },
                  { value: '180', label: '180 dias' },
                  { value: '365', label: '1 ano' },
                ]}
              />
            </div>
            <Button onClick={handleDataCleanup}>
              <Trash2 className="mr-2 h-4 w-4" />
              Iniciar Limpeza
            </Button>
            {cleanupStatus && (
              <Alert variant={cleanupStatus.includes('sucesso') ? 'default' : 'destructive'}>
                <AlertTitle>Status da Limpeza</AlertTitle>
                <AlertDescription>{cleanupStatus}</AlertDescription>
              </Alert>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default withAdminAccess(MaintenancePage)

