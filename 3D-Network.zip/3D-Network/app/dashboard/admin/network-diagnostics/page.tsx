'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { withAdminAccess } from '@/components/with-admin-access'

function NetworkDiagnosticsPage() {
  const [target, setTarget] = useState('')
  const [result, setResult] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const runDiagnostic = async (tool: string) => {
    setLoading(true)
    setResult(null)
    setError(null)
    try {
      const response = await fetch('/api/admin/network-diagnostic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tool, target }),
      })
      if (!response.ok) throw new Error('Diagnostic failed')
      const data = await response.json()
      setResult(data.result)
    } catch (err) {
      setError(`Failed to run diagnostic: ${(err as Error).message}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Diagnóstico de Rede</h1>
      <div className="space-y-4">
        <div>
          <Label htmlFor="target">Alvo (IP ou Hostname)</Label>
          <Input
            id="target"
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            placeholder="Ex: 192.168.1.1 ou example.com"
          />
        </div>
        <Tabs defaultValue="ping">
          <TabsList>
            <TabsTrigger value="ping">Ping</TabsTrigger>
            <TabsTrigger value="traceroute">Traceroute</TabsTrigger>
            <TabsTrigger value="packet-capture">Captura de Pacotes</TabsTrigger>
          </TabsList>
          <TabsContent value="ping">
            <Button onClick={() => runDiagnostic('ping')} disabled={loading || !target}>
              Executar Ping
            </Button>
          </TabsContent>
          <TabsContent value="traceroute">
            <Button onClick={() => runDiagnostic('traceroute')} disabled={loading || !target}>
              Executar Traceroute
            </Button>
          </TabsContent>
          <TabsContent value="packet-capture">
            <Button onClick={() => runDiagnostic('packet-capture')} disabled={loading || !target}>
              Iniciar Captura de Pacotes
            </Button>
          </TabsContent>
        </Tabs>
      </div>
      {loading && <p>Executando diagnóstico...</p>}
      {error && (
        <Alert variant="destructive">
          <AlertTitle>Erro</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      {result && (
        <div className="bg-gray-100 p-4 rounded-lg">
          <pre className="whitespace-pre-wrap">{result}</pre>
        </div>
      )}
    </div>
  )
}

export default withAdminAccess(NetworkDiagnosticsPage)

