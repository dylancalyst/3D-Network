'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { withAdminAccess } from '@/components/with-admin-access'
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

interface NetworkMapSettings {
  updateInterval: number
  warningThreshold: number
  criticalThreshold: number
  normalColor: string
  warningColor: string
  criticalColor: string
  connectionColor: string
}

function NetworkMapSettingsPage() {
  const [settings, setSettings] = useState<NetworkMapSettings>({
    updateInterval: 60,
    warningThreshold: 70,
    criticalThreshold: 90,
    normalColor: '#4CAF50',
    warningColor: '#FFC107',
    criticalColor: '#F44336',
    connectionColor: '#2196F3',
  })

  useEffect(() => {
    fetchSettings()
  }, [])

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/network-map-settings')
      if (response.ok) {
        const data = await response.json()
        setSettings(data)
      }
    } catch (error) {
      console.error('Failed to fetch network map settings:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/network-map-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      })
      if (!response.ok) throw new Error('Failed to update network map settings')
      alert('Network map settings updated successfully')
    } catch (err) {
      alert('Failed to update network map settings')
    }
  }

  return (
    <div className="space-y-6">
      <div className='flex items-center mb-4'>
        <Link href="/dashboard/admin">
          <Button variant="ghost"><ArrowLeft className="mr-2 h-4 w-4" /> Voltar à Administração</Button>
        </Link>
      </div>
      <h1 className="text-2xl font-bold">Configurações do Mapa de Rede</h1>
      <form onSubmit={handleSubmit} className="space-y-4 bg-white rounded-lg shadow p-4">
        <div>
          <Label htmlFor="updateInterval">Intervalo de Atualização (segundos)</Label>
          <Input
            id="updateInterval"
            type="number"
            value={settings.updateInterval}
            onChange={(e) => setSettings({ ...settings, updateInterval: Number(e.target.value) })}
            min={1}
            required
          />
        </div>
        <div>
          <Label htmlFor="warningThreshold">Limite de Aviso (%)</Label>
          <Input
            id="warningThreshold"
            type="number"
            value={settings.warningThreshold}
            onChange={(e) => setSettings({ ...settings, warningThreshold: Number(e.target.value) })}
            min={0}
            max={100}
            required
          />
        </div>
        <div>
          <Label htmlFor="criticalThreshold">Limite Crítico (%)</Label>
          <Input
            id="criticalThreshold"
            type="number"
            value={settings.criticalThreshold}
            onChange={(e) => setSettings({ ...settings, criticalThreshold: Number(e.target.value) })}
            min={0}
            max={100}
            required
          />
        </div>
        <div>
          <Label htmlFor="normalColor">Cor Normal</Label>
          <Input
            id="normalColor"
            type="color"
            value={settings.normalColor}
            onChange={(e) => setSettings({ ...settings, normalColor: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="warningColor">Cor de Aviso</Label>
          <Input
            id="warningColor"
            type="color"
            value={settings.warningColor}
            onChange={(e) => setSettings({ ...settings, warningColor: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="criticalColor">Cor Crítica</Label>
          <Input
            id="criticalColor"
            type="color"
            value={settings.criticalColor}
            onChange={(e) => setSettings({ ...settings, criticalColor: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="connectionColor">Cor das Conexões</Label>
          <Input
            id="connectionColor"
            type="color"
            value={settings.connectionColor}
            onChange={(e) => setSettings({ ...settings, connectionColor: e.target.value })}
            required
          />
        </div>
        <Button type="submit">Salvar Configurações</Button>
      </form>
    </div>
  )
}

export default withAdminAccess(NetworkMapSettingsPage)

