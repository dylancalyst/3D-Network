'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { withAdminAccess } from '@/components/with-admin-access'
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

interface NetworkSettings {
  serverIp: string
  subnetMask: string
}

function NetworkSettingsPage() {
  const [settings, setSettings] = useState<NetworkSettings>({
    serverIp: '',
    subnetMask: '',
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/network-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      })
      if (!response.ok) throw new Error('Failed to update network settings')
      alert('Network settings updated successfully')
    } catch (err) {
      alert('Failed to update network settings')
    }
  }

  return (
    <div className="space-y-6">
      <div className='flex items-center mb-4'>
        <Link href="/dashboard/admin">
          <Button variant="ghost"><ArrowLeft className="mr-2 h-4 w-4" /> Voltar à Administração</Button>
        </Link>
      </div>
      <h1 className="text-2xl font-bold">Configurações de Rede</h1>
      <form onSubmit={handleSubmit} className="space-y-4 bg-white rounded-lg shadow p-4">
        <div>
          <Label htmlFor="serverIp">Endereço IP do Servidor</Label>
          <Input
            id="serverIp"
            value={settings.serverIp}
            onChange={(e) => setSettings({ ...settings, serverIp: e.target.value })}
            placeholder="Ex: 192.168.1.100"
            required
          />
        </div>
        <div>
          <Label htmlFor="subnetMask">Máscara de Sub-rede</Label>
          <Input
            id="subnetMask"
            value={settings.subnetMask}
            onChange={(e) => setSettings({ ...settings, subnetMask: e.target.value })}
            placeholder="Ex: 255.255.255.0"
            required
          />
        </div>
        <Button type="submit">Salvar Configurações</Button>
      </form>
      <p className="text-sm text-gray-500">
        Nota: Após salvar as configurações, os serviços de rede serão reiniciados automaticamente para aplicar as alterações.
      </p>
    </div>
  )
}

export default withAdminAccess(NetworkSettingsPage)

