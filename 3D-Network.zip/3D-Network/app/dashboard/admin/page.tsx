'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Switch } from '@/components/ui/switch'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { withAdminAccess } from '@/components/with-admin-access'
import SecurityPolicies from '@/components/security-policies'

interface User {
  id: number
  name: string
  email: string
  role: 'admin' | 'operator' | 'viewer'
  permissions: string[]
  twoFactorEnabled: boolean
  isActive: boolean
}

const availablePermissions = [
  'view_devices',
  'edit_devices',
  'view_reports',
  'create_reports',
  'manage_users',
  'configure_network',
]

function AdminPage() {
  const [users, setUsers] = useState<User[]>([])
  const [newUser, setNewUser] = useState<Omit<User, 'id' | 'isActive'>>({
    name: '',
    email: '',
    role: 'viewer',
    permissions: [],
    twoFactorEnabled: false
  })
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    fetchUsers()
  }, [])

  const fetchUsers = async () => {
    try {
      const response = await fetch('/api/users')
      if (!response.ok) throw new Error('Failed to fetch users')
      const data = await response.json()
      setUsers(data)
    } catch (err) {
      setError('Failed to load users')
    } finally {
      setLoading(false)
    }
  }

  const addUser = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newUser),
      })
      if (!response.ok) throw new Error('Failed to add user')
      fetchUsers()
      setNewUser({
        name: '',
        email: '',
        role: 'viewer',
        permissions: [],
        twoFactorEnabled: false
      })
    } catch (err) {
      setError('Failed to add user')
    }
  }

  const updateUser = async (id: number, updates: Partial<User>) => {
    try {
      const response = await fetch(`/api/users/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      })
      if (!response.ok) throw new Error('Failed to update user')
      fetchUsers()
      setEditingUser(null)
    } catch (err) {
      setError('Failed to update user')
    }
  }

  const deleteUser = async (id: number) => {
    if (window.confirm('Are you sure you want to delete this user? This action is permanent.')) {
      try {
        const response = await fetch(`/api/users/${id}`, { method: 'DELETE' })
        if (!response.ok) throw new Error('Failed to delete user')
        fetchUsers()
      } catch (err) {
        setError('Failed to delete user')
      }
    }
  }

  const toggleUserActivation = async (id: number, isActive: boolean) => {
    try {
      const response = await fetch(`/api/users/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive }),
      })
      if (!response.ok) throw new Error('Failed to update user status')
      fetchUsers()
    } catch (err) {
      setError('Failed to update user status')
    }
  }

  const handlePermissionChange = (user: User | Omit<User, 'id' | 'isActive'>, permission: string, checked: boolean) => {
    const updatedPermissions = checked
      ? [...user.permissions, permission]
      : user.permissions.filter(p => p !== permission)
    
    if ('id' in user) {
      setEditingUser({ ...user, permissions: updatedPermissions })
    } else {
      setNewUser({ ...user, permissions: updatedPermissions })
    }
  }

  const renderUserForm = (user: User | Omit<User, 'id' | 'isActive'>, onSubmit: (e: React.FormEvent) => void) => (
    <form onSubmit={onSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Nome</Label>
        <Input
          id="name"
          value={user.name}
          onChange={(e) => 'id' in user ? setEditingUser({ ...user, name: e.target.value }) : setNewUser({ ...user, name: e.target.value })}
          required
        />
      </div>
      <div>
        <Label htmlFor="email">E-mail</Label>
        <Input
          id="email"
          type="email"
          value={user.email}
          onChange={(e) => 'id' in user ? setEditingUser({ ...user, email: e.target.value }) : setNewUser({ ...user, email: e.target.value })}
          required
        />
      </div>
      <div>
        <Label htmlFor="role">Função</Label>
        <Select
          id="role"
          value={user.role}
          onValueChange={(value: 'admin' | 'operator' | 'viewer') => 'id' in user ? setEditingUser({ ...user, role: value }) : setNewUser({ ...user, role: value })}
          options={[
            { value: 'admin', label: 'Admin' },
            { value: 'operator', label: 'Operador' },
            { value: 'viewer', label: 'Visualizador' },
          ]}
        />
      </div>
      <div>
        <Label>Permissões</Label>
        <div className="space-y-2">
          {availablePermissions.map(permission => (
            <div key={permission} className="flex items-center">
              <Checkbox
                id={`permission-${permission}`}
                checked={user.permissions.includes(permission)}
                onCheckedChange={(checked) => handlePermissionChange(user, permission, checked as boolean)}
              />
              <label htmlFor={`permission-${permission}`} className="ml-2 text-sm">
                {permission.replace('_', ' ')}
              </label>
            </div>
          ))}
        </div>
      </div>
      <div className="flex items-center space-x-2">
        <Switch
          id="twoFactorEnabled"
          checked={user.twoFactorEnabled}
          onCheckedChange={(checked) => 'id' in user ? setEditingUser({ ...user, twoFactorEnabled: checked }) : setNewUser({ ...user, twoFactorEnabled: checked })}
        />
        <Label htmlFor="twoFactorEnabled">Enable Two-Factor Authentication</Label>
      </div>
      <Button type="submit">{'id' in user ? 'Salvar Alterações' : 'Criar Usuário'}</Button>
    </form>
  )

  if (loading) return <div>Loading...</div>
  if (error) return <div>Error: {error}</div>

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Administração</h1>
      <SecurityPolicies />
      <div className="bg-white rounded-lg shadow p-4">
        <h2 className="text-xl font-semibold mb-4">Adicionar Novo Usuário</h2>
        {renderUserForm(newUser, addUser)}
      </div>
      <div className="bg-white rounded-lg shadow p-4">
        <h2 className="text-xl font-semibold mb-4">Usuários Existentes</h2>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>E-mail</TableHead>
              <TableHead>Função</TableHead>
              <TableHead>Permissões</TableHead>
              <TableHead>2FA</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.map((user) => (
              <TableRow key={user.id}>
                <TableCell>{user.name}</TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>{user.role}</TableCell>
                <TableCell>{user.permissions.join(', ')}</TableCell>
                <TableCell>
                  <Switch
                    checked={user.twoFactorEnabled}
                    onCheckedChange={(checked) => updateUser(user.id, { twoFactorEnabled: checked })}
                  />
                </TableCell>
                <TableCell>
                  <Switch
                    checked={user.isActive}
                    onCheckedChange={(checked) => toggleUserActivation(user.id, checked)}
                  />
                  {user.isActive ? 'Ativo' : 'Inativo'}
                </TableCell>
                <TableCell>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setEditingUser(user)}>
                        Editar
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Editar Usuário</DialogTitle>
                      </DialogHeader>
                      {editingUser && renderUserForm(editingUser, (e) => {
                        e.preventDefault()
                        updateUser(editingUser.id, editingUser)
                      })}
                    </DialogContent>
                  </Dialog>
                  <Button variant="outline" size="sm" className="ml-2" onClick={() => deleteUser(user.id)}>
                    Excluir
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

export default withAdminAccess(AdminPage)

