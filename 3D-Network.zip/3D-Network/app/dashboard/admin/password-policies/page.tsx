'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { withAdminAccess } from '@/components/with-admin-access'
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

interface PasswordPolicy {
  minLength: number
  requireUppercase: boolean
  requireLowercase: boolean
  requireNumbers: boolean
  requireSpecialChars: boolean
  expirationDays: number
}

function PasswordPoliciesPage() {
  const [policy, setPolicy] = useState<PasswordPolicy>({
    minLength: 8,
    requireUppercase: true,
    requireLowercase: true,
    requireNumbers: true,
    requireSpecialChars: true,
    expirationDays: 90,
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/password-policies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(policy),
      })
      if (!response.ok) throw new Error('Failed to update password policy')
      alert('Password policy updated successfully')
    } catch (err) {
      alert('Failed to update password policy')
    }
  }

  return (
    <div className="space-y-6">
      <div className='flex items-center mb-4'>
        <Link href="/dashboard/admin">
          <Button variant="ghost"><ArrowLeft className="mr-2 h-4 w-4" /> Voltar à Administração</Button>
        </Link>
      </div>
      <h1 className="text-2xl font-bold">Políticas de Senha</h1>
      <p>
        Configure as políticas de senha para garantir a segurança do sistema.
      </p>
      <form onSubmit={handleSubmit} className="space-y-4 bg-white rounded-lg shadow p-4">
        <div>
          <Label htmlFor="minLength">Comprimento Mínimo</Label>
          <Input
            id="minLength"
            type="number"
            value={policy.minLength}
            onChange={(e) => setPolicy({ ...policy, minLength: parseInt(e.target.value) })}
            min={1}
            required
          />
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="requireUppercase"
            checked={policy.requireUppercase}
            onCheckedChange={(checked) => setPolicy({ ...policy, requireUppercase: checked })}
          />
          <Label htmlFor="requireUppercase">Exigir Letra Maiúscula</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="requireLowercase"
            checked={policy.requireLowercase}
            onCheckedChange={(checked) => setPolicy({ ...policy, requireLowercase: checked })}
          />
          <Label htmlFor="requireLowercase">Exigir Letra Minúscula</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="requireNumbers"
            checked={policy.requireNumbers}
            onCheckedChange={(checked) => setPolicy({ ...policy, requireNumbers: checked })}
          />
          <Label htmlFor="requireNumbers">Exigir Números</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="requireSpecialChars"
            checked={policy.requireSpecialChars}
            onCheckedChange={(checked) => setPolicy({ ...policy, requireSpecialChars: checked })}
          />
          <Label htmlFor="requireSpecialChars">Exigir Caracteres Especiais</Label>
        </div>
        <div>
          <Label htmlFor="expirationDays">Dias para Expiração da Senha</Label>
          <Input
            id="expirationDays"
            type="number"
            value={policy.expirationDays}
            onChange={(e) => setPolicy({ ...policy, expirationDays: parseInt(e.target.value) })}
            min={0}
            required
          />
        </div>
        <Button type="submit">Salvar Políticas</Button>
      </form>
    </div>
  )
}

export default withAdminAccess(PasswordPoliciesPage)

