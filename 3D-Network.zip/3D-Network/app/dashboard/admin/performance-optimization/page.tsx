'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select } from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { withAdminAccess } from '@/components/with-admin-access'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'

interface PerformanceSettings {
  dataCollectionInterval: number
  mapDetailLevel: number
  enableDatabaseIndexing: boolean
  maxConcurrentQueries: number
}

function PerformanceOptimizationPage() {
  const [settings, setSettings] = useState<PerformanceSettings>({
    dataCollectionInterval: 60,
    mapDetailLevel: 5,
    enableDatabaseIndexing: true,
    maxConcurrentQueries: 10,
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [saveStatus, setSaveStatus] = useState<string | null>(null)

  useEffect(() => {
    fetchSettings()
  }, [])

  const fetchSettings = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await fetch('/api/admin/performance-settings')
      if (!response.ok) throw new Error('Failed to fetch performance settings')
      const data = await response.json()
      setSettings(data)
    } catch (err) {
      setError('Failed to load performance settings')
    } finally {
      setLoading(false)
    }
  }

  const saveSettings = async () => {
    setSaveStatus(null)
    setError(null)
    try {
      const response = await fetch('/api/admin/performance-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      })
      if (!response.ok) throw new Error('Failed to save performance settings')
      setSaveStatus('Settings saved successfully')
    } catch (err) {
      setError(`Failed to save settings: ${(err as Error).message}`)
    }
  }

  if (loading) return <p>Carregando configurações...</p>

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Otimização de Desempenho</h1>
      <div className="space-y-4">
        <div>
          <Label htmlFor="dataCollectionInterval">Intervalo de Coleta de Dados (segundos)</Label>
          <Input
            id="dataCollectionInterval"
            type="number"
            value={settings.dataCollectionInterval}
            onChange={(e) => setSettings({ ...settings, dataCollectionInterval: Number(e.target.value) })}
            min={10}
            max={3600}
          />
        </div>
        <div>
          <Label htmlFor="mapDetailLevel">Nível de Detalhe do Mapa 3D</Label>
          <Slider
            id="mapDetailLevel"
            min={1}
            max={10}
            step={1}
            value={[settings.mapDetailLevel]}
            onValueChange={(value) => setSettings({ ...settings, mapDetailLevel: value[0] })}
          />
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="enableDatabaseIndexing"
            checked={settings.enableDatabaseIndexing}
            onCheckedChange={(checked) => setSettings({ ...settings, enableDatabaseIndexing: checked })}
          />
          <Label htmlFor="enableDatabaseIndexing">Habilitar Indexação de Banco de Dados</Label>
        </div>
        <div>
          <Label htmlFor="maxConcurrentQueries">Máximo de Consultas Concorrentes</Label>
          <Input
            id="maxConcurrentQueries"
            type="number"
            value={settings.maxConcurrentQueries}
            onChange={(e) => setSettings({ ...settings, maxConcurrentQueries: Number(e.target.value) })}
            min={1}
            max={100}
          />
        </div>
      </div>
      <Button onClick={saveSettings}>Salvar Configurações</Button>
      {error && (
        <Alert variant="destructive">
          <AlertTitle>Erro</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      {saveStatus && (
        <Alert>
          <AlertTitle>Sucesso</AlertTitle>
          <AlertDescription>{saveStatus}</AlertDescription>
        </Alert>
      )}
    </div>
  )
}

export default withAdminAccess(PerformanceOptimizationPage)

