'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { withAdminAccess } from '@/components/with-admin-access'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Calendar } from '@/components/ui/calendar'
import { Shield, FileText, AlertTriangle } from 'lucide-react'
import AccessLogViewer from '@/components/access-log-viewer'
import SystemChangeLogViewer from '@/components/system-change-log-viewer'
import VulnerabilityScanner from '@/components/vulnerability-scanner'

function SecurityAuditsPage() {
  const [nextAuditDate, setNextAuditDate] = useState<Date | undefined>(new Date())
  const [auditFrequency, setAuditFrequency] = useState('monthly')
  const [auditStatus, setAuditStatus] = useState<string | null>(null)

  const scheduleAudit = async () => {
    try {
      const response = await fetch('/api/admin/schedule-audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nextAuditDate, auditFrequency }),
      })
      if (!response.ok) throw new Error('Falha ao agendar auditoria')
      setAuditStatus('Auditoria agendada com sucesso!')
    } catch (error) {
      setAuditStatus(`Erro ao agendar auditoria: ${(error as Error).message}`)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Auditorias de Segurança</h1>

      <Tabs defaultValue="schedule">
        <TabsList>
          <TabsTrigger value="schedule">Agendar Auditoria</TabsTrigger>
          <TabsTrigger value="access-logs">Logs de Acesso</TabsTrigger>
          <TabsTrigger value="system-changes">Alterações no Sistema</TabsTrigger>
          <TabsTrigger value="vulnerabilities">Verificação de Vulnerabilidades</TabsTrigger>
        </TabsList>

        <TabsContent value="schedule">
          <div className="bg-white rounded-lg shadow p-6 space-y-4">
            <h2 className="text-xl font-semibold">Agendar Próxima Auditoria</h2>
            <div className="space-y-2">
              <Label htmlFor="auditDate">Data da Próxima Auditoria</Label>
              <Calendar
                mode="single"
                selected={nextAuditDate}
                onSelect={setNextAuditDate}
                className="rounded-md border"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="auditFrequency">Frequência da Auditoria</Label>
              <Select
                id="auditFrequency"
                value={auditFrequency}
                onValueChange={setAuditFrequency}
                options={[
                  { value: 'weekly', label: 'Semanal' },
                  { value: 'monthly', label: 'Mensal' },
                  { value: 'quarterly', label: 'Trimestral' },
                  { value: 'biannually', label: 'Semestral' },
                  { value: 'annually', label: 'Anual' },
                ]}
              />
            </div>
            <Button onClick={scheduleAudit}>
              <Shield className="mr-2 h-4 w-4" />
              Agendar Auditoria
            </Button>
            {auditStatus && (
              <Alert variant={auditStatus.includes('sucesso') ? 'default' : 'destructive'}>
                <AlertTitle>Status do Agendamento</AlertTitle>
                <AlertDescription>{auditStatus}</AlertDescription>
              </Alert>
            )}
          </div>
        </TabsContent>

        <TabsContent value="access-logs">
          <div className="bg-white rounded-lg shadow p-6 space-y-4">
            <h2 className="text-xl font-semibold">Revisão de Logs de Acesso</h2>
            <AccessLogViewer />
          </div>
        </TabsContent>

        <TabsContent value="system-changes">
          <div className="bg-white rounded-lg shadow p-6 space-y-4">
            <h2 className="text-xl font-semibold">Alterações no Sistema</h2>
            <SystemChangeLogViewer />
          </div>
        </TabsContent>

        <TabsContent value="vulnerabilities">
          <div className="bg-white rounded-lg shadow p-6 space-y-4">
            <h2 className="text-xl font-semibold">Verificação de Vulnerabilidades</h2>
            <VulnerabilityScanner />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default withAdminAccess(SecurityAuditsPage)

