'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { withAdminAccess } from '@/components/with-admin-access'
import { RefreshCw, Play } from 'lucide-react'

interface ServiceStatus {
  id: string
  name: string
  status: 'running' | 'stopped' | 'error'
  lastChecked: string
}

function SystemStatusPage() {
  const [services, setServices] = useState<ServiceStatus[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchServiceStatus()
  }, [])

  const fetchServiceStatus = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await fetch('/api/admin/service-status')
      if (!response.ok) throw new Error('Failed to fetch service status')
      const data = await response.json()
      setServices(data)
    } catch (err) {
      setError('Failed to load service status')
    } finally {
      setLoading(false)
    }
  }

  const restartService = async (serviceId: string) => {
    try {
      const response = await fetch(`/api/admin/restart-service`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ serviceId }),
      })
      if (!response.ok) throw new Error('Failed to restart service')
      await fetchServiceStatus()
    } catch (err) {
      setError(`Failed to restart service: ${(err as Error).message}`)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Status do Sistema</h1>
      <div className="flex justify-between items-center">
        <Button onClick={fetchServiceStatus} disabled={loading}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Atualizar Status
        </Button>
      </div>
      {error && (
        <Alert variant="destructive">
          <AlertTitle>Erro</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      {loading ? (
        <p>Carregando status dos serviços...</p>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Serviço</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Última Verificação</TableHead>
              <TableHead>Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {services.map((service) => (
              <TableRow key={service.id}>
                <TableCell>{service.name}</TableCell>
                <TableCell>
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                    service.status === 'running' ? 'bg-green-100 text-green-800' :
                    service.status === 'stopped' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {service.status.toUpperCase()}
                  </span>
                </TableCell>
                <TableCell>{new Date(service.lastChecked).toLocaleString()}</TableCell>
                <TableCell>
                  <Button
                    size="sm"
                    onClick={() => restartService(service.id)}
                    disabled={service.status === 'running'}
                  >
                    <Play className="mr-2 h-4 w-4" />
                    Reiniciar
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  )
}

export default withAdminAccess(SystemStatusPage)

