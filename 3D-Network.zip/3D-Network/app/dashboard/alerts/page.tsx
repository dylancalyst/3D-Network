import AlertPanel from '@/components/alert-panel'
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

export default function AlertsPage() {
 return (
   <div className="space-y-6">
     <div className='flex items-center mb-4'>
       <Link href="/dashboard">
         <Button variant="ghost"><ArrowLeft className="mr-2 h-4 w-4" /> Voltar ao Dashboard</Button>
       </Link>
     </div>
     <h1 className="text-2xl font-bold">Alertas [^2]</h1>
     <p>
       Visualize os alertas ativos e o histórico de alertas.
       Você pode filtrar alertas por severidade, tipo de dispositivo ou período. [^2]
     </p>
     <AlertPanel showAllAlerts={true} />
   </div>
 )
}

