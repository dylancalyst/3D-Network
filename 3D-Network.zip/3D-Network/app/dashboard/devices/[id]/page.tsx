'use client'

import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ArrowLeft } from 'lucide-react'

interface DeviceDetails {
  id: string
  name: string
  type: string
  ip: string
  status: string
  lastSeen: string
}

export default function DeviceDetailsPage() {
  const params = useParams()
  const [device, setDevice] = useState<DeviceDetails | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchDeviceDetails = async () => {
      try {
        const response = await fetch(`/api/devices/${params.id}`)
        if (!response.ok) throw new Error('Failed to fetch device details')
        const data = await response.json()
        setDevice(data)
      } catch (err) {
        setError('Failed to fetch device details')
      } finally {
        setLoading(false)
      }
    }

    fetchDeviceDetails()
  }, [params.id])

  if (loading) return <div>Loading...</div>
  if (error) return <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>
  if (!device) return <div>Device not found</div>

  return (
    <div className="space-y-6">
      <div className='flex items-center mb-4'>
        <Link href="/dashboard/devices">
          <Button variant="ghost"><ArrowLeft className="mr-2 h-4 w-4" /> Voltar à Lista de Dispositivos</Button>
        </Link>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>{device.name}</CardTitle>
        </CardHeader>
        <CardContent>
          <p><strong>Type:</strong> {device.type}</p>
          <p><strong>IP Address:</strong> {device.ip}</p>
          <p><strong>Status:</strong> {device.status}</p>
          <p><strong>Last Seen:</strong> {device.lastSeen}</p>
        </CardContent>
      </Card>
    </div>
  )
}

