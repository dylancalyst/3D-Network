import DeviceList from '@/components/device-list'
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

export default function DevicesPage() {
 return (
   <div className="space-y-6">
     <div className='flex items-center mb-4'>
       <Link href="/dashboard">
         <Button variant="ghost"><ArrowLeft className="mr-2 h-4 w-4" /> Voltar ao Dashboard</Button>
       </Link>
     </div>
     <h1 className="text-2xl font-bold">Dispositivos [^2]</h1>
     <p>Esta seção exibe todos os dispositivos monitorados pela plataforma. [^2]</p>
     <p>Você pode clicar em um dispositivo para ver mais detalhes. [^2]</p>
     <DeviceList showDetails={true} />
   </div>
 )
}

