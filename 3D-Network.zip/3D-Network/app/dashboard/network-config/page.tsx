'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import FirewallRules from '@/components/firewall-rules'
import VpnWizard from '@/components/vpn-wizard'
import MonitoringProtocols from '@/components/monitoring-protocols'
import NetworkTopology from '@/components/network-topology'

export default function NetworkConfigPage() {
  const [firewallConfig, setFirewallConfig] = useState({
    enabledPorts: '80,443,22,161,162',
    natRules: [],
    packetFilters: [],
  })
  const [vpnConfig, setVpnConfig] = useState({
    enabled: false,
    serverAddress: '',
    protocol: 'OpenVPN',
    encryption: 'AES-256',
    authentication: 'Certificate',
  })
  const [monitoringConfig, setMonitoringConfig] = useState({
    snmp: { enabled: true, version: 'v3', community: 'public', interval: 300 },
    icmp: { enabled: true, interval: 60, timeout: 5 },
    netflow: { enabled: false, collectorIP: '', collectorPort: 2055 },
  })
  const [externalAccessConfig, setExternalAccessConfig] = useState({
    enabled: false,
    hostname: '',
    port: '',
  })

  const saveConfig = () => {
    console.log('Saving configuration:', { firewallConfig, vpnConfig, monitoringConfig, externalAccessConfig })
    // Aqui você implementaria a lógica para salvar as configurações
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Configuração de Rede</h1>
      <Tabs defaultValue="firewall">
        <TabsList>
          <TabsTrigger value="firewall">Firewall</TabsTrigger>
          <TabsTrigger value="vpn">VPN</TabsTrigger>
          <TabsTrigger value="monitoring">Protocolos de Monitoramento</TabsTrigger>
          <TabsTrigger value="topology">Topologia de Rede</TabsTrigger>
          <TabsTrigger value="externalAccess">Acesso Externo</TabsTrigger>
        </TabsList>
        <TabsContent value="firewall">
          <Accordion type="single" collapsible>
            <AccordionItem value="basic">
              <AccordionTrigger>Configuração Básica</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="enabledPorts">Portas Permitidas</Label>
                    <Input
                      id="enabledPorts"
                      value={firewallConfig.enabledPorts}
                      onChange={(e) => setFirewallConfig({ ...firewallConfig, enabledPorts: e.target.value })}
                      placeholder="Ex: 80,443,22,161,162"
                    />
                    <p className="text-sm text-gray-500 mt-1">Separe as portas por vírgulas</p>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="advanced">
              <AccordionTrigger>Configuração Avançada</AccordionTrigger>
              <AccordionContent>
                <FirewallRules
                  natRules={firewallConfig.natRules}
                  packetFilters={firewallConfig.packetFilters}
                  onUpdate={(newRules) => setFirewallConfig({ ...firewallConfig, ...newRules })}
                />
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </TabsContent>
        <TabsContent value="vpn">
          <VpnWizard
            config={vpnConfig}
            onConfigChange={setVpnConfig}
          />
        </TabsContent>
        <TabsContent value="monitoring">
          <MonitoringProtocols
            config={monitoringConfig}
            onConfigChange={setMonitoringConfig}
          />
        </TabsContent>
        <TabsContent value="topology">
          <NetworkTopology
            firewallRules={firewallConfig}
            vpnConfig={vpnConfig}
          />
        </TabsContent>
        <TabsContent value="externalAccess">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Switch
                id="externalAccessEnabled"
                checked={externalAccessConfig.enabled}
                onCheckedChange={(checked) => setExternalAccessConfig({ ...externalAccessConfig, enabled: checked })}
              />
              <Label htmlFor="externalAccessEnabled">Habilitar Acesso Externo</Label>
            </div>
            {externalAccessConfig.enabled && (
              <>
                <div>
                  <Label htmlFor="hostname">Hostname</Label>
                  <Input
                    id="hostname"
                    value={externalAccessConfig.hostname}
                    onChange={(e) => setExternalAccessConfig({ ...externalAccessConfig, hostname: e.target.value })}
                    placeholder="Ex: seu_dominio.com ou IP público"
                  />
                </div>
                <div>
                  <Label htmlFor="port">Porta</Label>
                  <Input
                    id="port"
                    type="number"
                    value={externalAccessConfig.port}
                    onChange={(e) => setExternalAccessConfig({ ...externalAccessConfig, port: e.target.value })}
                    placeholder="Ex: 80 ou 443"
                  />
                </div>
              </>
            )}
          </div>
        </TabsContent>
      </Tabs>
      <Button onClick={saveConfig}>Salvar Configurações</Button>
    </div>
  )
}

