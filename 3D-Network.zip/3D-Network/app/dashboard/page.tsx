'use client'

import { useSession } from "next-auth/react"
import AdminDashboard from '@/components/admin-dashboard'
import UserDashboard from '@/components/user-dashboard'
import { SavedConfigurations } from '@/components/saved-configurations'
import { useState } from 'react'
import { SaveConfigurationModal } from '@/components/save-configuration-modal'
import { SavedConfigurationsProvider } from '@/contexts/SavedConfigurationsContext'

export default function Dashboard() {
  const { data: session } = useSession()
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false)
  const [currentLayout, setCurrentLayout] = useState('')

  const saveLayout = (layout: string) => {
    setCurrentLayout(layout)
    setIsSaveModalOpen(true)
  }

  const DashboardComponent = session?.user?.role === 'admin' ? AdminDashboard : UserDashboard

  return (
    <SavedConfigurationsProvider>
      <div className="p-4">
        <SavedConfigurations />
        <DashboardComponent saveLayout={saveLayout} />
        {isSaveModalOpen && (
          <SaveConfigurationModal
            onClose={() => setIsSaveModalOpen(false)}
            currentLayout={currentLayout}
          />
        )}
      </div>
    </SavedConfigurationsProvider>
  )
}

