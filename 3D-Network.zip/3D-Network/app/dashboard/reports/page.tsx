'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Select } from '@/components/ui/select'
import { Calendar } from '@/components/ui/calendar'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts'
import { PDFDownloadLink } from '@react-pdf/renderer'
import { PDFReport } from '@/components/pdf-report'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'

const mockData = [
  { name: 'Router', uptime: 99.9, bandwidth: 80 },
  { name: 'Switch', uptime: 99.8, bandwidth: 75 },
  { name: 'Server 1', uptime: 99.5, bandwidth: 90 },
  { name: 'Server 2', uptime: 99.7, bandwidth: 85 },
  { name: 'PC 1', uptime: 98.5, bandwidth: 40 },
  { name: 'PC 2', uptime: 97.8, bandwidth: 35 },
]

const mockAlerts = [
  { message: 'High CPU usage on Server 1', severity: 'High', timestamp: '2023-06-15T10:30:00Z' },
  { message: 'Switch rebooted', severity: 'Medium', timestamp: '2023-06-15T09:45:00Z' },
  { message: 'PC 1 offline for 30 minutes', severity: 'Low', timestamp: '2023-06-15T08:00:00Z' },
]

export default function ReportsPage() {
  const [reportType, setReportType] = useState('performance')
  const [startDate, setStartDate] = useState<Date | undefined>(new Date())
  const [endDate, setEndDate] = useState<Date | undefined>(new Date())

  const generateReport = () => {
    console.log('Generating report:', { reportType, startDate, endDate })
    // Aqui você implementaria a lógica real de geração de relatórios
  }

  const reportData = {
    title: `Relatório de ${reportType === 'performance' ? 'Desempenho' : reportType === 'inventory' ? 'Inventário' : 'Alertas'}`,
    date: new Date().toLocaleDateString(),
    devices: mockData.map(device => ({
      name: device.name,
      status: 'Online',
      uptime: `${device.uptime}%`,
    })),
    alerts: mockAlerts,
  }

  return (
    <div className="space-y-6">
      <div className='flex items-center mb-4'>
        <Link href="/dashboard">
          <Button variant="ghost"><ArrowLeft className="mr-2 h-4 w-4" /> Voltar ao Dashboard</Button>
        </Link>
      </div>
      <h1 className="text-2xl font-bold">Relatórios</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Select
          value={reportType}
          onValueChange={setReportType}
          options={[
            { value: 'performance', label: 'Desempenho de Rede' },
            { value: 'inventory', label: 'Inventário de Dispositivos' },
            { value: 'alerts', label: 'Histórico de Alertas' },
          ]}
        />
        <Calendar
          selected={startDate}
          onChange={(date) => setStartDate(date)}
          placeholderText="Data Inicial"
        />
        <Calendar
          selected={endDate}
          onChange={(date) => setEndDate(date)}
          placeholderText="Data Final"
        />
      </div>
      <div className="flex space-x-4">
        <Button onClick={generateReport}>Gerar Relatório</Button>
        <PDFDownloadLink document={<PDFReport data={reportData} />} fileName="network-report.pdf">
          {({ blob, url, loading, error }) =>
            loading ? 'Carregando documento...' : <Button>Baixar PDF</Button>
          }
        </PDFDownloadLink>
      </div>
      <div className="bg-white rounded-lg shadow p-4">
        <h2 className="text-xl font-semibold mb-4">Visualização do Relatório</h2>
        <BarChart width={600} height={300} data={mockData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
          <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
          <Tooltip />
          <Legend />
          <Bar yAxisId="left" dataKey="uptime" fill="#8884d8" name="Uptime (%)" />
          <Bar yAxisId="right" dataKey="bandwidth" fill="#82ca9d" name="Uso de Banda (%)" />
        </BarChart>
      </div>
    </div>
  )
}

