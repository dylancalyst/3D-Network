'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    emailNotifications: true,
    alertThreshold: 80,
    dataRetentionDays: 30,
    backupFrequency: 'daily',
    darkMode: false,
  })

  const handleChange = (name: string, value: any) => {
    setSettings(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log('Configurações salvas:', settings)
    // Aqui você implementaria a lógica para salvar as configurações
  }

  return (
    <div className="space-y-6">
      <div className='flex items-center mb-4'>
        <Link href="/dashboard">
          <Button variant="ghost"><ArrowLeft className="mr-2 h-4 w-4" /> Voltar ao Dashboard</Button>
        </Link>
      </div>
      <h1 className="text-2xl font-bold">Configurações</h1>
      <p>
        Aqui você pode configurar suas preferências de notificação, como email e alertas.
      </p>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="emailNotifications">Notificações por E-mail</Label>
          <Switch
            id="emailNotifications"
            checked={settings.emailNotifications}
            onCheckedChange={(checked) => handleChange('emailNotifications', checked)}
          />
        </div>
        <div>
          <Label htmlFor="alertThreshold">Limite de Alerta (%)</Label>
          <Input
            type="number"
            id="alertThreshold"
            value={settings.alertThreshold}
            onChange={(e) => handleChange('alertThreshold', parseInt(e.target.value))}
            min="0"
            max="100"
          />
        </div>
        <div>
          <Label htmlFor="dataRetentionDays">Retenção de Dados (dias)</Label>
          <Input
            type="number"
            id="dataRetentionDays"
            value={settings.dataRetentionDays}
            onChange={(e) => handleChange('dataRetentionDays', parseInt(e.target.value))}
            min="1"
          />
        </div>
        <div>
          <Label htmlFor="backupFrequency">Frequência de Backup</Label>
          <Select
            id="backupFrequency"
            value={settings.backupFrequency}
            onValueChange={(value) => handleChange('backupFrequency', value)}
            options={[
              { value: 'daily', label: 'Diário' },
              { value: 'weekly', label: 'Semanal' },
              { value: 'monthly', label: 'Mensal' },
            ]}
          />
        </div>
        <div className="flex items-center justify-between">
          <Label htmlFor="darkMode">Modo Escuro</Label>
          <Switch
            id="darkMode"
            checked={settings.darkMode}
            onCheckedChange={(checked) => handleChange('darkMode', checked)}
          />
        </div>
        <Button type="submit">Salvar Configurações</Button>
      </form>
    </div>
  )
}

