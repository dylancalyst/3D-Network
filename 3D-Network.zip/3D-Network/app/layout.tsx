import './globals.css'
import { Inter } from 'next/font/google'
import { ThemeProvider } from 'next-themes'
import { ThemeToggle } from "@/components/theme-toggle"
import { SessionProvider } from "next-auth/react"

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: '3D Network Monitor',
  description: 'Sistema de monitoramento de rede com mapeamento e topologia 3D',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>
        <SessionProvider>
          <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
            <div className="flex justify-end p-4">
              <ThemeToggle />
            </div>
            {children}
          </ThemeProvider>
        </SessionProvider>
      </body>
    </html>
  )
}

