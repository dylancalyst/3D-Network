'use client'

import { useState, useEffect } from 'react'
import { Dashboard } from '@/components/Dashboard'
import NetworkMap3D from '@/components/NetworkMap3D'
import RealTimeNetworkStats from '@/components/RealTimeNetworkStats'
import BGPInfo from '@/components/BGPInfo'
import { Button } from "@/components/ui/button"
import { RefreshCw, AlertTriangle, GlobeIcon as GlobeAlt } from 'lucide-react'
import Link from 'next/link'
import { Alert } from '@/types/alert'
import { cn } from '@/lib/utils'
import { motion } from 'framer-motion'

// Styles for the node legend items
const legendItemStyles = cn(
  'flex items-center space-x-2 mb-2',
  'focus-within:ring-2 focus-within:ring-inset focus-within:ring-blue-500', // Focus styles
  'hover:bg-gray-100 rounded', // Hover effect
  'p-2' // Padding
)

const Legend = () => (
  <div className="bg-white p-4 rounded shadow-lg dark:bg-gray-800">
    <h3 className="text-lg font-bold mb-2">Legenda</h3>
    <div className="grid grid-cols-2 gap-2">
      <div className={legendItemStyles} tabIndex={0} aria-label="Roteador: Nó verde">
        <div className="w-4 h-4 rounded-full bg-green-500 mr-2"></div>
        <span>Roteador</span>
      </div>
      <div className={legendItemStyles} tabIndex={0} aria-label="Switch: Nó azul">
        <div className="w-4 h-4 rounded-full bg-blue-500 mr-2"></div>
        <span>Switch</span>
      </div>
      <div className={legendItemStyles} tabIndex={0} aria-label="Servidor: Nó amarelo">
        <div className="w-4 h-4 rounded-full bg-yellow-500 mr-2"></div>
        <span>Servidor</span>
      </div>
      <div className={legendItemStyles} tabIndex={0} aria-label="Firewall: Nó laranja escuro">
        <div className="w-4 h-4 rounded-full bg-orange-500 mr-2"></div>
        <span>Firewall</span>
      </div>
      <div className={legendItemStyles} tabIndex={0} aria-label="Endpoint: Nó roxo">
        <div className="w-4 h-4 rounded-full bg-purple-500 mr-2"></div>
        <span>Endpoint</span>
      </div>
      <div className={legendItemStyles} tabIndex={0} aria-label="Offline: Nó vermelho">
        <div className="w-4 h-4 rounded-full bg-red-500 mr-2"></div>
        <span>Offline</span>
      </div>
    </div>
  </div>
)

export default function Home() {
  const [key, setKey] = useState(0)
  const [recentAlerts, setRecentAlerts] = useState<Alert[]>([])
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const fetchRecentAlerts = async () => {
      try {
        const response = await fetch('/api/alerts')
        if (response.ok) {
          const data = await response.json()
          setRecentAlerts(data.slice(0, 5)) // Display up to 5 recent alerts
        }
      } catch (error) {
        console.error('Failed to fetch recent alerts:', error)
      }
    }

    fetchRecentAlerts()
    const interval = setInterval(fetchRecentAlerts, 60000) // Fetch every minute
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  const handleRefresh = () => {
    setKey(prevKey => prevKey + 1)
  }

  return (
    <main className="flex min-h-screen flex-col items-center p-8 dark:bg-gray-900">
      <h1 className="text-4xl font-bold mb-4 dark:text-white">3D Network Monitor</h1>
      <motion.div
        initial={{ rotate: 0 }}
        animate={{ rotate: 360 }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "linear",
        }}
        style={{ display: 'inline-flex', width: '2.5rem', height: '2.5rem' }}
      >
        <GlobeAlt className="w-full h-full text-blue-500" />
      </motion.div>
      <p className="text-xl text-muted-foreground mb-8 dark:text-gray-300">
        Monitoramento de rede em tempo real com visualização 3D [^2] - {currentTime.toLocaleString()}
      </p>
      
      <div className="w-full max-w-7xl space-y-8">
        <div className="bg-white p-6 rounded-lg shadow-lg dark:bg-gray-800">
          <h2 className="text-2xl font-bold mb-4 dark:text-white">Introdução</h2>
          <p className="dark:text-gray-300">Bem-vindo ao 3D Network Monitor! Este guia irá te auxiliar nos seus primeiros passos. [^2]</p>
          <h3 className="text-xl font-semibold mt-4 mb-2 dark:text-white">Login</h3>
          <ol className="list-decimal pl-6 dark:text-gray-300">
            <li>Acesse o 3D Network Monitor através do URL fornecido.</li>
            <li>Insira seu nome de usuário e senha na tela de login.</li>
            <li>Em caso de primeiro acesso, altere sua senha.</li>
          </ol>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg dark:bg-gray-800">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold dark:text-white">Mapa de Rede 3D</h2>
            <Button onClick={handleRefresh}>
              <RefreshCw className="mr-2 h-4 w-4" /> Atualizar
            </Button>
          </div>
          <div className="relative">
            <NetworkMap3D key={key} />
            <div className="absolute bottom-4 left-4">
              <Legend />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg dark:bg-gray-800">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold dark:text-white">Alertas Recentes</h2>
            <Link href="/dashboard/alerts">
              <Button>Ver Todos os Alertas</Button>
            </Link>
          </div>
          <ul>
            {recentAlerts.map((alert) => (
              <li key={alert.id} className="flex items-center space-x-2 mb-2">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                <span className="dark:text-gray-300">{alert.message}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg dark:bg-gray-800">
          <h2 className="text-2xl font-bold mb-4 dark:text-white">Estatísticas de Rede em Tempo Real</h2>
          <RealTimeNetworkStats />
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg dark:bg-gray-800">
          <h2 className="text-2xl font-bold mb-4 dark:text-white">Dashboard</h2>
          <Dashboard />
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg dark:bg-gray-800">
          <h2 className="text-2xl font-bold mb-4 dark:text-white">Informações BGP</h2>
          <BGPInfo />
        </div>
      </div>
    </main>
  )
}

