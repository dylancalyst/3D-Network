'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'

interface BGPPeer {
 ip: string
 asn: number
 status: string
 routesReceived: number
 routesAdvertised: number
}

interface BGPRoute {
 prefix: string
 nextHop: string
 asn: number
}

interface BGPData {
 peers: BGPPeer[]
 routes: BGPRoute[]
}

export default function BGPInfo() {
 const [bgpData, setBgpData] = useState<BGPData | null>(null)

 useEffect(() => {
   const fetchBgpData = async () => {
     const response = await fetch('/api/bgp-data')
     const data = await response.json()
     setBgpData(data)
   }

   fetchBgpData()
   const interval = setInterval(fetchBgpData, 5000) // Update every 5 seconds
   return () => clearInterval(interval)
 }, [])

 if (!bgpData || !bgpData.peers || !bgpData.routes) return <div>Loading BGP data...</div>

 return (
   <Card>
     <CardHeader>
       <CardTitle>BGP Information</CardTitle>
     </CardHeader>
     <CardContent>
       <h3 className="text-lg font-bold mb-2">Peers</h3>
       <Table>
         <TableHeader>
           <TableRow>
             <TableHead>IP</TableHead>
             <TableHead>ASN</TableHead>
             <TableHead>Status</TableHead>
             <TableHead>Routes Received</TableHead>
             <TableHead>Routes Advertised</TableHead>
           </TableRow>
         </TableHeader>
         <TableBody>
           {bgpData.peers.map((peer) => (
             <TableRow key={peer.ip}>
               <TableCell>{peer.ip}</TableCell>
               <TableCell>{peer.asn}</TableCell>
               <TableCell>
                 <Badge variant={peer.status === 'up' ? 'success' : 'destructive'}>
                   {peer.status}
                 </Badge>
               </TableCell>
               <TableCell>{peer.routesReceived}</TableCell>
               <TableCell>{peer.routesAdvertised}</TableCell>
             </TableRow>
           ))}
         </TableBody>
       </Table>

       <h3 className="text-lg font-bold mt-4 mb-2">Routes</h3>
       <Table>
         <TableHeader>
           <TableRow>
             <TableHead>Prefix</TableHead>
             <TableHead>Next Hop</TableHead>
             <TableHead>ASN</TableHead>
           </TableRow>
         </TableHeader>
         <TableBody>
           {bgpData.routes.map((route) => (
             <TableRow key={route.prefix}>
               <TableCell>{route.prefix}</TableCell>
               <TableCell>{route.nextHop}</TableCell>
               <TableCell>{route.asn}</TableCell>
             </TableRow>
           ))}
         </TableBody>
       </Table>
     </CardContent>
   </Card>
 )
}

