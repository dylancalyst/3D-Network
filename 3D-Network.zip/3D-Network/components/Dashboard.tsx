'use client'

import React, { useEffect, useState, Suspense, lazy } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { Activity, Wifi, Server, AlertTriangle, Cpu, HardDrive, Network, Loader2 } from 'lucide-react'
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"

const NetworkMap = lazy(() => import('@/components/NetworkMap3D'))
const RealTimeNetworkStats = lazy(() => import('@/components/RealTimeNetworkStats'))
const BGPInfo = lazy(() => import('@/components/BGPInfo'))
const NetworkHealthMonitor = lazy(() => import('@/components/NetworkHealthMonitor'))

type MetricData = {
  count: number
  change: number
  details: Array<{ [key: string]: string | number }>
}

type DashboardData = {
  activeDevices: MetricData
  monitoredServers: MetricData
  activeAlerts: MetricData
  networkTraffic: MetricData & { total: number }
  cpuUsage: number
  memoryUsage: number
  diskUsage: number
  trafficOverview: Array<{ name: string, total: number }>
}

function MetricCard({ title, value, change, icon: Icon, details }: { 
  title: string
  value: number | string
  change: number
  icon: React.ElementType
  details: Array<{ [key: string]: string | number }>
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">
          {change >= 0 ? '+' : ''}{change}% em relação ao mês passado
        </p>
        <Dialog>
          <DialogTrigger asChild>
            <Button variant="outline" className="mt-2">Ver Detalhes</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>{title} - Detalhes</DialogTitle>
              <DialogDescription>
                Breakdown of {title.toLowerCase()}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              {details.map((item, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span>{Object.keys(item)[0]}</span>
                  <span className="font-semibold">{Object.values(item)[0]}</span>
                </div>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}

function ResourceUsageCard({ title, value, icon: Icon }: {
  title: string
  value: number
  icon: React.ElementType
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}%</div>
        <Progress value={value} className="mt-2" />
      </CardContent>
    </Card>
  )
}

export function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null)

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch('/api/dashboard-metrics')
      const jsonData = await response.json()
      setData(jsonData)
    }

    fetchData()
    const interval = setInterval(fetchData, 60000) // Refresh every minute

    return () => clearInterval(interval)
  }, [])

  if (!data || !data.trafficOverview) return <div>Loading dashboard data...</div>

  return (
    <div className="space-y-4">
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="traffic">Tráfego</TabsTrigger>
          <TabsTrigger value="resources">Recursos</TabsTrigger>
          <TabsTrigger value="health">Saúde da Rede</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <MetricCard
              title="Dispositivos Ativos"
              value={data.activeDevices.count}
              change={data.activeDevices.change}
              icon={Wifi}
              details={data.activeDevices.details}
            />
            <MetricCard
              title="Servidores Monitorados"
              value={data.monitoredServers.count}
              change={data.monitoredServers.change}
              icon={Server}
              details={data.monitoredServers.details}
            />
            <MetricCard
              title="Alertas Ativos"
              value={data.activeAlerts.count}
              change={data.activeAlerts.change}
              icon={AlertTriangle}
              details={data.activeAlerts.details}
            />
            <MetricCard
              title="Tráfego de Rede"
              value={`${data.networkTraffic.total} GB`}
              change={data.networkTraffic.change}
              icon={Activity}
              details={data.networkTraffic.details}
            />
          </div>
        </TabsContent>
        <TabsContent value="traffic">
          <Card>
            <CardHeader>
              <CardTitle>Visão Geral do Tráfego</CardTitle>
            </CardHeader>
            <CardContent className="pl-2">
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={data.trafficOverview}>
                  <XAxis
                    dataKey="name"
                    stroke="#888888"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    stroke="#888888"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => `${value} GB`}
                  />
                  <Bar dataKey="total" fill="#adfa1d" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
          <Suspense fallback={<Loader2 className="h-8 w-8 animate-spin" />}>
            <NetworkMap />
          </Suspense>
          <Suspense fallback={<Loader2 className="h-8 w-8 animate-spin" />}>
            <RealTimeNetworkStats />
          </Suspense>
          <Suspense fallback={<Loader2 className="h-8 w-8 animate-spin" />}>
            <BGPInfo />
          </Suspense>
        </TabsContent>
        <TabsContent value="resources" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <ResourceUsageCard
              title="Uso de CPU"
              value={data.cpuUsage}
              icon={Cpu}
            />
            <ResourceUsageCard
              title="Uso de Memória"
              value={data.memoryUsage}
              icon={HardDrive}
            />
            <ResourceUsageCard
              title="Uso de Disco"
              value={data.diskUsage}
              icon={Network}
            />
          </div>
        </TabsContent>
        <TabsContent value="health">
          <Suspense fallback={<Loader2 className="h-8 w-8 animate-spin" />}>
            <NetworkHealthMonitor />
          </Suspense>
        </TabsContent>
      </Tabs>
    </div>
  )
}

