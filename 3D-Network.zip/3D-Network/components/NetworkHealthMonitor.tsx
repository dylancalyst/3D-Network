'use client'

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Loader2, CheckCircle, XCircle, AlertTriangle } from 'lucide-react'

interface HealthStatus {
  overall: 'good' | 'warning' | 'critical'
  cpu: number
  memory: number
  disk: number
  network: number
  activeConnections: number
  latency: number
}

const NetworkHealthMonitor: React.FC = () => {
  const [health, setHealth] = useState<HealthStatus | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchHealthStatus = async () => {
      try {
        const response = await fetch('/api/network-health')
        if (!response.ok) throw new Error('Failed to fetch network health status')
        const data = await response.json()
        setHealth(data)
      } catch (err) {
        setError('Failed to fetch network health status')
      } finally {
        setLoading(false)
      }
    }

    fetchHealthStatus()
    const interval = setInterval(fetchHealthStatus, 60000) // Update every minute

    return () => clearInterval(interval)
  }, [])

  if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="h-8 w-8 animate-spin" /></div>
  if (error) return <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>
  if (!health) return null

  const getStatusIcon = (status: 'good' | 'warning' | 'critical') => {
    switch (status) {
      case 'good':
        return <CheckCircle className="h-6 w-6 text-green-500" />
      case 'warning':
        return <AlertTriangle className="h-6 w-6 text-yellow-500" />
      case 'critical':
        return <XCircle className="h-6 w-6 text-red-500" />
    }
  }

  const getStatusColor = (value: number) => {
    if (value < 70) return 'bg-green-100 text-green-800'
    if (value < 90) return 'bg-yellow-100 text-yellow-800'
    return 'bg-red-100 text-red-800'
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <span>Network Health</span>
          {getStatusIcon(health.overall)}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span>CPU Usage</span>
              <Badge className={getStatusColor(health.cpu)}>{health.cpu}%</Badge>
            </div>
            <Progress value={health.cpu} className="w-full" />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span>Memory Usage</span>
              <Badge className={getStatusColor(health.memory)}>{health.memory}%</Badge>
            </div>
            <Progress value={health.memory} className="w-full" />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span>Disk Usage</span>
              <Badge className={getStatusColor(health.disk)}>{health.disk}%</Badge>
            </div>
            <Progress value={health.disk} className="w-full" />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span>Network Usage</span>
              <Badge className={getStatusColor(health.network)}>{health.network}%</Badge>
            </div>
            <Progress value={health.network} className="w-full" />
          </div>
          <div className="flex justify-between items-center">
            <span>Active Connections</span>
            <Badge variant="outline">{health.activeConnections}</Badge>
          </div>
          <div className="flex justify-between items-center">
            <span>Average Latency</span>
            <Badge variant="outline">{health.latency} ms</Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default React.memo(NetworkHealthMonitor)

