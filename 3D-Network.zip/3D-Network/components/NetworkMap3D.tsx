'use client'

import React, { useRef, useEffect, useState, useCallback } from 'react'
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Loader2, ZoomIn, ZoomOut, RotateCw } from 'lucide-react'

interface NetworkNode {
  id: string
  name: string
  type: string
  status: string
  x: number
  y: number
  z: number
  load: number
}

interface NetworkLink {
  source: string
  target: string
  status: string
}

interface NetworkData {
  nodes: NetworkNode[]
  links: NetworkLink[]
}

const NetworkMap3D: React.FC = React.memo(() => {
  const mountRef = useRef<HTMLDivElement>(null)
  const [networkData, setNetworkData] = useState<NetworkData | null>(null)
  const [selectedNode, setSelectedNode] = useState<NetworkNode | null>(null)
  const [hoveredNode, setHoveredNode] = useState<NetworkNode | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchNetworkData = async () => {
      setLoading(true)
      try {
        const response = await fetch('/api/network-data')
        const data = await response.json()
        setNetworkData(data)
      } catch (error) {
        console.error('Error fetching network data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchNetworkData()
    const interval = setInterval(fetchNetworkData, 5000) // Fetch every 5 seconds

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (!mountRef.current || !networkData) return

    const width = mountRef.current.clientWidth
    const height = mountRef.current.clientHeight

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000)
    const renderer = new THREE.WebGLRenderer({ antialias: true })
    const labelRenderer = new CSS2DRenderer()

    renderer.setSize(width, height)
    labelRenderer.setSize(width, height)
    mountRef.current.appendChild(renderer.domElement)
    mountRef.current.appendChild(labelRenderer.domElement)

    const controls = new OrbitControls(camera, labelRenderer.domElement)

    const getNodeColor = (type: string, status: string) => {
      if (status === 'offline') return 0xff0000 // Red for offline
      if (status === 'warning') return 0xffa500 // Orange for warning
      switch (type) {
        case 'router': return 0x4CAF50 // Green
        case 'switch': return 0x2196F3 // Blue
        case 'server': return 0xFFC107 // Yellow
        case 'firewall': return 0xFF5722 // Deep Orange
        case 'endpoint': return 0x9C27B0 // Purple
        default: return 0xBDBDBD // Grey
      }
    }

    const getLinkColor = (status: string) => {
      switch (status) {
        case 'normal': return 0xffffff // White
        case 'warning': return 0xffa500 // Orange
        case 'down': return 0xff0000 // Red
        default: return 0xBDBDBD // Grey
      }
    }

    const nodeObjects: { [key: string]: THREE.Mesh } = {}
    const linkObjects: THREE.Line[] = []

    if (networkData.nodes && networkData.links) {
      networkData.nodes.forEach((node) => {
        const geometry = new THREE.SphereGeometry(0.3, 32, 32)
        const material = new THREE.MeshBasicMaterial({ color: getNodeColor(node.type, node.status) })
        const nodeMesh = new THREE.Mesh(geometry, material)
        nodeMesh.position.set(node.x, node.y, node.z)
        scene.add(nodeMesh)
        nodeObjects[node.id] = nodeMesh

        const nodeDiv = document.createElement('div')
        nodeDiv.className = 'label'
        nodeDiv.textContent = node.name
        nodeDiv.style.pointerEvents = 'none' // Prevent labels from blocking raycasting
        const nodeLabel = new CSS2DObject(nodeDiv)
        nodeLabel.position.set(0, 0.5, 0)
        nodeMesh.add(nodeLabel)
      })

      networkData.links.forEach((link) => {
        const sourceNode = nodeObjects[link.source]
        const targetNode = nodeObjects[link.target]
        if (sourceNode && targetNode) {
          const points = []
          points.push(sourceNode.position)
          points.push(targetNode.position)
          const lineGeometry = new THREE.BufferGeometry().setFromPoints(points)
          const lineMaterial = new THREE.LineBasicMaterial({ color: getLinkColor(link.status) })
          const line = new THREE.Line(lineGeometry, lineMaterial)
          scene.add(line)
          linkObjects.push(line)
        }
      })
    }

    camera.position.z = 5

    const raycaster = new THREE.Raycaster()
    const mouse = new THREE.Vector2()

    const onMouseMove = useCallback((event: MouseEvent) => {
      const rect = mountRef.current!.getBoundingClientRect()
      mouse.x = ((event.clientX - rect.left) / width) * 2 - 1
      mouse.y = -((event.clientY - rect.top) / height) * 2 + 1

      raycaster.setFromCamera(mouse, camera)
      const intersects = raycaster.intersectObjects(Object.values(nodeObjects))

      if (intersects.length > 0) {
        document.body.style.cursor = 'pointer'
        const intersectedNodeMesh = intersects[0].object as THREE.Mesh
        const hoveredNode = networkData.nodes.find(node => nodeObjects[node.id] === intersectedNodeMesh)
        setHoveredNode(hoveredNode || null)

        // Highlight connected nodes and links
        if (hoveredNode) {
          const connectedLinks = networkData.links.filter(
            link => link.source === hoveredNode.id || link.target === hoveredNode.id
          )
          connectedLinks.forEach(link => {
            const linkObject = linkObjects.find(
              obj => obj.geometry.attributes.position.array[0] === nodeObjects[link.source].position.x &&
                     obj.geometry.attributes.position.array[1] === nodeObjects[link.source].position.y &&
                     obj.geometry.attributes.position.array[2] === nodeObjects[link.source].position.z &&
                     obj.geometry.attributes.position.array[3] === nodeObjects[link.target].position.x &&
                     obj.geometry.attributes.position.array[4] === nodeObjects[link.target].position.y &&
                     obj.geometry.attributes.position.array[5] === nodeObjects[link.target].position.z
            )
            if (linkObject) {
              (linkObject.material as THREE.LineBasicMaterial).color.setHex(0x00ff00) // Highlight in green
            }
          })
        }
      } else {
        document.body.style.cursor = 'default'
        setHoveredNode(null)
        // Reset link colors
        linkObjects.forEach(link => {
          (link.material as THREE.LineBasicMaterial).color.setHex(0xffffff)
        })
      }
    }, [networkData, nodeObjects, linkObjects, camera])

    const onClick = useCallback((event: MouseEvent) => {
      const rect = mountRef.current!.getBoundingClientRect()
      mouse.x = ((event.clientX - rect.left) / width) * 2 - 1
      mouse.y = -((event.clientY - rect.top) / height) * 2 + 1

      raycaster.setFromCamera(mouse, camera)
      const intersects = raycaster.intersectObjects(Object.values(nodeObjects))

      if (intersects.length > 0) {
        const clickedNodeMesh = intersects[0].object as THREE.Mesh
        const clickedNode = networkData.nodes.find(node => nodeObjects[node.id] === clickedNodeMesh)
        if (clickedNode) {
          setSelectedNode(clickedNode)
        }
      } else {
        setSelectedNode(null)
      }
    }, [nodeObjects, networkData])

    window.addEventListener('mousemove', onMouseMove)
    window.addEventListener('click', onClick)

    const animate = () => {
      requestAnimationFrame(animate)
      controls.update()
      renderer.render(scene, camera)
      labelRenderer.render(scene, camera)
    }

    animate()

    const handleResize = () => {
      const newWidth = mountRef.current?.clientWidth || width
      const newHeight = mountRef.current?.clientHeight || height
      camera.aspect = newWidth / newHeight
      camera.updateProjectionMatrix()
      renderer.setSize(newWidth, newHeight)
      labelRenderer.setSize(newWidth, newHeight)
    }

    window.addEventListener('resize', handleResize)

    return () => {
      window.removeEventListener('resize', handleResize)
      window.removeEventListener('mousemove', onMouseMove)
      window.removeEventListener('click', onClick)
      mountRef.current?.removeChild(renderer.domElement)
      mountRef.current?.removeChild(labelRenderer.domElement)
    }
  }, [networkData])

  const resetCamera = useCallback(() => {
    if (mountRef.current) {
      const camera = mountRef.current.querySelector('canvas')?.__three_camera as THREE.PerspectiveCamera;
      if (camera) {
        camera.position.set(0, 0, 5);
        camera.lookAt(0, 0, 0);
      }
    }
  }, [])

  const zoomIn = useCallback(() => {
    if (mountRef.current) {
      const camera = mountRef.current.querySelector('canvas')?.__three_camera as THREE.PerspectiveCamera;
      if (camera) {
        camera.position.z *= 0.9;
      }
    }
  }, [])

  const zoomOut = useCallback(() => {
    if (mountRef.current) {
      const camera = mountRef.current.querySelector('canvas')?.__three_camera as THREE.PerspectiveCamera;
      if (camera) {
        camera.position.z *= 1.1;
      }
    }
  }, [])

  return (
    <Card className="w-full h-[600px]">
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>Mapa de Rede 3D</span>
          <div>
            <Button onClick={zoomIn} className="mr-2"><ZoomIn className="h-4 w-4" /></Button>
            <Button onClick={zoomOut} className="mr-2"><ZoomOut className="h-4 w-4" /></Button>
            <Button onClick={resetCamera}><RotateCw className="h-4 w-4" /></Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="h-6 w-6 animate-spin text-gray-500" />
          </div>
        ) : (
          <div className="relative w-full h-full">
            <div ref={mountRef} className="w-full h-full" />
            {hoveredNode && (
              <div className="absolute top-0 left-0 bg-black bg-opacity-75 text-white p-2 rounded">
                <p>{hoveredNode.name}</p>
                <p>Tipo: {hoveredNode.type}</p>
                <p>Status: {hoveredNode.status}</p>
              </div>
            )}
            {selectedNode && (
              <Card className="absolute top-4 right-4 w-64">
                <CardHeader>
                  <CardTitle>{selectedNode.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Tipo: {selectedNode.type}</p>
                  <p>Status: <Badge variant={selectedNode.status === 'online' ? 'success' : 'destructive'}>{selectedNode.status}</Badge></p>
                  <p>Carga: {selectedNode.load.toFixed(2)}%</p>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
})

export default NetworkMap3D

