'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { useTheme } from 'next-themes'

interface NetworkStats {
  timestamp: number
  bandwidth: number
  latency: number
  packetLoss: number
}

const RealTimeNetworkStats: React.FC = () => {
  const [stats, setStats] = useState<NetworkStats[]>([])
  const { theme } = useTheme()

  const fetchStats = useCallback(async () => {
    try {
      const response = await fetch('/api/network-stats')
      const data = await response.json()
      setStats(prevStats => [...prevStats, data].slice(-20)) // Keep last 20 data points
    } catch (error) {
      console.error('Error fetching network stats:', error)
    }
  }, [])

  useEffect(() => {
    fetchStats()
    const interval = setInterval(fetchStats, 1000) // Fetch every second

    return () => {
      clearInterval(interval) // Clear the interval when the component unmounts
    }
  }, [fetchStats])

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString()
  }

  return (
    <Card className="w-full h-[400px]">
      <CardHeader>
        <CardTitle>Estatísticas de Rede em Tempo Real</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={stats}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis
              dataKey="timestamp"
              tickFormatter={formatTimestamp}
              style={{ fontSize: '12px' }}
            />
            <YAxis yAxisId="left" style={{ fontSize: '12px' }} />
            <YAxis yAxisId="right" orientation="right" style={{ fontSize: '12px' }} />
            <Tooltip
              labelFormatter={(timestamp) => formatTimestamp(timestamp)}
              contentStyle={{ backgroundColor: theme === 'dark' ? '#1F2937' : '#FFFFFF', border: 'none' }}
            />
            <Legend />
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="bandwidth"
              stroke="#8884d8"
              name="Largura de Banda (Mbps)"
              dot={false}
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="latency"
              stroke="#82ca9d"
              name="Latência (ms)"
              dot={false}
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="packetLoss"
              stroke="#ffc658"
              name="Perda de Pacotes (%)"
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

export default React.memo(RealTimeNetworkStats)

