import { useState } from 'react'
import { Button } from '@/components/ui/button'
import {
 Dialog,
 DialogContent,
 DialogHeader,
 DialogTitle,
 DialogTrigger, DialogFooter,
} from '@/components/ui/dialog'
import {
 Select,
 SelectContent,
 SelectItem,
 SelectTrigger,
 SelectValue,
} from '@/components/ui/select'

type AddDashboardItemProps = {
 onAddItem: (itemType: string) => void
 availableItems: { id: string; title: string }[]
}

export function AddDashboardItem({ onAddItem, availableItems }: AddDashboardItemProps) {
 const [selectedItem, setSelectedItem] = useState<string | undefined>()
 const [showConfirm, setShowConfirm] = useState(false)

 const handleAddItem = () => {
   if (selectedItem) {
     setShowConfirm(true) // Show confirmation dialog
   }
 }

 const confirmAddItem = () => {
   if (selectedItem) {
     onAddItem(selectedItem)
     setSelectedItem(undefined)
     setShowConfirm(false)
   }
 }

 return (
   <>
     <Dialog open={showConfirm} onOpenChange={() => setShowConfirm(false)}>
       <DialogContent className="sm:max-w-[425px]">
         <DialogHeader>
           <DialogTitle>Confirm Add Item</DialogTitle>
         </DialogHeader>
         <div className="grid gap-4 py-4">
           <p>Are you sure you want to add this item to the dashboard?</p>
           <DialogFooter>
             <Button type="button" variant="secondary" onClick={() => setShowConfirm(false)}>
               Cancel
             </Button>
             <Button type="button" onClick={confirmAddItem}>
               Confirm
             </Button>
           </DialogFooter>
         </div>
       </DialogContent>
     </Dialog>
     <Dialog>
       <DialogTrigger asChild>
         <Button variant="outline">Add Dashboard Item</Button>
       </DialogTrigger>
       <DialogContent className="sm:max-w-[425px]">
         <DialogHeader>
           <DialogTitle>Add Dashboard Item</DialogTitle>
         </DialogHeader>
         <div className="grid gap-4 py-4">
           <Select onValueChange={setSelectedItem} value={selectedItem}>
             <SelectTrigger>
               <SelectValue placeholder="Select an item to add" />
             </SelectTrigger>
             <SelectContent>
               {availableItems.map((item) => (
                 <SelectItem key={item.id} value={item.id}>
                   {item.title}
                 </SelectItem>
               ))}
             </SelectContent>
           </Select>
           <Button onClick={handleAddItem} disabled={!selectedItem}>
             Add Item
           </Button>
         </div>
       </DialogContent>
     </Dialog>
   </>
 )
}

