import { useState, useEffect } from 'react'
import { Responsive, WidthProvider } from 'react-grid-layout'
import 'react-grid-layout/css/styles.css'
import 'react-resizable/css/styles.css'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { NetworkMap } from '@/components/network-map'
import { DeviceList } from '@/components/device-list'
import { AlertPanel } from '@/components/alert-panel'
import { NetworkStats } from '@/components/network-stats'
import { useSavedConfigurations } from '@/contexts/SavedConfigurationsContext'
import { AddDashboardItem } from '@/components/add-dashboard-item'
import { X, Info } from 'lucide-react'
import DeviceHealthMonitor from '@/components/device-health-monitor'

const ResponsiveGridLayout = WidthProvider(Responsive)

type DashboardItem = {
  i: string
  x: number
  y: number
  w: number
  h: number
  component: React.ReactNode
  title: string
  description: string
}

type AdminDashboardProps = {
  saveLayout: (layout: string) => void
}

const availableItems = [
  { id: 'network-map', title: 'Network Map', component: <NetworkMap />, description: 'Visualize your network topology' },
  { id: 'device-list', title: 'Device List', component: <DeviceList />, description: 'View and manage network devices' },
  { id: 'alert-panel', title: 'Alerts', component: <AlertPanel />, description: 'Monitor and respond to network alerts' },
  { id: 'network-stats', title: 'Network Statistics', component: <NetworkStats />, description: 'View key network performance metrics' },
  { id: 'device-health-monitor', title: 'Device Health Monitor', component: <DeviceHealthMonitor />, description: 'Monitor the health of network devices' },
]

export default function AdminDashboard({ saveLayout }: AdminDashboardProps) {
  const [layout, setLayout] = useState<DashboardItem[]>([
    { i: 'network-map', x: 0, y: 0, w: 6, h: 4, component: <NetworkMap />, title: 'Network Map', description: 'Visualize your network topology' },
    { i: 'device-list', x: 6, y: 0, w: 6, h: 4, component: <DeviceList />, title: 'Device List', description: 'View and manage network devices' },
    { i: 'alert-panel', x: 0, y: 4, w: 6, h: 4, component: <AlertPanel />, title: 'Alerts', description: 'Monitor and respond to network alerts' },
    { i: 'network-stats', x: 6, y: 4, w: 6, h: 4, component: <NetworkStats />, title: 'Network Statistics', description: 'View key network performance metrics' },
  ])

  const { currentConfig } = useSavedConfigurations()

  useEffect(() => {
    if (currentConfig) {
      try {
        const loadedLayout = JSON.parse(currentConfig.layout)
        setLayout(loadedLayout)
      } catch (error) {
        console.error('Error loading layout:', error)
      }
    }
  }, [currentConfig])

  const handleSaveLayout = () => {
    const layoutToSave = JSON.stringify(layout)
    saveLayout(layoutToSave)
  }

  const onLayoutChange = (newLayout: any) => {
    const updatedLayout = layout.map((item) => {
      const updatedItem = newLayout.find((layoutItem: any) => layoutItem.i === item.i)
      return { ...item, ...updatedItem }
    })
    setLayout(updatedLayout)
  }

  const handleAddItem = (itemId: string) => {
    const newItem = availableItems.find((item) => item.id === itemId)
    if (newItem) {
      const newLayoutItem: DashboardItem = {
        i: `${itemId}-${Date.now()}`,
        x: (layout.length * 2) % 12,
        y: Infinity,
        w: 6,
        h: 4,
        component: newItem.component,
        title: newItem.title,
        description: newItem.description,
      }
      setLayout([...layout, newLayoutItem])
    }
  }

  const handleRemoveItem = (itemId: string) => {
    setLayout(layout.filter((item) => item.i !== itemId))
  }

  return (
    <TooltipProvider>
      <div className="p-4">
        <div className="mb-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <div className="flex gap-2">
            <AddDashboardItem onAddItem={handleAddItem} availableItems={availableItems} />
            <Button onClick={handleSaveLayout}>Save Layout</Button>
          </div>
        </div>
        <ResponsiveGridLayout
          className="layout"
          layouts={{ lg: layout }}
          breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
          cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
          rowHeight={100}
          onLayoutChange={onLayoutChange}
        >
          {layout.map((item) => (
            <div key={item.i}>
              <Card className="h-full">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="flex items-center">
                    {item.title}
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="ghost" size="icon" className="ml-2 h-6 w-6">
                          <Info className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{item.description}</p>
                      </TooltipContent>
                    </Tooltip>
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemoveItem(item.i)}
                    className="h-6 w-6"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </CardHeader>
                <CardContent>{item.component}</CardContent>
              </Card>
            </div>
          ))}
        </ResponsiveGridLayout>
      </div>
    </TooltipProvider>
  )
}

