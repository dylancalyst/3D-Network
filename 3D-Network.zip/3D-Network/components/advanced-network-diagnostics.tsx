'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Loader2, AlertTriangle } from 'lucide-react'

export default function AdvancedNetworkDiagnostics() {
  const [target, setTarget] = useState('')
  const [tool, setTool] = useState('ping')
  const [result, setResult] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const runDiagnostic = async () => {
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      const response = await fetch('/api/admin/network-diagnostics', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}` // Assuming you store the JWT in localStorage
        },
        body: JSON.stringify({ tool, target }),
      })

      if (!response.ok) {
        throw new Error('Failed to run network diagnostic')
      }

      const data = await response.json()
      setResult(data.result)
    } catch (err) {
      setError('An error occurred while running diagnostics')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Advanced Network Diagnostics</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <Label htmlFor="target">Target IP or Hostname</Label>
            <Input
              id="target"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              placeholder="e.g., 192.168.1.1 or example.com"
            />
          </div>
          <div>
            <Label htmlFor="tool">Diagnostic Tool</Label>
            <select
              id="tool"
              value={tool}
              onChange={(e) => setTool(e.target.value)}
              className="w-full p-2 border rounded"
            >
              <option value="ping">Ping</option>
              <option value="traceroute">Traceroute</option>
              <option value="nslookup">NS Lookup</option>
              <option value="portscan">Port Scan</option>
            </select>
          </div>
          <Button onClick={runDiagnostic} disabled={loading || !target}>
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Run Diagnostic'}
          </Button>

          {error && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {result && (
            <div className="mt-4">
              <h3 className="text-lg font-semibold mb-2">Diagnostic Result:</h3>
              <pre className="bg-gray-100 p-4 rounded-lg overflow-x-auto">
                {result}
              </pre>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

