'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface Alert {
  id: string
  name: string
  metric: string
  threshold: number
  deviceId: string
}

export default function AlertManagement() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [newAlert, setNewAlert] = useState<Omit<Alert, 'id'>>({
    name: '',
    metric: 'cpuLoad',
    threshold: 0,
    deviceId: '',
  })
  const [devices, setDevices] = useState<{ id: string; name: string }[]>([])

  useEffect(() => {
    fetchAlerts()
    fetchDevices()
  }, [])

  const fetchAlerts = async () => {
    const response = await fetch('/api/alerts')
    const data = await response.json()
    setAlerts(data)
  }

  const fetchDevices = async () => {
    const response = await fetch('/api/devices')
    const data = await response.json()
    setDevices(data)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const response = await fetch('/api/alerts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newAlert),
    })
    if (response.ok) {
      fetchAlerts()
      setNewAlert({ name: '', metric: 'cpuLoad', threshold: 0, deviceId: '' })
    }
  }

  const handleDelete = async (id: string) => {
    const response = await fetch(`/api/alerts/${id}`, { method: 'DELETE' })
    if (response.ok) {
      fetchAlerts()
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Alert Management</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4 mb-6">
          <div>
            <Label htmlFor="name">Alert Name</Label>
            <Input
              id="name"
              value={newAlert.name}
              onChange={(e) => setNewAlert({ ...newAlert, name: e.target.value })}
              required
            />
          </div>
          <div>
            <Label htmlFor="metric">Metric</Label>
            <Select
              id="metric"
              value={newAlert.metric}
              onValueChange={(value) => setNewAlert({ ...newAlert, metric: value })}
              options={[
                { value: 'cpuLoad', label: 'CPU Load' },
                { value: 'memoryUsed', label: 'Memory Used' },
                { value: 'status', label: 'Status' },
              ]}
            />
          </div>
          <div>
            <Label htmlFor="threshold">Threshold</Label>
            <Input
              id="threshold"
              type="number"
              value={newAlert.threshold}
              onChange={(e) => setNewAlert({ ...newAlert, threshold: Number(e.target.value) })}
              required
            />
          </div>
          <div>
            <Label htmlFor="deviceId">Device</Label>
            <Select
              id="deviceId"
              value={newAlert.deviceId}
              onValueChange={(value) => setNewAlert({ ...newAlert, deviceId: value })}
              options={devices.map(device => ({ value: device.id, label: device.name }))}
            />
          </div>
          <Button type="submit">Add Alert</Button>
        </form>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Metric</TableHead>
              <TableHead>Threshold</TableHead>
              <TableHead>Device</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {alerts.map((alert) => (
              <TableRow key={alert.id}>
                <TableCell>{alert.name}</TableCell>
                <TableCell>{alert.metric}</TableCell>
                <TableCell>{alert.threshold}</TableCell>
                <TableCell>{devices.find(d => d.id === alert.deviceId)?.name}</TableCell>
                <TableCell>
                  <Button variant="destructive" onClick={() => handleDelete(alert.id)}>Delete</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

