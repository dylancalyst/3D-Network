'use client'

import { useEffect, useState } from 'react'
import { Alert as AlertType } from '@/types/alert'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { RefreshCw, Loader2 } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

interface AlertPanelProps {
 showAllAlerts?: boolean
}

export default function AlertPanel({ showAllAlerts = false }: AlertPanelProps) {
 const [alerts, setAlerts] = useState<AlertType[]>([])
 const [loading, setLoading] = useState(true)
 const [error, setError] = useState<string | null>(null)

 useEffect(() => {
   const fetchAlerts = async () => {
     setLoading(true)
     try {
       const response = await fetch('/api/alerts')
       if (!response.ok) {
         throw new Error('Failed to fetch alerts')
       }
       const data = await response.json()
       setAlerts(data)
     } catch (err) {
       setError('Failed to load alerts')
     } finally {
       setLoading(false)
     }
   }

   fetchAlerts()
   const interval = setInterval(fetchAlerts, 60000) // Fetch every minute

   return () => clearInterval(interval)
 }, [])

 const displayAlerts = showAllAlerts ? alerts : alerts.slice(0, 3)

 const handleRefresh = async () => {
   setLoading(true)
   setError(null)
   try {
     await fetch('/api/alerts')
   } catch (error) {
     setError('Failed to refresh alerts')
   } finally {
     setLoading(false)
   }
 }

 if (loading) {
   return <div className="flex justify-center items-center h-64"><Loader2 className="h-8 w-8 animate-spin" /></div>
 }

 if (error) {
   return <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>
 }

 if (alerts.length === 0) {
   return (
     <Alert>
       <AlertTitle>No Alerts</AlertTitle>
       <AlertDescription>There are currently no active alerts.</AlertDescription>
     </Alert>
   )
 }

 return (
   <Card>
     <CardHeader>
       <CardTitle className="flex justify-between items-center">
         Alertas
         <Button onClick={handleRefresh} disabled={loading} size="sm" variant="outline">
           {loading ? (
             <Loader2 className="mr-2 h-4 w-4 animate-spin" />
           ) : (
             <RefreshCw className="mr-2 h-4 w-4" />
           )}
           Atualizar
         </Button>
       </CardTitle>
     </CardHeader>
     <CardContent>
       <ul className="space-y-2">
         {displayAlerts.map((alert) => (
           <li key={alert.id} className="p-2 rounded border">
             <div className="flex items-center justify-between">
               <p className="font-medium">{alert.message}</p>
               <Badge variant={alert.severity === 'high' ? 'destructive' : alert.severity === 'medium' ? 'warning' : 'default'}>
                 {alert.severity}
               </Badge>
             </div>
             <p className="text-xs text-muted mt-1">{new Date(alert.timestamp).toLocaleString()}</p>
           </li>
         ))}
       </ul>
     </CardContent>
   </Card>
 )
}

