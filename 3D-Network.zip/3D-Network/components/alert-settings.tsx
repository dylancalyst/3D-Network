'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'

interface AlertRule {
  id: string
  name: string
  condition: string
  threshold: number
  severity: 'low' | 'medium' | 'high'
  enabled: boolean
}

export default function AlertSettings() {
  const [alertRules, setAlertRules] = useState<AlertRule[]>([])
  const [newRule, setNewRule] = useState<Omit<AlertRule, 'id'>>({
    name: '',
    condition: 'cpu_usage',
    threshold: 80,
    severity: 'medium',
    enabled: true,
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchAlertRules()
  }, [])

  const fetchAlertRules = async () => {
    try {
      const response = await fetch('/api/alert-rules')
      if (!response.ok) throw new Error('Failed to fetch alert rules')
      const data = await response.json()
      setAlertRules(data)
      setLoading(false)
    } catch (err) {
      setError('Failed to load alert rules')
      setLoading(false)
    }
  }

  const addAlertRule = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/alert-rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRule),
      })
      if (!response.ok) throw new Error('Failed to add alert rule')
      fetchAlertRules()
      setNewRule({
        name: '',
        condition: 'cpu_usage',
        threshold: 80,
        severity: 'medium',
        enabled: true,
      })
    } catch (err) {
      setError('Failed to add alert rule')
    }
  }

  const updateAlertRule = async (id: string, updates: Partial<AlertRule>) => {
    try {
      const response = await fetch(`/api/alert-rules/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      })
      if (!response.ok) throw new Error('Failed to update alert rule')
      fetchAlertRules()
    } catch (err) {
      setError('Failed to update alert rule')
    }
  }

  const deleteAlertRule = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this alert rule?')) {
      try {
        const response = await fetch(`/api/alert-rules/${id}`, { method: 'DELETE' })
        if (!response.ok) throw new Error('Failed to delete alert rule')
        fetchAlertRules()
      } catch (err) {
        setError('Failed to delete alert rule')
      }
    }
  }

  if (loading) return <div>Loading alert rules...</div>
  if (error) return <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Alert Settings</h2>
      <Card>
        <CardHeader>
          <CardTitle>Add New Alert Rule</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={addAlertRule} className="space-y-4">
            <div>
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={newRule.name}
                onChange={(e) => setNewRule({ ...newRule, name: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="condition">Condition</Label>
              <Select
                id="condition"
                value={newRule.condition}
                onValueChange={(value) => setNewRule({ ...newRule, condition: value })}
                options={[
                  { value: 'cpu_usage', label: 'CPU Usage' },
                  { value: 'memory_usage', label: 'Memory Usage' },
                  { value: 'disk_usage', label: 'Disk Usage' },
                  { value: 'network_latency', label: 'Network Latency' },
                ]}
              />
            </div>
            <div>
              <Label htmlFor="threshold">Threshold</Label>
              <Input
                id="threshold"
                type="number"
                value={newRule.threshold}
                onChange={(e) => setNewRule({ ...newRule, threshold: Number(e.target.value) })}
                required
              />
            </div>
            <div>
              <Label htmlFor="severity">Severity</Label>
              <Select
                id="severity"
                value={newRule.severity}
                onValueChange={(value: 'low' | 'medium' | 'high') => setNewRule({ ...newRule, severity: value })}
                options={[
                  { value: 'low', label: 'Low' },
                  { value: 'medium', label: 'Medium' },
                  { value: 'high', label: 'High' },
                ]}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="enabled"
                checked={newRule.enabled}
                onCheckedChange={(checked) => setNewRule({ ...newRule, enabled: checked })}
              />
              <Label htmlFor="enabled">Enabled</Label>
            </div>
            <Button type="submit">Add Alert Rule</Button>
          </form>
        </CardContent>
      </Card>
      <div className="space-y-4">
        <h3 className="text-xl font-semibold">Existing Alert Rules</h3>
        {alertRules.map((rule) => (
          <Card key={rule.id}>
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <span>{rule.name}</span>
                <Switch
                  checked={rule.enabled}
                  onCheckedChange={(checked) => updateAlertRule(rule.id, { enabled: checked })}
                />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p>Condition: {rule.condition}</p>
              <p>Threshold: {rule.threshold}</p>
              <p>Severity: {rule.severity}</p>
              <div className="mt-4 flex justify-end space-x-2">
                <Button variant="outline" onClick={() => deleteAlertRule(rule.id)}>Delete</Button>
                <Button onClick={() => updateAlertRule(rule.id, { ...rule })}>Update</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

