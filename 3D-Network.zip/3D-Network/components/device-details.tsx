'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Loader2, RefreshCw, Power, Activity } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface DeviceDetails {
  id: string
  name: string
  type: string
  ip: string
  status: string
  lastSeen: string
  cpuUsage: number
  memoryUsage: number
  diskUsage: number
  uptime: string
  firmwareVersion: string
}

interface PerformanceData {
  timestamp: number
  cpuUsage: number
  memoryUsage: number
  diskUsage: number
}

export default function DeviceDetails({ deviceId }: { deviceId: string }) {
  const [device, setDevice] = useState<DeviceDetails | null>(null)
  const [performanceData, setPerformanceData] = useState<PerformanceData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchDeviceDetails()
    fetchPerformanceData()
  }, [deviceId])

  const fetchDeviceDetails = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await fetch(`/api/devices/${deviceId}`)
      if (!response.ok) throw new Error('Failed to fetch device details')
      const data = await response.json()
      setDevice(data)
    } catch (err) {
      setError('Failed to fetch device details')
    } finally {
      setLoading(false)
    }
  }

  const fetchPerformanceData = async () => {
    try {
      const response = await fetch(`/api/devices/${deviceId}/performance`)
      if (!response.ok) throw new Error('Failed to fetch performance data')
      const data = await response.json()
      setPerformanceData(data)
    } catch (err) {
      console.error('Failed to fetch performance data:', err)
    }
  }

  const handleRefresh = () => {
    fetchDeviceDetails()
    fetchPerformanceData()
  }

  const handleReboot = async () => {
    try {
      const response = await fetch(`/api/devices/${deviceId}/reboot`, { method: 'POST' })
      if (!response.ok) throw new Error('Failed to reboot device')
      alert('Device reboot initiated')
    } catch (err) {
      console.error('Failed to reboot device:', err)
      alert('Failed to reboot device')
    }
  }

  if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="h-8 w-8 animate-spin" /></div>
  if (error) return <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>
  if (!device) return <div>Device not found</div>

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex justify-between items-center">
            <span>{device.name}</span>
            <Badge variant={device.status === 'online' ? 'success' : 'destructive'}>{device.status}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p><strong>Type:</strong> {device.type}</p>
              <p><strong>IP Address:</strong> {device.ip}</p>
              <p><strong>Last Seen:</strong> {new Date(device.lastSeen).toLocaleString()}</p>
              <p><strong>Uptime:</strong> {device.uptime}</p>
            </div>
            <div>
              <p><strong>CPU Usage:</strong> {device.cpuUsage}%</p>
              <p><strong>Memory Usage:</strong> {device.memoryUsage}%</p>
              <p><strong>Disk Usage:</strong> {device.diskUsage}%</p>
              <p><strong>Firmware Version:</strong> {device.firmwareVersion}</p>
            </div>
          </div>
          <div className="mt-4 flex space-x-2">
            <Button onClick={handleRefresh} size="sm">
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh
            </Button>
            <Button onClick={handleReboot} size="sm" variant="destructive">
              <Power className="mr-2 h-4 w-4" />
              Reboot
            </Button>
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Performance History</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="timestamp"
                tickFormatter={(timestamp) => new Date(timestamp).toLocaleTimeString()}
              />
              <YAxis />
              <Tooltip
                labelFormatter={(timestamp) => new Date(timestamp).toLocaleString()}
              />
              <Legend />
              <Line type="monotone" dataKey="cpuUsage" stroke="#8884d8" name="CPU Usage (%)" />
              <Line type="monotone" dataKey="memoryUsage" stroke="#82ca9d" name="Memory Usage (%)" />
              <Line type="monotone" dataKey="diskUsage" stroke="#ffc658" name="Disk Usage (%)" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}

