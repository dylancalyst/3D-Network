'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Loader2 } from 'lucide-react'

interface DeviceHealth {
  id: string
  name: string
  status: 'online' | 'offline'
  cpuUsage: number
  memoryUsage: number
  diskUsage: number
  lastChecked: string
}

export default function DeviceHealthMonitor() {
  const [devices, setDevices] = useState<DeviceHealth[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchDeviceHealth = async () => {
      try {
        const response = await fetch('/api/device-health')
        if (!response.ok) throw new Error('Failed to fetch device health status')
        const data = await response.json()
        setDevices(data)
      } catch (err) {
        setError('Failed to fetch device health status')
      } finally {
        setLoading(false)
      }
    }

    fetchDeviceHealth()
    const interval = setInterval(fetchDeviceHealth, 60000) // Update every minute

    return () => clearInterval(interval)
  }, [])

  if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="h-8 w-8 animate-spin" /></div>
  if (error) return <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>
  if (devices.length === 0) return <Alert><AlertTitle>No devices</AlertTitle><AlertDescription>No devices found in the network.</AlertDescription></Alert>

  return (
    <Card>
      <CardHeader>
        <CardTitle>Device Health Monitor</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Device</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>CPU</TableHead>
              <TableHead>Memory</TableHead>
              <TableHead>Disk</TableHead>
              <TableHead>Last Checked</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {devices.map((device) => (
              <TableRow key={device.id}>
                <TableCell>{device.name}</TableCell>
                <TableCell>
                  <Badge variant={device.status === 'online' ? 'success' : 'destructive'}>
                    {device.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Progress value={device.cpuUsage} className="w-[60px]" />
                    <span>{device.cpuUsage}%</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Progress value={device.memoryUsage} className="w-[60px]" />
                    <span>{device.memoryUsage}%</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Progress value={device.diskUsage} className="w-[60px]" />
                    <span>{device.diskUsage}%</span>
                  </div>
                </TableCell>
                <TableCell>{new Date(device.lastChecked).toLocaleString()}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

