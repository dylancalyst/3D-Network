'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { initializeWebSocket } from '@/utils/websocket'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Device } from '@/types/device'
import { RefreshCw, Loader2 } from 'lucide-react'

interface Device {
 id: string
 name: string
 status: string
 ip: string
 lastCheckin: string
 cpuUsage: number
 memoryUsage: number
 diskUsage: number
}

export default function DeviceList({ showDetails = false }) {
 const [devices, setDevices] = useState<Device[]>([])
 const [loading, setLoading] = useState(true)
 const [error, setError] = useState<string | null>(null)
 const [searchQuery, setSearchQuery] = useState('')
 const [filter, setFilter] = useState('all')
 const [sortBy, setSortBy] = useState('name')
 const [sortOrder, setSortOrder] = useState('asc')

 useEffect(() => {
   const fetchDevices = async () => {
     setLoading(true)
     try {
       const response = await fetch('/api/devices')
       if (!response.ok) {
         throw new Error('Failed to fetch devices')
       }
       const data = await response.json()
       setDevices(data)
     } catch (err) {
       setError('Failed to load devices')
     } finally {
       setLoading(false)
     }
   }

   fetchDevices()

   const socket = initializeWebSocket()
   socket.on('deviceUpdate', (updatedDevice) => {
     setDevices((prevDevices) =>
       prevDevices.map((device) =>
         device.id === updatedDevice.id ? { ...device, ...updatedDevice } : device
       )
     );
   });

   return () => {
     socket.off('deviceUpdate')
   }
 }, [])

 const filteredDevices = devices.filter(device =>
   device.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
   (filter === 'all' || device.status === filter)
 )

 const sortedDevices = [...filteredDevices].sort((a, b) => {
   const aValue = a[sortBy as keyof Device]
   const bValue = b[sortBy as keyof Device]

   if (typeof aValue === 'string' && typeof bValue === 'string') {
     return sortOrder === 'asc'
       ? aValue.localeCompare(bValue)
       : bValue.localeCompare(aValue)
   } else if (typeof aValue === 'number' && typeof bValue === 'number') {
     return sortOrder === 'asc' ? aValue - bValue : bValue - aValue
   }
   return 0
 })

 const handleRefresh = async () => {
   setLoading(true)
   setError(null)
   try {
     await fetch('/api/devices')
   } catch (error) {
     setError('Failed to refresh devices')
   } finally {
     setLoading(false)
   }
 }

 if (loading) {
   return <div className="flex justify-center items-center h-64"><Loader2 className="h-8 w-8 animate-spin" /></div>
 }

 if (error) {
   return <Alert variant="destructive"><AlertTitle>Erro</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>
 }

 return (
   <Card>
     <CardHeader>
       <CardTitle className="flex justify-between items-center">
         Lista de Dispositivos
         <Button onClick={handleRefresh} disabled={loading} size="sm" variant="outline">
           {loading ? (
             <Loader2 className="mr-2 h-4 w-4 animate-spin" />
           ) : (
             <RefreshCw className="mr-2 h-4 w-4" />
           )}
           Atualizar
         </Button>
       </CardTitle>
     </CardHeader>
     <CardContent>
       <div className="flex items-center space-x-4 mb-4">
         <Input
           placeholder="Pesquisar..."
           value={searchQuery}
           onChange={(e) => setSearchQuery(e.target.value)}
         />
         <Select value={filter} onValueChange={setFilter}>
           <SelectTrigger>
             <SelectValue placeholder="Filtrar por status" />
           </SelectTrigger>
           <SelectContent>
             <SelectItem value="all">Todos</SelectItem>
             <SelectItem value="online">Online</SelectItem>
             <SelectItem value="offline">Offline</SelectItem>
           </SelectContent>
         </Select>
         <Select value={sortBy} onValueChange={setSortBy}>
           <SelectTrigger>
             <SelectValue placeholder="Ordenar por" />
           </SelectTrigger>
           <SelectContent>
             <SelectItem value="name">Nome</SelectItem>
             <SelectItem value="status">Status</SelectItem>
             <SelectItem value="ip">IP</SelectItem>
           </SelectContent>
         </Select>
         <Button onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')} size="sm" variant="outline">
           {sortOrder === 'asc' ? 'Crescente' : 'Decrescente'}
         </Button>
       </div>
       <Table>
         <TableHeader>
           <TableRow>
             <TableHead>Nome</TableHead>
             <TableHead>Status</TableHead>
             <TableHead>IP</TableHead>
             {showDetails && <TableHead>Detalhes</TableHead>}
           </TableRow>
         </TableHeader>
         <TableBody>
           {sortedDevices.map((device) => (
             <TableRow key={device.id}>
               <TableCell><Link href={`/dashboard/devices/${device.id}`} className="hover:underline">{device.name}</Link></TableCell>
               <TableCell>
                 <Badge variant={device.status === 'online' ? 'success' : 'destructive'}>
                   {device.status}
                 </Badge>
               </TableCell>
               <TableCell>{device.ip}</TableCell>
               {showDetails && (
                 <TableCell>
                   <p>Último check-in: {new Date(device.lastCheckin).toLocaleString()}</p>
                   <p>CPU: {device.cpuUsage.toFixed(2)}% | Memória: {device.memoryUsage.toFixed(2)}% | Disco: {device.diskUsage.toFixed(2)}%</p>
                 </TableCell>
               )}
             </TableRow>
           ))}
         </TableBody>
       </Table>
     </CardContent>
   </Card>
 )
}

