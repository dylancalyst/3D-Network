import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

interface Rule {
  id: number
  type: 'nat' | 'filter'
  source: string
  destination: string
  action: string
}

interface FirewallRulesProps {
  natRules: Rule[]
  packetFilters: Rule[]
  onUpdate: (newRules: { natRules: Rule[], packetFilters: Rule[] }) => void
}

export default function FirewallRules({ natRules, packetFilters, onUpdate }: FirewallRulesProps) {
  const [newRule, setNewRule] = useState<Omit<Rule, 'id'>>({ type: 'nat', source: '', destination: '', action: '' })

  const addRule = () => {
    const ruleWithId = { ...newRule, id: Date.now() }
    if (newRule.type === 'nat') {
      onUpdate({ natRules: [...natRules, ruleWithId], packetFilters })
    } else {
      onUpdate({ natRules, packetFilters: [...packetFilters, ruleWithId] })
    }
    setNewRule({ type: 'nat', source: '', destination: '', action: '' })
  }

  const removeRule = (id: number, type: 'nat' | 'filter') => {
    if (type === 'nat') {
      onUpdate({ natRules: natRules.filter(rule => rule.id !== id), packetFilters })
    } else {
      onUpdate({ natRules, packetFilters: packetFilters.filter(rule => rule.id !== id) })
    }
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Adicionar Nova Regra</Label>
        <select
          value={newRule.type}
          onChange={(e) => setNewRule({ ...newRule, type: e.target.value as 'nat' | 'filter' })}
          className="w-full p-2 border rounded"
        >
          <option value="nat">NAT</option>
          <option value="filter">Filtro de Pacotes</option>
        </select>
        <Input
          placeholder="Origem"
          value={newRule.source}
          onChange={(e) => setNewRule({ ...newRule, source: e.target.value })}
        />
        <Input
          placeholder="Destino"
          value={newRule.destination}
          onChange={(e) => setNewRule({ ...newRule, destination: e.target.value })}
        />
        <Input
          placeholder="Ação"
          value={newRule.action}
          onChange={(e) => setNewRule({ ...newRule, action: e.target.value })}
        />
        <Button onClick={addRule}>Adicionar Regra</Button>
      </div>
      <div>
        <h3 className="font-bold">Regras NAT</h3>
        {natRules.map(rule => (
          <div key={rule.id} className="flex justify-between items-center border-b py-2">
            <span>{rule.source} → {rule.destination} : {rule.action}</span>
            <Button variant="destructive" onClick={() => removeRule(rule.id, 'nat')}>Remover</Button>
          </div>
        ))}
      </div>
      <div>
        <h3 className="font-bold">Filtros de Pacotes</h3>
        {packetFilters.map(rule => (
          <div key={rule.id} className="flex justify-between items-center border-b py-2">
            <span>{rule.source} → {rule.destination} : {rule.action}</span>
            <Button variant="destructive" onClick={() => removeRule(rule.id, 'filter')}>Remover</Button>
          </div>
        ))}
      </div>
    </div>
  )
}

