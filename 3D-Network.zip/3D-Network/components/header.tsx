'use client'

import { useState } from 'react'
import { Bell, User } from 'lucide-react'

export default function Header() {
  const [isProfileOpen, setIsProfileOpen] = useState(false)

  return (
    <header className="bg-white shadow-md py-4 px-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-gray-800">3D Network Monitor</h1>
        <div className="flex items-center space-x-4">
          <button className="text-gray-600 hover:text-gray-800">
            <Bell className="h-6 w-6" />
          </button>
          <div className="relative">
            <button 
              onClick={() => setIsProfileOpen(!isProfileOpen)}
              className="flex items-center text-gray-600 hover:text-gray-800"
            >
              <User className="h-6 w-6" />
            </button>
            {isProfileOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1">
                <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Perfil</a>
                <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Configurações</a>
                <a href="/login" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Sair</a>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}

