'use client'

import { useState, useEffect } from 'react'
import { Input } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { Button } from '@/components/ui/button'

interface Log {
  id: string
  timestamp: string
  level: string
  message: string
}

export default function LogViewer() {
  const [logs, setLogs] = useState<Log[]>([])
  const [filter, setFilter] = useState('')
  const [logLevel, setLogLevel] = useState('all')

  useEffect(() => {
    fetchLogs()
  }, [])

  const fetchLogs = async () => {
    try {
      const response = await fetch('/api/admin/logs')
      if (!response.ok) throw new Error('Falha ao buscar logs')
      const data = await response.json()
      setLogs(data)
    } catch (error) {
      console.error('Erro ao buscar logs:', error)
    }
  }

  const filteredLogs = logs.filter(log => 
    (logLevel === 'all' || log.level === logLevel) &&
    (log.message.toLowerCase().includes(filter.toLowerCase()) || 
     log.timestamp.includes(filter))
  )

  return (
    <div className="space-y-4">
      <div className="flex space-x-2">
        <Input
          placeholder="Filtrar logs..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        />
        <Select
          value={logLevel}
          onValueChange={setLogLevel}
          options={[
            { value: 'all', label: 'Todos' },
            { value: 'info', label: 'Info' },
            { value: 'warn', label: 'Aviso' },
            { value: 'error', label: 'Erro' },
          ]}
        />
        <Button onClick={fetchLogs}>Atualizar</Button>
      </div>
      <div className="bg-gray-100 p-4 rounded-lg max-h-96 overflow-y-auto">
        {filteredLogs.map(log => (
          <div key={log.id} className={`mb-2 p-2 rounded ${
            log.level === 'error' ? 'bg-red-100' :
            log.level === 'warn' ? 'bg-yellow-100' : 'bg-white'
          }`}>
            <span className="font-mono text-sm">{log.timestamp}</span>
            <span className={`ml-2 px-1 rounded ${
              log.level === 'error' ? 'bg-red-200 text-red-800' :
              log.level === 'warn' ? 'bg-yellow-200 text-yellow-800' :
              'bg-blue-200 text-blue-800'
            }`}>
              {log.level.toUpperCase()}
            </span>
            <span className="ml-2">{log.message}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

