import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Select } from '@/components/ui/select'

interface MonitoringConfig {
  snmp: {
    enabled: boolean
    version: string
    community: string
    interval: number
  }
  icmp: {
    enabled: boolean
    interval: number
    timeout: number
  }
  netflow: {
    enabled: boolean
    collectorIP: string
    collectorPort: number
  }
}

interface MonitoringProtocolsProps {
  config: MonitoringConfig
  onConfigChange: (newConfig: MonitoringConfig) => void
}

export default function MonitoringProtocols({ config, onConfigChange }: MonitoringProtocolsProps) {
  const handleChange = (protocol: keyof MonitoringConfig, field: string, value: any) => {
    onConfigChange({
      ...config,
      [protocol]: {
        ...config[protocol],
        [field]: value
      }
    })
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-bold mb-2">SNMP</h3>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Switch
              id="snmpEnabled"
              checked={config.snmp.enabled}
              onCheckedChange={(checked) => handleChange('snmp', 'enabled', checked)}
            />
            <Label htmlFor="snmpEnabled">Habilitar SNMP</Label>
          </div>
          {config.snmp.enabled && (
            <>
              <div>
                <Label htmlFor="snmpVersion">Versão SNMP</Label>
                <Select
                  id="snmpVersion"
                  value={config.snmp.version}
                  onValueChange={(value) => handleChange('snmp', 'version', value)}
                  options={[
                    { value: 'v1', label: 'v1' },
                    { value: 'v2c', label: 'v2c' },
                    { value: 'v3', label: 'v3' },
                  ]}
                />
              </div>
              <div>
                <Label htmlFor="snmpCommunity">Comunidade SNMP</Label>
                <Input
                  id="snmpCommunity"
                  value={config.snmp.community}
                  onChange={(e) => handleChange('snmp', 'community', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="snmpInterval">Intervalo de Coleta (segundos)</Label>
                <Input
                  id="snmpInterval"
                  type="number"
                  value={config.snmp.interval}
                  onChange={(e) => handleChange('snmp', 'interval', parseInt(e.target.value))}
                />
              </div>
            </>
          )}
        </div>
      </div>

      <div>
        <h3 className="font-bold mb-2">ICMP (Ping)</h3>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Switch
              id="icmpEnabled"
              checked={config.icmp.enabled}
              onCheckedChange={(checked) => handleChange('icmp', 'enabled', checked)}
            />
            <Label htmlFor="icmpEnabled">Habilitar ICMP</Label>
          </div>
          {config.icmp.enabled && (
            <>
              <div>
                <Label htmlFor="icmpInterval">Intervalo de Ping (segundos)</Label>
                <Input
                  id="icmpInterval"
                  type="number"
                  value={config.icmp.interval}
                  onChange={(e) => handleChange('icmp', 'interval', parseInt(e.target.value))}
                />
              </div>
              <div>
                <Label htmlFor="icmpTimeout">Timeout (segundos)</Label>
                <Input
                  id="icmpTimeout"
                  type="number"
                  value={config.icmp.timeout}
                  onChange={(e) => handleChange('icmp', 'timeout', parseInt(e.target.value))}
                />
              </div>
            </>
          )}
        </div>
      </div>

      <div>
        <h3 className="font-bold mb-2">NetFlow</h3>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Switch
              id="netflowEnabled"
              checked={config.netflow.enabled}
              onCheckedChange={(checked) => handleChange('netflow', 'enabled', checked)}
            />
            <Label htmlFor="netflowEnabled">Habilitar NetFlow</Label>
          </div>
          {config.netflow.enabled && (
            <>
              <div>
                <Label htmlFor="netflowCollectorIP">IP do Coletor NetFlow</Label>
                <Input
                  id="netflowCollectorIP"
                  value={config.netflow.collectorIP}
                  onChange={(e) => handleChange('netflow', 'collectorIP', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="netflowCollectorPort">Porta do Coletor NetFlow</Label>
                <Input
                  id="netflowCollectorPort"
                  type="number"
                  value={config.netflow.collectorPort}
                  onChange={(e) => handleChange('netflow', 'collectorPort', parseInt(e.target.value))}
                />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

