'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Globe, Server, AlertTriangle } from 'lucide-react'

interface HealthCheckResult {
  internetAccess: boolean
  snmpPort: boolean
  icmpPort: boolean
  customPorts: { [key: string]: boolean }
}

export default function NetworkHealthCheck() {
  const [healthCheck, setHealthCheck] = useState<HealthCheckResult | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchHealthCheck = async () => {
      try {
        const response = await fetch('/api/network-health-check')
        if (response.ok) {
          const data = await response.json()
          setHealthCheck(data)
        } else {
          throw new Error('Failed to fetch health check data')
        }
      } catch (error) {
        console.error('Error fetching health check:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchHealthCheck()
    const interval = setInterval(fetchHealthCheck, 300000) // Check every 5 minutes

    return () => clearInterval(interval)
  }, [])

  if (loading) {
    return <Card><CardContent>Carregando verificação de saúde da rede...</CardContent></Card>
  }

  if (!healthCheck) {
    return <Card><CardContent>Falha ao carregar a verificação de saúde da rede.</CardContent></Card>
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Server className="h-6 w-6" />
          <span>Verificação de Saúde da Rede</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="flex items-center space-x-2">
            <Globe className="h-5 w-5" />
            <span>Acesso à Internet</span>
          </span>
          <Badge variant={healthCheck.internetAccess ? "success" : "destructive"}>
            {healthCheck.internetAccess ? "Ativo" : "Inativo"}
          </Badge>
        </div>
        <div className="flex items-center justify-between">
          <span>Porta SNMP (161)</span>
          <Badge variant={healthCheck.snmpPort ? "success" : "destructive"}>
            {healthCheck.snmpPort ? "Aberta" : "Fechada"}
          </Badge>
        </div>
        <div className="flex items-center justify-between">
          <span>ICMP (Ping)</span>
          <Badge variant={healthCheck.icmpPort ? "success" : "destructive"}>
            {healthCheck.icmpPort ? "Ativo" : "Inativo"}
          </Badge>
        </div>
        {Object.entries(healthCheck.customPorts).map(([port, isOpen]) => (
          <div key={port} className="flex items-center justify-between">
            <span>Porta Personalizada ({port})</span>
            <Badge variant={isOpen ? "success" : "destructive"}>
              {isOpen ? "Aberta" : "Fechada"}
            </Badge>
          </div>
        ))}
        {(!healthCheck.internetAccess || !healthCheck.snmpPort || !healthCheck.icmpPort || Object.values(healthCheck.customPorts).some(v => !v)) && (
          <div className="flex items-center space-x-2 text-yellow-600">
            <AlertTriangle className="h-5 w-5" />
            <span>Alguns serviços podem estar comprometidos. Verifique a configuração de rede.</span>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

