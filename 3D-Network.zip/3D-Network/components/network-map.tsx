'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import ForceGraph3D from '3d-force-graph'
import * as THREE from 'three'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Loader2, ZoomIn, ZoomOut, RotateCcw, Eye, EyeOff } from 'lucide-react'
import { Slider } from '@/components/ui/slider'
import { initializeWebSocket, getSocket } from '@/utils/websocket'
import DeviceDetails from '@/components/device-details'
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip'
import { cn } from '@/lib/utils'

interface Device {
 id: string
 name: string
 type: string
 status: string
 ip: string
}

interface Link {
 source: string
 target: string
 status: string
}

export default function NetworkMap() {
 const [devices, setDevices] = useState<Device[]>([])
 const [links, setLinks] = useState<Link[]>([])
 const [loading, setLoading] = useState(true)
 const [selectedDevice, setSelectedDevice] = useState<string | null>(null)
 const [graph, setGraph] = useState<any>(null)
 const [linkDistance, setLinkDistance] = useState(50)
 const [showLabels, setShowLabels] = useState(true)


 useEffect(() => {
   const socket = initializeWebSocket()

   const handleDeviceUpdate = (data: any) => {
     // Update device status in real-time
     setDevices(prevDevices =>
       prevDevices.map(device =>
         device.id === data.deviceId ? { ...device, status: data.status } : device
       )
     )
   }

   socket.on('deviceUpdate', handleDeviceUpdate)
   socket.on('topologyUpdate', (newTopologyData) => {
    setDevices(newTopologyData.nodes);
    setLinks(newTopologyData.links);
    renderGraph(newTopologyData.nodes, newTopologyData.links); // Update the graph with new data
  });

   return () => {
     socket.off('deviceUpdate')
     socket.off('topologyUpdate');
   }
 }, [])

 useEffect(() => {
   fetchTopologyData()
 }, [])

 const fetchTopologyData = async () => {
   setLoading(true)
   try {
     const response = await fetch('/api/network-topology')
     if (!response.ok) throw new Error('Failed to fetch network topology')
     const data = await response.json()
     setDevices(data.nodes)
     setLinks(data.links)
     renderGraph(data.nodes, data.links)
   } catch (error) {
     console.error('Error fetching topology data:', error)
   } finally {
     setLoading(false)
   }
 }

 const renderGraph = useCallback((nodes: Device[], links: Link[]) => {
   const elem = document.getElementById('3d-graph')
   if (elem) {
     const newGraph = ForceGraph3D()(elem)
       .graphData({ nodes, links })
       .nodeLabel(showLabels ? 'name' : '') // Conditionally show labels
       .nodeColor((node: Device) => getNodeColor(node.status))
       .nodeThreeObject((node: Device) => {
         const sprite = new THREE.Sprite(
           new THREE.SpriteMaterial({ map: new THREE.TextureLoader().load(`/icons/${node.type}.png`) })
         )
         sprite.scale.set(12, 12, 1) // Smaller icon size
         return sprite
       })
       .linkColor((link: Link) => getLinkColor(link.status))
       .linkWidth(2) // Thicker links
       .linkDirectionalParticles(4) // More particles
       .linkDirectionalParticleWidth(1) // Thicker particles
       .d3Force('link').distance(linkDistance)
       .onNodeClick((node: Device, event: any) => {
         setSelectedDevice(node.id)
       })
       .onNodeHover((node: Device | null) => {
         // Implement tooltip logic here if needed
       })

     setGraph(newGraph)
   }
 }, [linkDistance, showLabels])

 const getNodeColor = (status: string) => {
   switch (status) {
     case 'online': return 'green'
     case 'offline': return 'red'
     case 'warning': return 'orange'
     default: return 'gray'
   }
 }

 const getLinkColor = (status: string) => {
   switch (status) {
     case 'active': return 'green'
     case 'inactive': return 'red'
     default: return 'gray'
   }
 }

 const handleZoomIn = () => graph?.zoom(1.5, 200)
 const handleZoomOut = () => graph?.zoom(0.67, 200)
 const handleResetView = () => {
   graph?.zoomToFit(400)
   graph?.d3ReheatSimulation()
 }

 const handleLinkDistanceChange = (value: number[]) => {
   setLinkDistance(value[0])
 }

 const handleToggleLabels = () => {
   setShowLabels(!showLabels)
 }

 return (
   <Card className="h-[600px]">
     <CardHeader>
       <CardTitle className="flex justify-between items-center">
         <span>Network Map</span>
         <div className="flex space-x-2">
           <Button onClick={handleZoomIn} size="sm" aria-label="Zoom In">
             <ZoomIn className="h-4 w-4" />
           </Button>
           <Button onClick={handleZoomOut} size="sm" aria-label="Zoom Out">
             <ZoomOut className="h-4 w-4" />
           </Button>
           <Button onClick={handleResetView} size="sm" aria-label="Reset View">
             <RotateCcw className="h-4 w-4" />
           </Button>
           <Button onClick={fetchTopologyData} disabled={loading} size="sm" aria-label="Refresh">
             {loading ? (
               <>
                 <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                 Updating...
               </>
             ) : (
               'Refresh'
             )}
           </Button>
           <TooltipProvider>
             <Tooltip>
               <TooltipTrigger asChild>
                 <Button size="sm" variant="outline" onClick={handleToggleLabels} aria-label="Toggle Labels">
                   {showLabels ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                 </Button>
               </TooltipTrigger>
               <TooltipContent>
                 {showLabels ? 'Hide Labels' : 'Show Labels'}
               </TooltipContent>
             </Tooltip>
           </TooltipProvider>
         </div>
       </CardTitle>
       <CardDescription>Visualização 3D da sua topologia de rede.</CardDescription>
     </CardHeader>
     <CardContent className="space-y-4">
       <div className="flex space-x-4">
         <div id="3d-graph" className="w-2/3 h-[500px]"></div>
         <div className="w-1/3 h-[500px] overflow-y-auto">
           {selectedDevice && <DeviceDetails deviceId={selectedDevice} />}
         </div>
       </div>
       <div className="flex items-center space-x-2">
         <span className="text-sm">Link Distance:</span>
         <Slider
           defaultValue={[linkDistance]}
           max={200}
           step={1}
           onValueChange={handleLinkDistanceChange}
           className="w-[200px]"
         />
       </div>
     </CardContent>
   </Card>
 )
}

