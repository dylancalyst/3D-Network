'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { initializeWebSocket } from '@/utils/websocket'

interface PerformanceData {
  timestamp: number
  bandwidth: number
  latency: number
  packetLoss: number
}

export default function NetworkPerformance() {
  const [performanceData, setPerformanceData] = useState<PerformanceData[]>([])

  useEffect(() => {
    const fetchPerformanceData = async () => {
      try {
        const response = await fetch('/api/network-performance')
        if (response.ok) {
          const data = await response.json()
          setPerformanceData(data)
        }
      } catch (error) {
        console.error('Failed to fetch performance data:', error)
      }
    }

    fetchPerformanceData()

    const socket = initializeWebSocket()

    socket.on('performanceUpdate', (data) => {
      setPerformanceData(prevData => [...prevData.slice(-59), data])
    })

    return () => {
      socket.off('performanceUpdate')
    }
  }, [])

  return (
    <Card className="h-[400px]">
      <CardHeader>
        <CardTitle>Network Performance</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={performanceData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis
              dataKey="timestamp"
              tickFormatter={(timestamp) => new Date(timestamp).toLocaleTimeString()}
            />
            <YAxis yAxisId="left" />
            <YAxis yAxisId="right" orientation="right" />
            <Tooltip
              labelFormatter={(timestamp) => new Date(timestamp).toLocaleString()}
            />
            <Legend />
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="bandwidth"
              stroke="#8884d8"
              name="Bandwidth (Mbps)"
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="latency"
              stroke="#82ca9d"
              name="Latency (ms)"
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="packetLoss"
              stroke="#ffc658"
              name="Packet Loss (%)"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

