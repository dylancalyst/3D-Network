'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

interface Prediction {
  id: string
  deviceId: string
  deviceName: string
  metric: string
  currentValue: number
  predictedValue: number
  timestamp: string
  confidence: number
}

export default function NetworkPredictions() {
  const [predictions, setPredictions] = useState<Prediction[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchPredictions()
  }, [])

  const fetchPredictions = async () => {
    try {
      const response = await fetch('/api/network-predictions')
      if (!response.ok) throw new Error('Failed to fetch network predictions')
      const data = await response.json()
      setPredictions(data)
      setLoading(false)
    } catch (err) {
      setError('Failed to load network predictions')
      setLoading(false)
    }
  }

  if (loading) return <div>Loading network predictions...</div>
  if (error) return <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Network Predictions</h2>
      {predictions.map((prediction) => (
        <Card key={prediction.id}>
          <CardHeader>
            <CardTitle>{prediction.deviceName} - {prediction.metric}</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart
                data={[
                  { name: 'Current', value: prediction.currentValue },
                  { name: 'Predicted', value: prediction.predictedValue },
                ]}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="value" stroke="#8884d8" activeDot={{ r: 8 }} />
              </LineChart>
            </ResponsiveContainer>
            <p className="mt-4">Confidence: {(prediction.confidence * 100).toFixed(2)}%</p>
            <p>Timestamp: {new Date(prediction.timestamp).toLocaleString()}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

