'use client'

import { useState, useEffect } from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

interface NetworkStat {
  timestamp: string
  bandwidth: number
}

export default function NetworkStats() {
  const [data, setData] = useState<NetworkStat[]>([])

  useEffect(() => {
    const fetchNetworkStats = async () => {
      try {
        const response = await fetch('/api/network-stats')
        if (response.ok) {
          const newData = await response.json()
          setData(newData)
        }
      } catch (error) {
        console.error('Failed to fetch network stats:', error)
      }
    }

    fetchNetworkStats()
    const interval = setInterval(fetchNetworkStats, 60000) // Fetch every minute

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h2 className="text-xl font-semibold mb-4">Network Bandwidth Usage</h2>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="timestamp" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="bandwidth" stroke="#8884d8" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

