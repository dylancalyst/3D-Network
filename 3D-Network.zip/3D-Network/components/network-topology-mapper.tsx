'use client'

import { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Loader2 } from 'lucide-react'
import ForceGraph3D from '3d-force-graph'
import { useRouter } from 'next/navigation'
import * as THREE from 'three'

interface NetworkNode {
  id: string
  name: string
  type: string
  status: string // Added status field
}

interface NetworkLink {
  source: string
  target: string
  status: string // Added status field
}

interface TopologyData {
  nodes: NetworkNode[]
  links: NetworkLink[]
}

export default function NetworkTopologyMapper() {
  const [topologyData, setTopologyData] = useState<TopologyData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [needsRefresh, setNeedsRefresh] = useState(false); // Added needsRefresh state
  const graphRef = useRef<any>(null)
  const router = useRouter()

  useEffect(() => {
    if (topologyData) {
      renderTopology(topologyData)
    }
  }, [topologyData])

  useEffect(() => {
    const intervalId = setInterval(() => {
      if (needsRefresh) {
        detectTopology();
        setNeedsRefresh(false);
      }
    }, 5000);
    return () => clearInterval(intervalId);
  }, [needsRefresh]);


  const detectTopology = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await fetch('/api/network-topology')
      if (!response.ok) throw new Error('Failed to detect network topology')
      const data = await response.json()
      setTopologyData(data)
      setNeedsRefresh(true); // Added setNeedsRefresh(true)
    } catch (err) {
      setError('Failed to detect network topology')
    } finally {
      setLoading(false)
    }
  }

  const renderTopology = (data: TopologyData) => {
    const elem = document.getElementById('3d-graph')
    if (elem) {
      graphRef.current = ForceGraph3D()(elem)
        .graphData(data)
        .nodeLabel('name')
        .nodeColor((node: any) => getNodeColor(node.type, node.status)) // Updated nodeColor
        .nodeThreeObject((node: any) => {
          const sprite = new THREE.Sprite(
            new THREE.SpriteMaterial({ map: new THREE.TextureLoader().load(`/icons/${node.type}.png`) })
          )
          sprite.scale.set(16, 16, 1)
          return sprite
        })
        .linkColor((link: any) => getLinkColor(link.status)) // Added linkColor function
        .linkWidth(1)
        .linkDirectionalParticles(2)
        .linkDirectionalParticleWidth(0.5)
        .onNodeClick((node: any) => router.push(`/dashboard/devices/${node.id}`))
        .onNodeHover((node: any) => {
          elem.style.cursor = node ? 'pointer' : null
        });
      graphRef.current.graphData(data); // Added graphData update
    }
  }

  const getNodeColor = (type: string, status: string) => {
    let color = '';
    switch (type) {
      case 'router':
        color = 'red';
        break;
      case 'switch':
        color = 'green';
        break;
      case 'server':
        color = 'blue';
        break;
      default:
        color = 'gray';
    }

    if (status === 'offline') {
      color = 'darkgray';
    } else if (status === 'warning') {
      color = 'orange';
    }
    return color;
  };

  const getLinkColor = (status: string) => {
    if (status === 'offline') {
      return 'darkgray';
    } else if (status === 'warning') {
      return 'orange';
    }
    return 'rgba(255,255,255,0.2)';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Network Topology Mapper</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <Button onClick={detectTopology} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Detecting Topology...
              </>
            ) : (
              'Detect Network Topology'
            )}
          </Button>
        </div>
        {error && (
          <Alert variant="destructive">
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        <div id="3d-graph" style={{ width: '100%', height: '500px' }}></div>
      </CardContent>
    </Card>
  )
}

