'use client'

import { useEffect, useRef } from 'react'
import { Network } from 'vis-network'
import { DataSet } from 'vis-data'

interface NetworkTopologyProps {
  firewallRules: any
  vpnConfig: any
}

export default function NetworkTopology({ firewallRules, vpnConfig }: NetworkTopologyProps) {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!containerRef.current) return

    const nodes = new DataSet([
      { id: 1, label: 'Internet', shape: 'cloud' },
      { id: 2, label: 'Firewall', shape: 'box' },
      { id: 3, label: 'Switch', shape: 'triangle' },
      { id: 4, label: 'Server 1', shape: 'box' },
      { id: 5, label: 'Server 2', shape: 'box' },
      { id: 6, label: 'Client 1', shape: 'circle' },
      { id: 7, label: 'Client 2', shape: 'circle' },
    ])

    const edges = new DataSet([
      { from: 1, to: 2 },
      { from: 2, to: 3 },
      { from: 3, to: 4 },
      { from: 3, to: 5 },
      { from: 3, to: 6 },
      { from: 3, to: 7 },
    ])

    if (vpnConfig.enabled) {
      nodes.add({ id: 8, label: 'VPN Server', shape: 'diamond' })
      edges.add({ from: 2, to: 8 })
    }

    const data = { nodes, edges }

    const options = {
      nodes: {
        shape: 'dot',
        size: 30,
        font: {
          size: 14,
          color: '#ffffff',
        },
        borderWidth: 2,
      },
      edges: {
        width: 2,
      },
    }

    const network = new Network(containerRef.current, data, options)

    return () => {
      network.destroy()
    }
  }, [firewallRules, vpnConfig])

  return <div ref={containerRef} style={{ height: '400px', border: '1px solid lightgray' }} />
}

