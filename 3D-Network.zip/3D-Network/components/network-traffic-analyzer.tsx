'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2 } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { Select } from "@/components/ui/select"

interface TrafficData {
  protocol: string
  inbound: number
  outbound: number
}

export default function NetworkTrafficAnalyzer() {
  const [trafficData, setTrafficData] = useState<TrafficData[]>([])
  const [timeRange, setTimeRange] = useState('1h')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchTrafficData = async () => {
      try {
        const response = await fetch(`/api/network-traffic?timeRange=${timeRange}`)
        if (!response.ok) throw new Error('Failed to fetch network traffic data')
        const data = await response.json()
        setTrafficData(data)
        setLoading(false)
      } catch (err) {
        setError('Failed to fetch network traffic data')
        setLoading(false)
      }
    }

    fetchTrafficData()
    const interval = setInterval(fetchTrafficData, 60000) // Update every minute

    return () => clearInterval(interval)
  }, [timeRange])

  if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="h-8 w-8 animate-spin" /></div>
  if (error) return <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Network Traffic Analysis</CardTitle>
        <Select
          value={timeRange}
          onValueChange={setTimeRange}
          options={[
            { value: '1h', label: 'Last Hour' },
            { value: '24h', label: 'Last 24 Hours' },
            { value: '7d', label: 'Last 7 Days' },
          ]}
        />
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={trafficData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="protocol" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="inbound" fill="#8884d8" name="Inbound Traffic" />
            <Bar dataKey="outbound" fill="#82ca9d" name="Outbound Traffic" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

