'use client'

import { useState, useEffect } from 'react'
import { io } from 'socket.io-client'
import { Toast } from '@/components/ui/toast'
import { useToast } from '@/components/ui/use-toast'

export default function Notifications() {
  const { toast } = useToast()
  const [socket, setSocket] = useState(null)

  useEffect(() => {
    const newSocket = io(process.env.NEXT_PUBLIC_WEBSOCKET_URL || 'http://localhost:3001')
    setSocket(newSocket)

    return () => newSocket.close()
  }, [])

  useEffect(() => {
    if (!socket) return

    socket.on('deviceUpdate', (data) => {
      if (data.status === 'offline') {
        toast({
          title: 'Device Offline',
          description: `Device ${data.deviceId} is now offline.`,
          variant: 'destructive',
        })
      }
    })

    socket.on('newAlerts', (alerts) => {
      alerts.forEach(alert => {
        toast({
          title: 'New Alert',
          description: alert.message,
          variant: 'destructive',
        })
      })
    })

    return () => {
      socket.off('deviceUpdate')
      socket.off('newAlerts')
    }
  }, [socket, toast])

  return null // This component doesn't render anything visible
}

