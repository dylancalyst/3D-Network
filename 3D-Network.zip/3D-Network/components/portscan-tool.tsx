'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Loader2 } from 'lucide-react'

export default function PortScanTool() {
 const [target, setTarget] = useState('')
 const [result, setResult] = useState<string | null>(null)
 const [error, setError] = useState<string | null>(null)
 const [loading, setLoading] = useState(false)

 const handlePortScan = async () => {
   setLoading(true)
   setError(null)
   setResult(null)

   try {
     const response = await fetch(`/api/network-tools?tool=portscan&target=${encodeURIComponent(target)}`)
     if (!response.ok) {
       const errorData = await response.json()
       throw new Error(errorData.error || 'Network response was not ok')
     }
     const data = await response.json()
     setResult(data.result)
   } catch (error) {
     setError(`Error: ${error instanceof Error ? error.message : String(error)}`)
   } finally {
     setLoading(false)
   }
 }

 return (
   <Card>
     <CardHeader>
       <CardTitle>Port Scan Tool</CardTitle>
     </CardHeader>
     <CardContent>
       <div className="space-y-4">
         <div>
           <Label htmlFor="portscanTarget">Target IP or Hostname</Label>
           <Input
             id="portscanTarget"
             value={target}
             onChange={(e) => setTarget(e.target.value)}
             placeholder="e.g., 8.8.8.8 or example.com"
           />
         </div>
         <Button onClick={handlePortScan} disabled={loading}>
           {loading ? (
             <>
               <Loader2 className="mr-2 h-4 w-4 animate-spin" />
               Loading...
             </>
           ) : (
             'Port Scan'
           )}
         </Button>
         {error && (
           <Alert variant="destructive">
             <AlertTitle>Error</AlertTitle>
             <AlertDescription>{error}</AlertDescription>
           </Alert>
         )}
         {result && <pre className="mt-4 p-2 bg-gray-100 rounded whitespace-pre-wrap">{result}</pre>}
       </div>
     </CardContent>
   </Card>
 )
}

