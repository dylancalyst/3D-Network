'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import io from 'socket.io-client'

interface Metric {
  timestamp: number
  cpuLoad: number
  memoryUsed: number
}

interface DeviceMetrics {
  [deviceId: string]: Metric[]
}

export default function RealTimeMetrics() {
  const [metrics, setMetrics] = useState<DeviceMetrics>({})

  useEffect(() => {
    const socket = io('http://localhost:3001')

    socket.on('deviceUpdate', (data) => {
      setMetrics(prevMetrics => {
        const deviceMetrics = prevMetrics[data.deviceId] || []
        const newMetric: Metric = {
          timestamp: Date.now(),
          cpuLoad: data.metrics.cpuLoad,
          memoryUsed: data.metrics.memoryUsed
        }
        return {
          ...prevMetrics,
          [data.deviceId]: [...deviceMetrics.slice(-19), newMetric]
        }
      })
    })

    return () => {
      socket.disconnect()
    }
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Real-Time Device Metrics</CardTitle>
      </CardHeader>
      <CardContent>
        {Object.entries(metrics).map(([deviceId, deviceMetrics]) => (
          <div key={deviceId} className="mb-8">
            <h3 className="text-lg font-semibold mb-2">Device {deviceId}</h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={deviceMetrics}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="timestamp" tickFormatter={(timestamp) => new Date(timestamp).toLocaleTimeString()} />
                <YAxis yAxisId="left" />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip labelFormatter={(timestamp) => new Date(timestamp).toLocaleString()} />
                <Legend />
                <Line yAxisId="left" type="monotone" dataKey="cpuLoad" stroke="#8884d8" name="CPU Load (%)" />
                <Line yAxisId="right" type="monotone" dataKey="memoryUsed" stroke="#82ca9d" name="Memory Used (bytes)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

