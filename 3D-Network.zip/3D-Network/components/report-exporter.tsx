'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Select } from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Loader2, FileDown } from 'lucide-react'

export default function ReportExporter() {
  const [reportType, setReportType] = useState('network-status')
  const [loading, setLoading] = useState(false)

  const exportReport = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/reports/export?type=${reportType}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })

      if (!response.ok) throw new Error('Failed to export report')

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.style.display = 'none'
      a.href = url
      a.download = `${reportType}-report.pdf`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Error exporting report:', error)
      // Você pode adicionar uma notificação de erro aqui
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Exportar Relatório</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <Select
              value={reportType}
              onValueChange={setReportType}
              options={[
                { value: 'network-status', label: 'Status da Rede' },
                { value: 'device-inventory', label: 'Inventário de Dispositivos' },
                { value: 'alert-history', label: 'Histórico de Alertas' },
              ]}
            />
          </div>
          <Button onClick={exportReport} disabled={loading}>
            {loading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <FileDown className="mr-2 h-4 w-4" />
            )}
            Exportar Relatório
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

