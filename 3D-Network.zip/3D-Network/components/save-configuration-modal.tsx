import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { useSavedConfigurations } from '@/contexts/SavedConfigurationsContext'

type SaveConfigurationModalProps = {
  onClose: () => void
  currentLayout: string
}

export function SaveConfigurationModal({ onClose, currentLayout }: SaveConfigurationModalProps) {
  const [configName, setConfigName] = useState('')
  const { addConfig } = useSavedConfigurations()

  const handleSave = () => {
    if (configName.trim()) {
      addConfig(configName.trim(), currentLayout)
      onClose()
    }
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Save Dashboard Configuration</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Input
              id="config-name"
              className="col-span-4"
              placeholder="Enter configuration name"
              value={configName}
              onChange={(e) => setConfigName(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button type="button" onClick={handleSave} disabled={!configName.trim()}>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

