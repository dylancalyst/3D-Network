import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { ChevronDown, Trash2, RotateCcw } from 'lucide-react'
import { useSavedConfigurations } from '@/contexts/SavedConfigurationsContext'
import { useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Button as DialogButton } from '@/components/ui/button'

export function SavedConfigurations() {
  const { savedConfigs, deleteConfig, loadConfig, resetToDefault } = useSavedConfigurations()
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null)
  const [confirmReset, setConfirmReset] = useState(false)

  const handleLoadConfiguration = (configId: string) => {
    loadConfig(configId)
  }

  const handleDeleteConfiguration = (configId: string) => {
    setConfirmDelete(configId)
  }

  const confirmDeleteConfiguration = () => {
    if (confirmDelete) {
      deleteConfig(confirmDelete)
      setConfirmDelete(null)
    }
  }

  const handleResetToDefault = () => {
    setConfirmReset(true)
  }

  const confirmResetToDefault = () => {
    resetToDefault()
    setConfirmReset(false)
  }

  return (
    <div className="mb-4">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline">
            Saved Configurations <ChevronDown className="ml-2 h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56">
          <DropdownMenuLabel>Load Configuration</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {savedConfigs.map((config) => (
            <DropdownMenuItem key={config.id} className="flex justify-between">
              <span onClick={() => handleLoadConfiguration(config.id)}>{config.name}</span>
              <Trash2
                className="h-4 w-4 text-red-500 cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation()
                  handleDeleteConfiguration(config.id)
                }}
              />
            </DropdownMenuItem>
          ))}
          <DropdownMenuSeparator />
          <DropdownMenuItem onSelect={handleResetToDefault}>
            <RotateCcw className="mr-2 h-4 w-4" />
            Reset to Default
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog open={confirmDelete !== null} onOpenChange={() => setConfirmDelete(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
          </DialogHeader>
          <p>Are you sure you want to delete this configuration?</p>
          <DialogFooter>
            <DialogButton variant="secondary" onClick={() => setConfirmDelete(null)}>
              Cancel
            </DialogButton>
            <DialogButton variant="destructive" onClick={confirmDeleteConfiguration}>
              Delete
            </DialogButton>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={confirmReset} onOpenChange={() => setConfirmReset(false)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset to Default</DialogTitle>
          </DialogHeader>
          <p>Are you sure you want to reset the dashboard to the default layout? This action cannot be undone.</p>
          <DialogFooter>
            <DialogButton variant="secondary" onClick={() => setConfirmReset(false)}>
              Cancel
            </DialogButton>
            <DialogButton variant="destructive" onClick={confirmResetToDefault}>
              Reset
            </DialogButton>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

