'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'

interface SecurityPolicy {
  id: string
  name: string
  description: string
  enabled: boolean
  config: Record<string, any>
}

export default function SecurityPolicies() {
  const [policies, setPolicies] = useState<SecurityPolicy[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchPolicies()
  }, [])

  const fetchPolicies = async () => {
    try {
      const response = await fetch('/api/security-policies')
      if (!response.ok) throw new Error('Failed to fetch security policies')
      const data = await response.json()
      setPolicies(data)
      setLoading(false)
    } catch (err) {
      setError('Failed to load security policies')
      setLoading(false)
    }
  }

  const updatePolicy = async (id: string, updates: Partial<SecurityPolicy>) => {
    try {
      const response = await fetch(`/api/security-policies/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      })
      if (!response.ok) throw new Error('Failed to update security policy')
      fetchPolicies()
    } catch (err) {
      setError('Failed to update security policy')
    }
  }

  if (loading) return <div>Loading security policies...</div>
  if (error) return <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Security Policies</h2>
      {policies.map((policy) => (
        <Card key={policy.id}>
          <CardHeader>
            <CardTitle className="flex justify-between items-center">
              <span>{policy.name}</span>
              <Switch
                checked={policy.enabled}
                onCheckedChange={(checked) => updatePolicy(policy.id, { enabled: checked })}
              />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">{policy.description}</p>
            {Object.entries(policy.config).map(([key, value]) => (
              <div key={key} className="mb-2">
                <Label htmlFor={`${policy.id}-${key}`}>{key}</Label>
                <Input
                  id={`${policy.id}-${key}`}
                  value={value}
                  onChange={(e) => updatePolicy(policy.id, { config: { ...policy.config, [key]: e.target.value } })}
                />
              </div>
            ))}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

