'use client'

import Link from 'next/link'
import { useSession } from 'next-auth/react'
import { usePathname } from 'next/navigation'
import { Home, BarChart2, Settings, AlertTriangle, FileText, Users, Network, Lock, Server, Bell, LinkIcon, Map, PenToolIcon as Tool, Shield, Sliders, Activity, Zap, Menu, GlobeIcon as GlobeAlt } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { cn } from "@/lib/utils"
import { User } from '@prisma/client'
import { signOut } from 'next-auth/react'

const menuItems = [
  { href: '/dashboard', icon: Home, label: 'Dashboard', permissions: ['view_dashboard'] },
  { href: '/dashboard/devices', icon: BarChart2, label: 'Dispositivos', permissions: ['view_devices'] },
  { href: '/dashboard/network-config', icon: Network, label: 'Configuração de Rede', permissions: ['configure_network'] },
  { href: '/dashboard/alerts', icon: AlertTriangle, label: 'Alertas', permissions: ['view_alerts'] },
  { href: '/dashboard/reports', icon: FileText, label: 'Relatórios', permissions: ['view_reports'] },
  { href: '/dashboard/settings', icon: Settings, label: 'Configurações', permissions: ['manage_settings'] },
  { href: '/dashboard/external-systems', icon: GlobeAlt, label: 'External Systems', permissions: ['manage_integrations'] },
]

const adminMenuItems = [
  { href: '/dashboard/admin', icon: Users, label: 'Administração', permissions: ['manage_users'] },
  { href: '/dashboard/admin/password-policies', icon: Lock, label: 'Políticas de Senha', permissions: ['manage_password_policies'] },
  { href: '/dashboard/admin/network-settings', icon: Server, label: 'Configurações de Rede', permissions: ['manage_network_settings'] },
  { href: '/dashboard/admin/alert-thresholds', icon: Bell, label: 'Limites de Alertas', permissions: ['manage_alert_thresholds'] },
  { href: '/dashboard/admin/integrations', icon: LinkIcon, label: 'Integrações', permissions: ['manage_integrations'] },
  { href: '/dashboard/admin/network-map', icon: Map, label: 'Mapa de Rede', permissions: ['view_network_map'] },
  { href: '/dashboard/admin/maintenance', icon: Tool, label: 'Manutenção', permissions: ['perform_maintenance'] },
  { href: '/dashboard/admin/security-audits', icon: Shield, label: 'Auditorias de Segurança', permissions: ['view_security_audits'] },
  { href: '/dashboard/admin/customize-dashboard', icon: Sliders, label: 'Personalizar Dashboard', permissions: ['customize_dashboard'] },
  { href: '/dashboard/admin/customize-network-map', icon: Sliders, label: 'Personalizar Mapa de Rede', permissions: ['customize_network_map'] },
  { href: '/dashboard/admin/system-status', icon: Activity, label: 'Status do Sistema', permissions: ['view_system_status'] },
  { href: '/dashboard/admin/network-diagnostics', icon: Zap, label: 'Diagnóstico de Rede', permissions: ['perform_network_diagnostics'] },
  { href: '/dashboard/admin/performance-optimization', icon: Zap, label: 'Otimização de Desempenho', permissions: ['perform_performance_optimization'] },
]

const hasPermission = (href: string, user?: User | null) => {
  if (!user) return false
  if (user.role === 'ADMIN') return true

  const pathPermissions: { [key: string]: string[] } = {
    '/dashboard': ['view_dashboard'],
    '/dashboard/devices': ['view_devices'],
    '/dashboard/network-config': ['configure_network'],
    '/dashboard/alerts': ['view_alerts'],
    '/dashboard/reports': ['view_reports'],
    '/dashboard/settings': ['manage_settings'],
    '/dashboard/admin': ['manage_users'],
    '/dashboard/admin/password-policies': ['manage_password_policies'],
    '/dashboard/admin/network-settings': ['manage_network_settings'],
    '/dashboard/admin/alert-thresholds': ['manage_alert_thresholds'],
    '/dashboard/admin/integrations': ['manage_integrations'],
    '/dashboard/admin/network-map': ['view_network_map'],
    '/dashboard/admin/maintenance': ['perform_maintenance'],
    '/dashboard/admin/security-audits': ['view_security_audits'],
    '/dashboard/admin/customize-dashboard': ['customize_dashboard'],
    '/dashboard/admin/customize-network-map': ['customize_network_map'],
    '/dashboard/admin/system-status': ['view_system_status'],
    '/dashboard/admin/network-diagnostics': ['perform_network_diagnostics'],
    '/dashboard/admin/performance-optimization': ['perform_performance_optimization'],
    '/dashboard/external-systems': ['manage_integrations'],
  }

  const requiredPermissions = pathPermissions[href] || []
  return requiredPermissions.every(permission => user?.permissions.includes(permission))
}

const NavItems = ({ items, session }: { items: typeof menuItems; session: any }) => (
  <>
    {items.filter(item => hasPermission(item.href, session?.user)).map((item) => (
      <Link key={item.href} href={item.href}>
        <span className={cn(
          "group flex items-center rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground",
          pathname === item.href ? "bg-accent" : "transparent"
        )}>
          <item.icon className="mr-2 h-4 w-4" />
          <span>{item.label}</span>
        </span>
      </Link>
    ))}
  </>
)

export default function Sidebar() {
  const { data: session } = useSession()
  const pathname = usePathname()

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="icon" className="md:hidden">
          <Menu />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[300px] sm:w-[400px]">
        <nav className="flex flex-col space-y-2">
          <NavItems items={menuItems} session={session} />
          {session?.user?.role === 'ADMIN' && (
            <>
              <hr className="my-4" />
              <NavItems items={adminMenuItems} session={session} />
            </>
          )}
          <a href="#" onClick={() => signOut()} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Sair</a>
        </nav>
      </SheetContent>
      <aside className="hidden md:flex flex-col space-y-2 w-[300px] p-4 bg-background border-r">
        <ScrollArea className="flex-grow">
          <nav className="flex flex-col space-y-2">
            <NavItems items={menuItems} session={session} />
            {session?.user?.role === 'ADMIN' && (
              <>
                <hr className="my-4" />
                <NavItems items={adminMenuItems} session={session} />
              </>
            )}
            <a href="#" onClick={() => signOut()} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Sair</a>
          </nav>
        </ScrollArea>
      </aside>
    </Sheet>
  )
}

