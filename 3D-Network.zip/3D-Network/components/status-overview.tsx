'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Server, Wifi, HardDrive, AlertTriangle } from 'lucide-react'
import { initializeWebSocket } from '@/utils/websocket'

interface StatusData {
servers: { online: number, total: number }
network: { uptime: number }
storage: { used: number, total: number }
alerts: { active: number }
}

export default function StatusOverview() {
const [statusData, setStatusData] = useState<StatusData>({
  servers: { online: 0, total: 0 },
  network: { uptime: 0 },
  storage: { used: 0, total: 0 },
  alerts: { active: 0 },
})

useEffect(() => {
  const fetchStatusData = async () => {
    try {
      const response = await fetch('/api/status-overview')
      if (response.ok) {
        const data = await response.json()
        setStatusData(data)
      }
    } catch (error) {
      console.error('Failed to fetch status data:', error)
    }
  }

  fetchStatusData()

  const socket = initializeWebSocket()

  socket.on('statusUpdate', (data) => {
    setStatusData(data)
  })

  return () => {
    socket.off('statusUpdate')
  }
}, [])

return (
  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
    <StatusCard
      icon={Server}
      title="Servidores"
      value={`${statusData.servers.online}/${statusData.servers.total} online`}
      color="text-green-500"
    />
    <StatusCard
      icon={Wifi}
      title="Rede"
      value={`${statusData.network.uptime.toFixed(2)}% uptime`}
      color="text-blue-500"
    />
    <StatusCard
      icon={HardDrive}
      title="Armazenamento"
      value={`${((statusData.storage.used / statusData.storage.total) * 100).toFixed(2)}% usado`}
      color="text-yellow-500"
    />
    <StatusCard
      icon={AlertTriangle}
      title="Alertas"
      value={`${statusData.alerts.active} ativos`}
      color="text-red-500"
    />
  </div>
)
}

function StatusCard({ icon: Icon, title, value, color }: { icon: any, title: string, value: string, color: string }) {
return (
  <Card>
    <CardContent className="flex items-center p-6">
      <Icon className={`h-8 w-8 ${color} mr-4`} />
      <div>
        <p className="text-sm font-medium text-muted-foreground">{title}</p>
        <p className={`text-2xl font-bold ${color}`}>{value}</p>
      </div>
    </CardContent>
  </Card>
)
}

