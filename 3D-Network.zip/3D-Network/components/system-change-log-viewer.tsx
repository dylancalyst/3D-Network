'use client'

import { useState, useEffect } from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface SystemChange {
  id: string
  timestamp: string
  user: string
  component: string
  description: string
}

export default function SystemChangeLogViewer() {
  const [changes, setChanges] = useState<SystemChange[]>([])
  const [filter, setFilter] = useState('')

  useEffect(() => {
    fetchChanges()
  }, [])

  const fetchChanges = async () => {
    try {
      const response = await fetch('/api/admin/system-changes')
      if (!response.ok) throw new Error('Falha ao buscar alterações do sistema')
      const data = await response.json()
      setChanges(data)
    } catch (error) {
      console.error('Erro ao buscar alterações do sistema:', error)
    }
  }

  const filteredChanges = changes.filter(change => 
    change.user.toLowerCase().includes(filter.toLowerCase()) ||
    change.component.toLowerCase().includes(filter.toLowerCase()) ||
    change.description.toLowerCase().includes(filter.toLowerCase())
  )

  return (
    <div className="space-y-4">
      <div className="flex space-x-2">
        <Input
          placeholder="Filtrar alterações..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        />
        <Button onClick={fetchChanges}>Atualizar</Button>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Timestamp</TableHead>
            <TableHead>Usuário</TableHead>
            <TableHead>Componente</TableHead>
            <TableHead>Descrição</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredChanges.map(change => (
            <TableRow key={change.id}>
              <TableCell>{new Date(change.timestamp).toLocaleString()}</TableCell>
              <TableCell>{change.user}</TableCell>
              <TableCell>{change.component}</TableCell>
              <TableCell>{change.description}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

