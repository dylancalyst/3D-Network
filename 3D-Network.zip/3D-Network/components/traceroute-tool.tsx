'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Loader2 } from 'lucide-react'

export default function TracerouteTool() {
  const [target, setTarget] = useState('')
  const [result, setResult] = useState('')
  const [loading, setLoading] = useState(false)

  const handleTraceroute = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/network-tools?tool=traceroute&target=${target}`)
      const data = await response.json()
      setResult(data.result)
    } catch (error) {
      setResult(`Error: ${error}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Traceroute Tool</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <Label htmlFor="tracerouteTarget">Target IP or Hostname</Label>
            <Input
              id="tracerouteTarget"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              placeholder="e.g., 8.8.8.8 or example.com"
            />
          </div>
          <Button onClick={handleTraceroute} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Tracing...
              </>
            ) : (
              'Traceroute'
            )}
          </Button>
          {result && <pre>{result}</pre>}
        </div>
      </CardContent>
    </Card>
  )
}

