import { useState, useEffect } from 'react'
import { Responsive, WidthProvider } from 'react-grid-layout'
import 'react-grid-layout/css/styles.css'
import 'react-resizable/css/styles.css'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { NetworkMap } from '@/components/network-map'
import { DeviceList } from '@/components/device-list'
import { AlertPanel } from '@/components/alert-panel'
import { useSavedConfigurations } from '@/contexts/SavedConfigurationsContext'
import { AddDashboardItem } from '@/components/add-dashboard-item'
import { X, Info } from 'lucide-react'
import NetworkTrafficAnalyzer from '@/components/network-traffic-analyzer';
import WifiManagement from '@/components/wifi-management';
import PingTool from '@/components/ping-tool';
import TracerouteTool from '@/components/traceroute-tool';
import WhoisTool from '@/components/whois-tool';
import PortscanTool from '@/components/portscan-tool';
import DeviceHealthMonitor from '@/components/device-health-monitor';
import NetworkPerformance from '@/components/network-performance';

const ResponsiveGridLayout = WidthProvider(Responsive)

type DashboardItem = {
  i: string
  x: number
  y: number
  w: number
  h: number
  component: React.ReactNode
  title: string
  description: string
}

type UserDashboardProps = {
  saveLayout: (layout: string) => void
}

const availableItems = [
  { id: 'network-map', title: 'Network Map', component: <NetworkMap />, description: 'Visualize your network topology' },
  { id: 'device-list', title: 'Device List', component: <DeviceList />, description: 'View network devices' },
  { id: 'alert-panel', title: 'Alerts', component: <AlertPanel />, description: 'Monitor network alerts' },
  { id: 'network-performance', title: 'Network Performance', component: <NetworkPerformance />, description: 'View real-time network performance metrics' },
  { id: 'network-traffic-analyzer', title: 'Network Traffic Analyzer', component: <NetworkTrafficAnalyzer />, description: 'Analyze network traffic patterns' },
  { id: 'wifi-management', title: 'Wi-Fi Management', component: <WifiManagement />, description: 'Manage Wi-Fi networks and settings' },
  { id: 'ping-tool', title: 'Ping Tool', component: <PingTool />, description: 'Test network connectivity with ping' },
  { id: 'traceroute-tool', title: 'Traceroute Tool', component: <TracerouteTool />, description: 'Trace network routes' },
  { id: 'whois-tool', title: 'Whois Tool', component: <WhoisTool />, description: 'Look up domain registration information' },
  { id: 'portscan-tool', title: 'Port Scan Tool', component: <PortscanTool />, description: 'Scan network ports for open services' },
  { id: 'device-health-monitor', title: 'Device Health Monitor', component: <DeviceHealthMonitor />, description: 'Monitor the health of network devices' },
]

export default function UserDashboard({ saveLayout }: UserDashboardProps) {
  const [layout, setLayout] = useState<DashboardItem[]>([
    { i: 'network-map', x: 0, y: 0, w: 6, h: 4, component: <NetworkMap />, title: 'Network Map', description: 'Visualize your network topology' },
    { i: 'device-list', x: 6, y: 0, w: 6, h: 4, component: <DeviceList />, title: 'Device List', description: 'View network devices' },
    { i: 'alert-panel', x: 0, y: 4, w: 12, h: 4, component: <AlertPanel />, title: 'Alerts', description: 'Monitor network alerts' },
  ])

  const { currentConfig } = useSavedConfigurations()

  useEffect(() => {
    if (currentConfig) {
      try {
        const loadedLayout = JSON.parse(currentConfig.layout)
        setLayout(loadedLayout)
      } catch (error) {
        console.error('Error loading layout:', error)
      }
    }
  }, [currentConfig])

  const handleSaveLayout = () => {
    const layoutToSave = JSON.stringify(layout)
    saveLayout(layoutToSave)
  }

  const onLayoutChange = (newLayout: any) => {
    const updatedLayout = layout.map((item) => {
      const updatedItem = newLayout.find((layoutItem: any) => layoutItem.i === item.i)
      return { ...item, ...updatedItem }
    })
    setLayout(updatedLayout)
  }

  const handleAddItem = (itemId: string) => {
    const newItem = availableItems.find((item) => item.id === itemId)
    if (newItem) {
      const newLayoutItem: DashboardItem = {
        i: `${itemId}-${Date.now()}`,
        x: (layout.length * 2) % 12,
        y: Infinity,
        w: 6,
        h: 4,
        component: newItem.component,
        title: newItem.title,
        description: newItem.description,
      }
      setLayout([...layout, newLayoutItem])
    }
  }

  const handleRemoveItem = (itemId: string) => {
    setLayout(layout.filter((item) => item.i !== itemId))
  }

  return (
    <TooltipProvider>
      <div className="p-4">
        <div className="mb-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">User Dashboard</h1>
          <div className="flex gap-2">
            <AddDashboardItem onAddItem={handleAddItem} availableItems={availableItems} />
            <Button onClick={handleSaveLayout}>Save Layout</Button>
          </div>
        </div>
        <ResponsiveGridLayout
          className="layout"
          layouts={{ lg: layout }}
          breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
          cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
          rowHeight={100}
          onLayoutChange={onLayoutChange}
        >
          {layout.map((item) => (
            <div key={item.i}>
              <Card className="h-full">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="flex items-center">
                    {item.title}
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="ghost" size="icon" className="ml-2 h-6 w-6">
                          <Info className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{item.description}</p>
                      </TooltipContent>
                    </Tooltip>
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemoveItem(item.i)}
                    className="h-6 w-6"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </CardHeader>
                <CardContent>{item.component}</CardContent>
              </Card>
            </div>
          ))}
        </ResponsiveGridLayout>
      </div>
    </TooltipProvider>
  )
}

