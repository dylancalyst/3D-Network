import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select } from '@/components/ui/select'

interface VpnConfig {
  enabled: boolean
  serverAddress: string
  protocol: string
  encryption: string
  authentication: string
}

interface VpnWizardProps {
  config: VpnConfig
  onConfigChange: (newConfig: VpnConfig) => void
}

export default function VpnWizard({ config, onConfigChange }: VpnWizardProps) {
  const [step, setStep] = useState(1)

  const nextStep = () => setStep(step + 1)
  const prevStep = () => setStep(step - 1)

  const handleChange = (field: keyof VpnConfig, value: string | boolean) => {
    onConfigChange({ ...config, [field]: value })
  }

  return (
    <div className="space-y-4">
      {step === 1 && (
        <>
          <h3 className="font-bold">Passo 1: Configuração Básica</h3>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="vpnEnabled"
                checked={config.enabled}
                onChange={(e) => handleChange('enabled', e.target.checked)}
              />
              <Label htmlFor="vpnEnabled">Habilitar VPN</Label>
            </div>
            {config.enabled && (
              <>
                <Label htmlFor="serverAddress">Endereço do Servidor VPN</Label>
                <Input
                  id="serverAddress"
                  value={config.serverAddress}
                  onChange={(e) => handleChange('serverAddress', e.target.value)}
                  placeholder="Ex: vpn.example.com"
                />
              </>
            )}
          </div>
          <Button onClick={nextStep} disabled={!config.enabled}>Próximo</Button>
        </>
      )}
      {step === 2 && (
        <>
          <h3 className="font-bold">Passo 2: Protocolo e Criptografia</h3>
          <div className="space-y-2">
            <Label htmlFor="protocol">Protocolo VPN</Label>
            <Select
              id="protocol"
              value={config.protocol}
              onValueChange={(value) => handleChange('protocol', value)}
              options={[
                { value: 'OpenVPN', label: 'OpenVPN' },
                { value: 'IPSec', label: 'IPSec' },
                { value: 'WireGuard', label: 'WireGuard' },
              ]}
            />
            <Label htmlFor="encryption">Criptografia</Label>
            <Select
              id="encryption"
              value={config.encryption}
              onValueChange={(value) => handleChange('encryption', value)}
              options={[
                { value: 'AES-128', label: 'AES-128' },
                { value: 'AES-256', label: 'AES-256' },
                { value: 'ChaCha20', label: 'ChaCha20' },
              ]}
            />
          </div>
          <div className="space-x-2">
            <Button onClick={prevStep}>Anterior</Button>
            <Button onClick={nextStep}>Próximo</Button>
          </div>
        </>
      )}
      {step === 3 && (
        <>
          <h3 className="font-bold">Passo 3: Autenticação</h3>
          <div className="space-y-2">
            <Label htmlFor="authentication">Método de Autenticação</Label>
            <Select
              id="authentication"
              value={config.authentication}
              onValueChange={(value) => handleChange('authentication', value)}
              options={[
                { value: 'Certificate', label: 'Certificado' },
                { value: 'Username/Password', label: 'Usuário/Senha' },
                { value: 'Two-Factor', label: 'Dois Fatores' },
              ]}
            />
          </div>
          <div className="space-x-2">
            <Button onClick={prevStep}>Anterior</Button>
            <Button onClick={() => console.log('Configuração VPN finalizada:', config)}>Finalizar</Button>
          </div>
        </>
      )}
    </div>
  )
}

