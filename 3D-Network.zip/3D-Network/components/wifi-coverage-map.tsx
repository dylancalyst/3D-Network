'use client'

import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'
import L from 'leaflet'
import { Wifi } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

// Workaround for the marker icon issue
// See: https://github.com/PaulLeCam/react-leaflet/issues/453#issuecomment-410450387
delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({
  iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
  iconUrl: require('leaflet/dist/images/marker-icon.png'),
  shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
});


interface WifiData {
 ssid: string
 channel: number
 signalStrength: number
 connectedDevices: number
 latitude: number // Add latitude for marker positioning
 longitude: number // Add longitude for marker positioning
}

interface WifiCoverageMapProps {
 wifiData: WifiData[]
}

function ChangeView({ center }: { center: [number, number] }) {
 const map = useMap()
 map.setView(center, map.getZoom())
 return null
}

const WifiCoverageMap: React.FC<WifiCoverageMapProps> = ({ wifiData }) => {
 if (!wifiData || wifiData.length === 0) {
   return (
     <Card>
       <CardHeader>
         <CardTitle className="flex items-center space-x-2">
           <Wifi className="h-6 w-6" />
           <span>Mapa de Cobertura Wi-Fi</span>
         </CardTitle>
       </CardHeader>
       <CardContent>
         <p>Sem dados de Wi-Fi disponíveis.</p>
       </CardContent>
     </Card>
   )
 }

 const centerLatitude = wifiData.reduce((sum, wifi) => sum + wifi.latitude, 0) / wifiData.length
 const centerLongitude = wifiData.reduce((sum, wifi) => sum + wifi.longitude, 0) / wifiData.length

 return (
   <Card>
     <CardHeader>
       <CardTitle className="flex items-center space-x-2">
         <Wifi className="h-6 w-6" />
         <span>Mapa de Cobertura Wi-Fi</span>
       </CardTitle>
     </CardHeader>
     <CardContent>
       <MapContainer center={[centerLatitude, centerLongitude]} zoom={13} scrollWheelZoom={true} style={{ height: '400px', width: '100%' }}>
         <ChangeView center={[centerLatitude, centerLongitude]} />
         <TileLayer
           attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
           url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
         />
         {wifiData.map((wifi) => (
           <Marker key={wifi.ssid} position={[wifi.latitude, wifi.longitude]}>
             <Popup>
               <div>
                 <p><strong>SSID:</strong> {wifi.ssid}</p>
                 <p><strong>Canal:</strong> {wifi.channel}</p>
                 <p><strong>Intensidade do Sinal:</strong> {wifi.signalStrength}%</p>
                 <p><strong>Dispositivos Conectados:</strong> {wifi.connectedDevices}</p>
               </div>
             </Popup>
           </Marker>
         ))}
       </MapContainer>
     </CardContent>
   </Card>
 )
}

export default WifiCoverageMap

