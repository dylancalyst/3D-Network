'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { RefreshCw, Loader2 } from 'lucide-react'
import dynamic from 'next/dynamic'
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert'

const DynamicCoverageMap = dynamic(() => import('./wifi-coverage-map'), { ssr: false })

interface WifiData {
ssid: string;
channel: number;
signalStrength: number;
connectedDevices: number;
latitude: number;
longitude: number;
}

export default function WifiManagement() {
const [wifiData, setWifiData] = useState<WifiData[]>([])
const [loading, setLoading] = useState(true)
const [error, setError] = useState<string | null>(null)

useEffect(() => {
  const fetchWifiData = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await fetch('/api/wifi-data')
      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'Failed to fetch Wi-Fi data')
      }
      const data = await response.json()
      setWifiData(data)
    } catch (error) {
      console.error('Error fetching Wi-Fi data:', error)
      setError(`Error: ${error instanceof Error ? error.message : String(error)}`)
    } finally {
      setLoading(false)
    }
  }

  fetchWifiData()
  const interval = setInterval(fetchWifiData, 5000) // Update every 5 seconds
  return () => clearInterval(interval)
}, [])

const handleRefresh = async () => {
  setLoading(true)
  setError(null)
  try {
    await fetchWifiData()
  } finally {
    setLoading(false)
  }
}

if (loading) return <div className="flex justify-center items-center h-64"><Loader2 className="h-8 w-8 animate-spin" /></div>
if (error) return <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>
if (!wifiData || wifiData.length === 0) return <Alert><AlertTitle>No Wi-Fi Data</AlertTitle><AlertDescription>No Wi-Fi networks found.</AlertDescription></Alert>

return (
  <Card>
    <CardHeader>
      <CardTitle className="flex justify-between items-center">
        <span>Gerenciamento de Wi-Fi</span>
        <Button onClick={handleRefresh} size="sm">
          <RefreshCw className="mr-2 h-4 w-4" />
          Atualizar
        </Button>
      </CardTitle>
    </CardHeader>
    <CardContent>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h3 className="text-lg font-bold mb-2">Informações da Rede Wi-Fi</h3>
          {wifiData.map((wifi) => (
            <div key={wifi.ssid} className="mb-4">
              <p><strong>SSID:</strong> {wifi.ssid}</p>
              <p><strong>Canal:</strong> {wifi.channel}</p>
              <p><strong>Intensidade do Sinal:</strong> {wifi.signalStrength}%</p>
              <p><strong>Dispositivos Conectados:</strong> {wifi.connectedDevices}</p>
            </div>
          ))}
        </div>
        <div>
          <h3 className="text-lg font-bold mb-2">Mapa de Cobertura</h3>
          <DynamicCoverageMap wifiData={wifiData} />
        </div>
      </div>
    </CardContent>
  </Card>
)
}

