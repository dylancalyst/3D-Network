import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'

export function withAdminAccess<P extends object>(
  WrappedComponent: React.ComponentType<P>
) {
  return function WithAdminAccess(props: P) {
    const { data: session, status } = useSession()
    const router = useRouter()

    useEffect(() => {
      if (status === 'loading') return // Do nothing while loading
      if (!session || session.user.role !== 'Admin') {
        router.push('/dashboard') // Redirect to dashboard if not admin
      }
    }, [session, status, router])

    if (status === 'loading') {
      return <div>Loading...</div>
    }

    if (!session || session.user.role !== 'Admin') {
      return null // Or you could render an "Access Denied" message
    }

    return <WrappedComponent {...props} />
  }
}

