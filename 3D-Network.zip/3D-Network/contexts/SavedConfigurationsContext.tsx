import React, { createContext, useState, useContext, useEffect } from 'react'

type SavedConfig = {
  id: string
  name: string
  layout: string // JSON string representing the layout
}

type SavedConfigurationsContextType = {
  savedConfigs: SavedConfig[]
  addConfig: (name: string, layout: string) => void
  deleteConfig: (id: string) => void
  loadConfig: (id: string) => void
  resetToDefault: () => void
  currentConfig: SavedConfig | null
}

const SavedConfigurationsContext = createContext<SavedConfigurationsContextType | undefined>(undefined)

const defaultLayout = [
  { i: 'network-map', x: 0, y: 0, w: 6, h: 4, component: 'NetworkMap', title: 'Network Map' },
  { i: 'device-list', x: 6, y: 0, w: 6, h: 4, component: 'DeviceList', title: 'Device List' },
  { i: 'alert-panel', x: 0, y: 4, w: 6, h: 4, component: 'AlertPanel', title: 'Alerts' },
  { i: 'network-stats', x: 6, y: 4, w: 6, h: 4, component: 'NetworkStats', title: 'Network Statistics' },
]

export const SavedConfigurationsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [savedConfigs, setSavedConfigs] = useState<SavedConfig[]>([])
  const [currentConfig, setCurrentConfig] = useState<SavedConfig | null>(null)

  useEffect(() => {
    // Load saved configurations from localStorage on initial render
    const storedConfigs = localStorage.getItem('savedDashboardConfigs')
    if (storedConfigs) {
      setSavedConfigs(JSON.parse(storedConfigs))
    }
  }, [])

  const addConfig = (name: string, layout: string) => {
    const newConfig: SavedConfig = {
      id: Date.now().toString(),
      name,
      layout,
    }
    const updatedConfigs = [...savedConfigs, newConfig]
    setSavedConfigs(updatedConfigs)
    localStorage.setItem('savedDashboardConfigs', JSON.stringify(updatedConfigs))
  }

  const deleteConfig = (id: string) => {
    const updatedConfigs = savedConfigs.filter(config => config.id !== id)
    setSavedConfigs(updatedConfigs)
    localStorage.setItem('savedDashboardConfigs', JSON.stringify(updatedConfigs))
  }

  const loadConfig = (id: string) => {
    const config = savedConfigs.find(config => config.id === id)
    if (config) {
      setCurrentConfig(config)
    }
  }

  const resetToDefault = () => {
    const defaultConfig: SavedConfig = {
      id: 'default',
      name: 'Default',
      layout: JSON.stringify(defaultLayout),
    }
    setCurrentConfig(defaultConfig)
  }

  return (
    <SavedConfigurationsContext.Provider value={{ savedConfigs, addConfig, deleteConfig, loadConfig, resetToDefault, currentConfig }}>
      {children}
    </SavedConfigurationsContext.Provider>
  )
}

export const useSavedConfigurations = () => {
  const context = useContext(SavedConfigurationsContext)
  if (context === undefined) {
    throw new Error('useSavedConfigurations must be used within a SavedConfigurationsProvider')
  }
  return context
}

