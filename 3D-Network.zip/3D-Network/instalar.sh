#!/bin/bash

# Instala as dependências do projeto
npm install

# Executa o script de configuração do banco de dados
python scripts/setup_database.py

# Inicia o servidor de desenvolvimento
npm run dev