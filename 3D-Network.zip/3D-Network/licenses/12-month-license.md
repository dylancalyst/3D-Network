# Licença de 12 Meses do 3D Network Monitor

## Termos e Condições

1. **Concessão de Licença**: A Network Solutions Inc. ("Licenciante") concede ao usuário ("Licenciado") uma licença limitada, não exclusiva, intransferível e mundial para usar o software 3D Network Monitor ("Software") por um período de 12 (doze) meses a partir da data de ativação.

2. **Duração**: Esta licença é válida por 12 meses a partir da data de ativação. Após este período, o Licenciado deve renovar a licença para continuar usando o Software.

3. **Escopo de Uso**: Esta licença permite ao Licenciado instalar e utilizar o Software em até 10 dispositivos dentro de uma única organização.

4. **Atualizações e Suporte**: 
   - O Licenciado tem direito a todas as atualizações e novas versões do Software lançadas durante o período de 12 meses.
   - Suporte técnico prioritário é fornecido via email, portal de suporte online e telefone durante o período da licença.

5. **Restrições**: O Licenciado não pode:
   - Modificar, adaptar ou hackear o Software.
   - Reverter a engenharia, descompilar ou desmontar o Software.
   - Remover ou alterar quaisquer marcas ou avisos de propriedade do Software.
   - Transferir, sublicenciar, alugar ou vender o Software a terceiros.

6. **Propriedade**: O Software é propriedade do Licenciante e está protegido por leis de direitos autorais e tratados internacionais.

7. **Garantia Limitada**: O Licenciante garante que o Software funcionará substancialmente de acordo com a documentação durante o período da licença.

8. **Limitação de Responsabilidade**: Em nenhum caso o Licenciante será responsável por quaisquer danos consequenciais, incidentais, indiretos ou especiais decorrentes do uso ou da incapacidade de usar o Software.

9. **Rescisão**: Esta licença é efetiva até o término do período de 12 meses ou até ser rescindida. Seus direitos sob esta licença serão rescindidos automaticamente sem aviso prévio do Licenciante se você não cumprir qualquer termo desta licença.

10. **Renovação**: O Licenciado pode renovar a licença por períodos adicionais de 12 meses mediante pagamento da taxa de renovação vigente.

11. **Lei Aplicável**: Esta licença será regida e interpretada de acordo com as leis do Brasil.

Ao usar o Software, você concorda com os termos desta licença. Se você não concordar com estes termos, não use o Software.

© 2024 3D Network Inc. Desenvolvido por: Renilson S. Ferreira. Todos os direitos reservados.

