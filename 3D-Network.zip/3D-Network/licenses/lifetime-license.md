# Licença Vitalícia do 3D Network Monitor

## Termos e Condições

1. **Concessão de Licença**: A Network Solutions Inc. ("Licenciante") concede ao usuário ("Licenciado") uma licença perpétua, não exclusiva, intransferível e mundial para usar o software 3D Network Monitor ("Software") por tempo indeterminado.

2. **Escopo de Uso**: Esta licença permite ao Licenciado instalar e utilizar o Software em um número ilimitado de dispositivos dentro de uma única organização.

3. **Atualizações e Suporte**: 
   - O Licenciado tem direito a todas as atualizações e novas versões do Software lançadas durante a vida útil do produto.
   - Suporte técnico vitalício é fornecido via email e portal de suporte online.

4. **Restrições**: O Licenciado não pode:
   - Modificar, adaptar ou hackear o Software.
   - Reverter a engenharia, descompilar ou desmontar o Software.
   - Remover ou alterar quaisquer marcas ou avisos de propriedade do Software.
   - Transferir, sublicenciar, alugar ou vender o Software a terceiros.

5. **Propriedade**: O Software é propriedade do Licenciante e está protegido por leis de direitos autorais e tratados internacionais.

6. **Garantia Limitada**: O Licenciante garante que o Software funcionará substancialmente de acordo com a documentação por 90 dias após a aquisição.

7. **Limitação de Responsabilidade**: Em nenhum caso o Licenciante será responsável por quaisquer danos consequenciais, incidentais, indiretos ou especiais decorrentes do uso ou da incapacidade de usar o Software.

8. **Rescisão**: Esta licença é efetiva até ser rescindida. Seus direitos sob esta licença serão rescindidos automaticamente sem aviso prévio do Licenciante se você não cumprir qualquer termo desta licença.

9. **Lei Aplicável**: Esta licença será regida e interpretada de acordo com as leis do Brasil.

Ao usar o Software, você concorda com os termos desta licença. Se você não concordar com estes termos, não use o Software.

© 2024 3D Network Inc. Desenvolvido por: Renilson S. Ferreira. Todos os direitos reservados.

