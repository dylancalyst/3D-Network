// ... (previous imports)
import { detectAnomalies } from '../../utils/anomalyDetection'

// ... (previous code)

// Schedule job to check for anomalies every 5 minutes
scheduleJob('*/5 * * * *', async () => {
  try {
    const devices = await prisma.device.findMany({
      include: {
        stats: {
          orderBy: { timestamp: 'desc' },
          take: 10, // Get last 10 stats for each device
        }
      }
    })

    const deviceData = devices.flatMap(device => 
      device.stats.map(stat => ({
        id: device.id,
        cpuUsage: stat.cpuUsage,
        memoryUsage: stat.memoryUsage,
        diskUsage: stat.diskUsage,
        timestamp: stat.timestamp,
      }))
    )

    const anomalies = await detectAnomalies(deviceData)

    for (const anomaly of anomalies) {
      await prisma.alert.create({
        data: {
          deviceId: anomaly.deviceId,
          message: `Anomaly detected: ${anomaly.message}`,
          severity: 'high',
        }
      })
    }

    console.log('Anomaly detection completed')
  } catch (error) {
    console.error('Failed to check for anomalies:', error)
  }
})

// ... (rest of the code)

