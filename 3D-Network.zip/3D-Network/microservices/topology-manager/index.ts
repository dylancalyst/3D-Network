import express from 'express'
import { PrismaClient } from '@prisma/client'

const app = express()
const prisma = new PrismaClient()

app.use(express.json())

// Endpoint to get network topology
app.get('/topology', async (req, res) => {
  try {
    const links = await prisma.networkLink.findMany({
      include: {
        sourceDevice: true,
        targetDevice: true,
      }
    })
    res.json(links)
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch network topology' })
  }
})

// Endpoint to update a network link
app.put('/topology/:id', async (req, res) => {
  const { id } = req.params
  const { status, bandwidth } = req.body

  try {
    const updatedLink = await prisma.networkLink.update({
      where: { id },
      data: { status, bandwidth },
      include: {
        sourceDevice: true,
        targetDevice: true,
      }
    })
    res.json(updatedLink)
  } catch (error) {
    res.status(500).json({ error: 'Failed to update network link' })
  }
})

const PORT = process.env.TOPOLOGY_MANAGER_PORT || 3002
app.listen(PORT, () => {
  console.log(`Topology management microservice running on port ${PORT}`)
})

