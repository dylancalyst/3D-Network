import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { getToken } from 'next-auth/jwt'

export async function middleware(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET })

  if (!token) {
    if (req.nextUrl.pathname.startsWith('/api')) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    } else {
      const url = new URL(`/login`, req.url)

      // Append the current path as a query parameter so
      // the user can be redirected back after logging in
      url.searchParams.set('callbackUrl', req.url)
      return NextResponse.redirect(url)
    }
  }


  // Protect API routes with appropriate permissions
  if (req.nextUrl.pathname.startsWith('/api') && !token.permissions?.includes(`${req.nextUrl.pathname.replace(/^\/api/, '').replace(/\/$/, '')}:${req.method.toLowerCase()}`)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
  }


  // Check role-based access
  const adminPaths = ['/dashboard/admin', '/dashboard/admin/password-policies', '/dashboard/admin/network-settings', '/dashboard/admin/alert-thresholds', '/dashboard/admin/integrations', '/dashboard/admin/network-map', '/dashboard/admin/maintenance', '/dashboard/admin/security-audits', '/dashboard/admin/customize-dashboard', '/dashboard/admin/customize-network-map', '/dashboard/admin/system-status', '/dashboard/admin/network-diagnostics', '/dashboard/admin/performance-optimization']
  const operatorPaths = ['/dashboard/devices', '/dashboard/network-config', '/dashboard/alerts', '/dashboard/reports', '/dashboard/settings']
  const userPaths = ['/dashboard']

  let hasAccess = false
  switch (token.role) {
    case 'ADMIN':
      hasAccess = true // Admin has access to all paths
      break
    case 'OPERATOR':
      hasAccess = operatorPaths.some(path => req.nextUrl.pathname.startsWith(path))
      break
    case 'USER':
      hasAccess = userPaths.some(path => req.nextUrl.pathname.startsWith(path))
      break
  }

  if (!hasAccess) {
    return NextResponse.redirect(new URL('/dashboard', req.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'], // Match all routes except api routes and static files
}

