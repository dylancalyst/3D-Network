/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true, // Improves build performance [^vercel_knowledge_base]
  images: {
    unoptimized: true, // Only use if absolutely necessary for specific images [^vercel_knowledge_base]
  },
  // Add other performance optimizations like output: 'standalone' as needed [^vercel_knowledge_base]
}

module.exports = nextConfig

