import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'
import { backupToS3 } from '@/utils/cloudServices'
import fs from 'fs'
import path from 'path'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).end()
  }

  const { includeConfigurations, includeHistory, includeReports, storageLocation } = req.body

  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive'
  })

  try {
    // Fetch data based on options
    const data: any = {}

    if (includeConfigurations) {
      data.configurations = await prisma.networkSettings.findMany()
      res.write(`data: ${JSON.stringify({ progress: 25, message: 'Configurations backed up' })}\n\n`)
    }

    if (includeHistory) {
      data.devices = await prisma.device.findMany({ include: { stats: true } })
      data.networkLinks = await prisma.networkLink.findMany()
      res.write(`data: ${JSON.stringify({ progress: 50, message: 'History backed up' })}\n\n`)
    }

    if (includeReports) {
      data.reports = await prisma.report.findMany()
      res.write(`data: ${JSON.stringify({ progress: 75, message: 'Reports backed up' })}\n\n`)
    }

    const backupFileName = `backup-${new Date().toISOString()}.json`

    if (storageLocation === 'cloud') {
      await backupToS3(JSON.stringify(data), backupFileName)
    } else {
      const backupDir = path.join(process.cwd(), 'backups')
      if (!fs.existsSync(backupDir)) {
        fs.mkdirSync(backupDir)
      }
      fs.writeFileSync(path.join(backupDir, backupFileName), JSON.stringify(data))
    }

    res.write(`data: ${JSON.stringify({ progress: 100, message: 'Backup completed successfully' })}\n\n`)
  } catch (error) {
    console.error('Backup failed:', error)
    res.write(`data: ${JSON.stringify({ progress: 100, message: 'Backup failed: ' + (error as Error).message })}\n\n`)
  } finally {
    res.end()
  }
}

