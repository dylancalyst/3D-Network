import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    try {
      const { retentionPeriod } = req.body
      const cutoffDate = new Date()
      cutoffDate.setDate(cutoffDate.getDate() - retentionPeriod)

      // Remove dados antigos
      await prisma.deviceStat.deleteMany({
        where: {
          timestamp: {
            lt: cutoffDate
          }
        }
      })

      await prisma.systemLog.deleteMany({
        where: {
          timestamp: {
            lt: cutoffDate
          }
        }
      })

      res.status(200).json({ message: 'Limpeza de dados concluída com sucesso' })
    } catch (error) {
      res.status(500).json({ error: 'Falha na limpeza de dados' })
    }
  } else {
    res.status(405).end()
  }
}

