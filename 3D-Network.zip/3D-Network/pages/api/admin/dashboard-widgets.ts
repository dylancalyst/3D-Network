import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const widgets = await prisma.dashboardWidget.findMany({
        orderBy: { order: 'asc' },
      })
      res.status(200).json(widgets)
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch dashboard widgets' })
    }
  } else if (req.method === 'POST') {
    try {
      const updatedWidgets = req.body

      await prisma.$transaction(
        updatedWidgets.map((widget: any, index: number) =>
          prisma.dashboardWidget.update({
            where: { id: widget.id },
            data: { enabled: widget.enabled, order: index },
          })
        )
      )

      res.status(200).json({ message: 'Dashboard widgets updated successfully' })
    } catch (error) {
      res.status(500).json({ error: 'Failed to update dashboard widgets' })
    }
  } else {
    res.status(405).end()
  }
}

