import { NextApiRequest, NextApiResponse } from 'next'
import { exec } from 'child_process'
import { promisify } from 'util'

const execAsync = promisify(exec)

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    try {
      const { tool, target } = req.body

      let command: string
      switch (tool) {
        case 'ping':
          command = `ping -c 4 ${target}`
          break
        case 'traceroute':
          command = `traceroute ${target}`
          break
        case 'packet-capture':
          // This is a placeholder. In a real-world scenario, you'd use a proper
          // packet capture tool and limit the capture duration.
          command = `tcpdump -i any -c 100 host ${target}`
          break
        default:
          return res.status(400).json({ error: 'Invalid diagnostic tool' })
      }

      const { stdout, stderr } = await execAsync(command)
      res.status(200).json({ result: stdout || stderr })
    } catch (error) {
      res.status(500).json({ error: 'Failed to run network diagnostic' })
    }
  } else {
    res.status(405).end()
  }
}

