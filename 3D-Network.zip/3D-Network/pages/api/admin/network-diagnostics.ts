import { NextApiRequest, NextApiResponse } from 'next'
import { exec } from 'child_process'
import util from 'util'
import { authMiddleware } from '@/middleware/authMiddleware'

const execAsync = util.promisify(exec)

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    const { tool, target } = req.body

    if (!target) {
      return res.status(400).json({ error: 'Target is required' })
    }

    try {
      let result: string
      switch (tool) {
        case 'ping':
          result = await runPing(target)
          break
        case 'traceroute':
          result = await runTraceroute(target)
          break
        case 'nslookup':
          result = await runNslookup(target)
          break
        case 'portscan':
          result = await runPortscan(target)
          break
        default:
          return res.status(400).json({ error: 'Invalid diagnostic tool' })
      }

      res.status(200).json({ result })
    } catch (error) {
      console.error('Error during network diagnostics:', error)
      res.status(500).json({ error: 'Failed to perform network diagnostics' })
    }
  } else {
    res.status(405).end()
  }
}

async function runPing(target: string): Promise<string> {
  const { stdout } = await execAsync(`ping -c 4 ${target}`)
  return stdout
}

async function runTraceroute(target: string): Promise<string> {
  const { stdout } = await execAsync(`traceroute ${target}`)
  return stdout
}

async function runNslookup(target: string): Promise<string> {
  const { stdout } = await execAsync(`nslookup ${target}`)
  return stdout
}

async function runPortscan(target: string): Promise<string> {
  const { stdout } = await execAsync(`nmap -p- -T4 ${target}`)
  return stdout
}

export default authMiddleware(handler)

