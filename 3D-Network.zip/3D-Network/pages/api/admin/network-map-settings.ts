import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const settings = await prisma.networkMapSettings.findFirst()
      res.status(200).json(settings)
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch network map settings' })
    }
  } else if (req.method === 'POST') {
    try {
      const updatedSettings = req.body

      await prisma.networkMapSettings.upsert({
        where: { id: 1 },
        update: updatedSettings,
        create: updatedSettings,
      })

      res.status(200).json({ message: 'Network map settings updated successfully' })
    } catch (error) {
      res.status(500).json({ error: 'Failed to update network map settings' })
    }
  } else {
    res.status(405).end()
  }
}

