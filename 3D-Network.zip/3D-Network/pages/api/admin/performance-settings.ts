import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const settings = await prisma.performanceSettings.findFirst()
      res.status(200).json(settings)
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch performance settings' })
    }
  } else if (req.method === 'POST') {
    try {
      const { dataCollectionInterval, mapDetailLevel, enableDatabaseIndexing, maxConcurrentQueries } = req.body

      const updatedSettings = await prisma.performanceSettings.upsert({
        where: { id: 1 },
        update: {
          dataCollectionInterval,
          mapDetailLevel,
          enableDatabaseIndexing,
          maxConcurrentQueries,
        },
        create: {
          dataCollectionInterval,
          mapDetailLevel,
          enableDatabaseIndexing,
          maxConcurrentQueries,
        },
      })

      res.status(200).json(updatedSettings)
    } catch (error) {
      res.status(500).json({ error: 'Failed to update performance settings' })
    }
  } else {
    res.status(405).end()
  }
}

