import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'
import { exec } from 'child_process'
import { promisify } from 'util'

const execAsync = promisify(exec)
const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    try {
      const { serviceId } = req.body

      const service = await prisma.service.findUnique({
        where: { id: serviceId },
      })

      if (!service) {
        return res.status(404).json({ error: 'Service not found' })
      }

      // This is a placeholder. In a real-world scenario, you'd use a proper
      // service management system or systemd commands.
      await execAsync(`echo "Restarting ${service.name}"`)

      await prisma.service.update({
        where: { id: serviceId },
        data: { status: 'running', lastChecked: new Date() },
      })

      res.status(200).json({ message: 'Service restarted successfully' })
    } catch (error) {
      res.status(500).json({ error: 'Failed to restart service' })
    }
  } else {
    res.status(405).end()
  }
}

