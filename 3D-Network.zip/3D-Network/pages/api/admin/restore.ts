import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'
import formidable from 'formidable'
import fs from 'fs'

const prisma = new PrismaClient()

export const config = {
  api: {
    bodyParser: false,
  },
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).end()
  }

  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive'
  })

  const form = new formidable.IncomingForm()

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error('Error parsing form:', err)
      res.write(`data: ${JSON.stringify({ progress: 100, message: 'Restore failed: Error parsing form' })}\n\n`)
      return res.end()
    }

    const file = files.file as formidable.File
    const options = JSON.parse(fields.options as string)

    try {
      const backupData = JSON.parse(fs.readFileSync(file.filepath, 'utf8'))

      if (options.restoreType === 'full' || backupData.configurations) {
        await prisma.networkSettings.deleteMany()
        await prisma.networkSettings.createMany({ data: backupData.configurations })
        res.write(`data: ${JSON.stringify({ progress: 25, message: 'Configurations restored' })}\n\n`)
      }

      if (options.restoreType === 'full' || backupData.devices) {
        await prisma.deviceStat.deleteMany()
        await prisma.device.deleteMany()
        await prisma.device.createMany({ data: backupData.devices })
        for (const device of backupData.devices) {
          await prisma.deviceStat.createMany({ data: device.stats })
        }
        await prisma.networkLink.deleteMany()
        await prisma.networkLink.createMany({ data: backupData.networkLinks })
        res.write(`data: ${JSON.stringify({ progress: 50, message: 'Devices and network links restored' })}\n\n`)
      }

      if (options.restoreType === 'full' || backupData.reports) {
        await prisma.report.deleteMany()
        await prisma.report.createMany({ data: backupData.reports })
        res.write(`data: ${JSON.stringify({ progress: 75, message: 'Reports restored' })}\n\n`)
      }

      res.write(`data: ${JSON.stringify({ progress: 100, message: 'Restore completed successfully' })}\n\n`)
    } catch (error) {
      console.error('Restore failed:', error)
      res.write(`data: ${JSON.stringify({ progress: 100, message: 'Restore failed: ' + (error as Error).message })}\n\n`)
    } finally {
      res.end()
    }
  })
}

