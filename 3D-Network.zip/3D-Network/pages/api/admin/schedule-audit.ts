import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    try {
      const { nextAuditDate, auditFrequency } = req.body

      const scheduledAudit = await prisma.scheduledAudit.create({
        data: {
          nextAuditDate: new Date(nextAuditDate),
          frequency: auditFrequency,
        },
      })

      res.status(200).json(scheduledAudit)
    } catch (error) {
      res.status(500).json({ error: 'Failed to schedule audit' })
    }
  } else {
    res.status(405).end()
  }
}

