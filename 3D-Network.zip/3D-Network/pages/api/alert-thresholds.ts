import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const thresholds = await prisma.alertThresholds.findFirst()
      res.status(200).json(thresholds)
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch alert thresholds' })
    }
  } else if (req.method === 'POST') {
    try {
      const { cpuWarning, cpuCritical, memoryWarning, memoryCritical, diskWarning, diskCritical, bandwidthWarning, bandwidthCritical } = req.body
      const thresholds = await prisma.alertThresholds.upsert({
        where: { id: 1 },
        update: { cpuWarning, cpuCritical, memoryWarning, memoryCritical, diskWarning, diskCritical, bandwidthWarning, bandwidthCritical },
        create: { cpuWarning, cpuCritical, memoryWarning, memoryCritical, diskWarning, diskCritical, bandwidthWarning, bandwidthCritical },
      })
      res.status(200).json(thresholds)
    } catch (error) {
      res.status(500).json({ error: 'Failed to update alert thresholds' })
    }
  } else {
    res.status(405).end()
  }
}

