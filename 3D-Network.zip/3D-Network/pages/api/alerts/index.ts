import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const alerts = await prisma.alert.findMany()
      res.status(200).json(alerts)
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch alerts' })
    }
  } else if (req.method === 'POST') {
    try {
      const { name, metric, threshold, deviceId } = req.body
      const alert = await prisma.alert.create({
        data: { name, metric, threshold, deviceId }
      })
      res.status(201).json(alert)
    } catch (error) {
      res.status(500).json({ error: 'Failed to create alert' })
    }
  } else {
    res.status(405).end()
  }
}

