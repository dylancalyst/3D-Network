import { NextApiRequest, NextApiResponse } from 'next'
import { generateAuthenticationOptions } from '@simplewebauthn/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).end()
  }

  try {
    const user = await prisma.user.findUnique({
      where: { email: req.query.email as string },
    })

    if (!user) {
      return res.status(400).json({ error: 'User not found' })
    }

    const options = await generateAuthenticationOptions({
      rpID: new URL(process.env.NEXTAUTH_URL).hostname,
      allowCredentials: user.credentials.map(cred => ({
        id: cred.credentialID,
        type: 'public-key',
        transports: cred.transports,
      })),
      userVerification: 'preferred',
    })

    await prisma.userChallenge.create({
      data: {
        userId: user.id,
        challenge: options.challenge,
      },
    })

    res.json(options)
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: 'Failed to generate authentication options' })
  }
}

