import { PrismaClient } from '@prisma/client'
import { NextResponse } from 'next/server'
import { sign } from 'jsonwebtoken'

const prisma = new PrismaClient()

const SECRET_KEY = process.env.SECRET_KEY as string; //Make sure to set this in your environment variables

export async function POST(request: Request) {
  try {
    const { username, password } = await request.json()

    const user = await prisma.user.findUnique({ where: { email: username } })

    if (!user) {
      return NextResponse.json({ message: 'Invalid credentials' }, { status: 401 })
    }

    const isPasswordCorrect = await bcrypt.compare(password, user.password)

    if (!isPasswordCorrect) {
      return NextResponse.json({ message: 'Invalid credentials' }, { status: 401 })
    }

    const token = sign({ userId: user.id, email: user.email, role: user.role, permissions: user.permissions }, SECRET_KEY, { expiresIn: '1h' })
    return NextResponse.json({ token })
  } catch (error) {
    console.error("Error during login:", error)
    return NextResponse.json({ message: 'Server error' }, { status: 500 })
  }
}

