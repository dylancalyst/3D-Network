import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query

  if (req.method === 'GET') {
    try {
      const device = await prisma.device.findUnique({
        where: { id: String(id) },
      })

      if (!device) {
        return res.status(404).json({ error: 'Device not found' })
      }

      // Simulating additional data that might come from a real monitoring system
      const enhancedDevice = {
        ...device,
        uptime: '3 days, 7 hours',
        firmwareVersion: 'v2.1.3',
      }

      res.status(200).json(enhancedDevice)
    } catch (error) {
      console.error('Error fetching device details:', error)
      res.status(500).json({ error: 'Failed to fetch device details' })
    }
  } else {
    res.status(405).end()
  }
}

