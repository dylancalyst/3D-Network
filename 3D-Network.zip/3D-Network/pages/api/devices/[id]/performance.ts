import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query

  if (req.method === 'GET') {
    try {
      const performanceData = await prisma.devicePerformance.findMany({
        where: { deviceId: String(id) },
        orderBy: { timestamp: 'desc' },
        take: 100, // Last 100 data points
      })

      res.status(200).json(performanceData)
    } catch (error) {
      console.error('Error fetching device performance data:', error)
      res.status(500).json({ error: 'Failed to fetch device performance data' })
    }
  } else {
    res.status(405).end()
  }
}

