import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query

  if (req.method === 'POST') {
    try {
      // In a real-world scenario, you would send a reboot command to the actual device here
      // For this example, we'll just update the device status in the database
      await prisma.device.update({
        where: { id: String(id) },
        data: { status: 'rebooting' },
      })

      res.status(200).json({ message: 'Device reboot initiated' })
    } catch (error) {
      console.error('Error rebooting device:', error)
      res.status(500).json({ error: 'Failed to reboot device' })
    }
  } else {
    res.status(405).end()
  }
}

