import { NextApiRequest, NextApiResponse } from 'next'
import axios from 'axios'

const DEVICE_MONITOR_URL = process.env.DEVICE_MONITOR_URL || 'http://localhost:3001'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const response = await axios.get(`${DEVICE_MONITOR_URL}/devices`)
      res.status(200).json(response.data)
    } catch (error) {
      console.error('Failed to fetch devices:', error)
      res.status(500).json({ error: 'Failed to fetch devices' })
    }
  } else {
    res.status(405).end()
  }
}

