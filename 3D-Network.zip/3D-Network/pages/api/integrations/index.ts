import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const integrations = await prisma.integration.findMany()
      res.status(200).json(integrations)
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch integrations' })
    }
  } else if (req.method === 'POST') {
    try {
      const { name, type, url, apiKey } = req.body
      const integration = await prisma.integration.create({
        data: { name, type, url, apiKey, isActive: true },
      })
      res.status(201).json(integration)
    } catch (error) {
      res.status(500).json({ error: 'Failed to create integration' })
    }
  } else {
    res.status(405).end()
  }
}

