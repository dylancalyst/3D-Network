import { NextApiRequest, NextApiResponse } from 'next'
import { exec } from 'child_process'
import util from 'util'

const execPromise = util.promisify(exec)

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    const { target } = req.body

    if (!target) {
      return res.status(400).json({ error: 'Target is required' })
    }

    try {
      const results = await Promise.all([
        runPing(target),
        runTraceroute(target),
        checkOpenPorts(target),
      ])

      res.status(200).json(results)
    } catch (error) {
      console.error('Error during network diagnostics:', error)
      res.status(500).json({ error: 'Failed to perform network diagnostics' })
    }
  } else {
    res.status(405).end()
  }
}

async function runPing(target: string) {
  try {
    const { stdout } = await execPromise(`ping -c 4 ${target}`)
    return {
      type: 'Ping',
      status: 'success',
      message: 'Ping successful',
      details: stdout,
    }
  } catch (error) {
    return {
      type: 'Ping',
      status: 'error',
      message: 'Ping failed',
      details: error.message,
    }
  }
}

async function runTraceroute(target: string) {
  try {
    const { stdout } = await execPromise(`traceroute ${target}`)
    return {
      type: 'Traceroute',
      status: 'success',
      message: 'Traceroute completed',
      details: stdout,
    }
  } catch (error) {
    return {
      type: 'Traceroute',
      status: 'error',
      message: 'Traceroute failed',
      details: error.message,
    }
  }
}

async function checkOpenPorts(target: string) {
  const portsToCheck = [22, 80, 443, 3389] // SSH, HTTP, HTTPS, RDP
  const results = await Promise.all(
    portsToCheck.map(async (port) => {
      try {
        await execPromise(`nc -z -w 5 ${target} ${port}`)
        return `${port}: open`
      } catch (error) {
        return `${port}: closed`
      }
    })
  )

  return {
    type: 'Port Scan',
    status: 'success',
    message: 'Port scan completed',
    details: results.join('\n'),
  }
}

