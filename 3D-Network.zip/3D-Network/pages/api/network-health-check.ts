import { NextApiRequest, NextApiResponse } from 'next'
import net from 'net'
import ping from 'ping'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const internetAccess = await checkInternetAccess()
      const snmpPort = await checkPort(161)
      const icmpPort = await checkICMP()
      const customPorts = {
        '443': await checkPort(443), // HTTPS
        '22': await checkPort(22),   // SSH
        // Add more custom ports as needed
      }

      res.status(200).json({
        internetAccess,
        snmpPort,
        icmpPort,
        customPorts,
      })
    } catch (error) {
      console.error('Error during network health check:', error)
      res.status(500).json({ error: 'Failed to perform network health check' })
    }
  } else {
    res.status(405).end()
  }
}

async function checkInternetAccess(): Promise<boolean> {
  try {
    const result = await ping.promise.probe('8.8.8.8', {
      timeout: 5,
    })
    return result.alive
  } catch (error) {
    console.error('Error checking internet access:', error)
    return false
  }
}

async function checkPort(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const socket = new net.Socket()
    socket.setTimeout(5000)
    socket.on('connect', () => {
      socket.destroy()
      resolve(true)
    })
    socket.on('timeout', () => {
      socket.destroy()
      resolve(false)
    })
    socket.on('error', () => {
      resolve(false)
    })
    socket.connect(port, 'localhost')
  })
}

async function checkICMP(): Promise<boolean> {
  try {
    const result = await ping.promise.probe('localhost', {
      timeout: 5,
    })
    return result.alive
  } catch (error) {
    console.error('Error checking ICMP:', error)
    return false
  }
}

