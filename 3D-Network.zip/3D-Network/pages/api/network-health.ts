import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      // In a real-world scenario, you would aggregate this data from your devices
      // This is a simplified example
      const devices = await prisma.device.findMany()
      
      const cpuUsage = devices.reduce((sum, device) => sum + device.cpuUsage, 0) / devices.length
      const memoryUsage = devices.reduce((sum, device) => sum + device.memoryUsage, 0) / devices.length
      const diskUsage = devices.reduce((sum, device) => sum + device.diskUsage, 0) / devices.length
      
      // Simulating network usage and other metrics
      const networkUsage = Math.random() * 100
      const activeConnections = Math.floor(Math.random() * 1000)
      const latency = Math.floor(Math.random() * 100)

      let overall: 'good' | 'warning' | 'critical' = 'good'
      if (cpuUsage > 90 || memoryUsage > 90 || diskUsage > 90 || networkUsage > 90) {
        overall = 'critical'
      } else if (cpuUsage > 70 || memoryUsage > 70 || diskUsage > 70 || networkUsage > 70) {
        overall = 'warning'
      }

      const healthStatus = {
        overall,
        cpu: Math.round(cpuUsage),
        memory: Math.round(memoryUsage),
        disk: Math.round(diskUsage),
        network: Math.round(networkUsage),
        activeConnections,
        latency
      }

      res.status(200).json(healthStatus)
    } catch (error) {
      console.error('Error fetching network health:', error)
      res.status(500).json({ error: 'Failed to fetch network health status' })
    }
  } else {
    res.status(405).end()
  }
}

