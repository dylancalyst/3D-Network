import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const predictions = await prisma.networkPrediction.findMany({
        include: {
          device: {
            select: {
              name: true,
            },
          },
        },
        orderBy: {
          timestamp: 'desc',
        },
        take: 10,
      })

      const formattedPredictions = predictions.map((prediction) => ({
        id: prediction.id,
        deviceId: prediction.deviceId,
        deviceName: prediction.device.name,
        metric: prediction.metric,
        currentValue: prediction.currentValue,
        predictedValue: prediction.predictedValue,
        timestamp: prediction.timestamp.toISOString(),
        confidence: prediction.confidence,
      }))

      res.status(200).json(formattedPredictions)
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch network predictions' })
    }
  } else {
    res.status(405).end()
  }
}

