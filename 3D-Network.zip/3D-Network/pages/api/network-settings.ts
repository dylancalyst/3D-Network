import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'
import { exec } from 'child_process'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    try {
      const { serverIp, subnetMask } = req.body
      const settings = await prisma.networkSettings.upsert({
        where: { id: 1 },
        update: { serverIp, subnetMask },
        create: { serverIp, subnetMask },
      })

      // Restart network services (this is a placeholder - implement according to your system)
      exec('sudo systemctl restart networking', (error, stdout, stderr) => {
        if (error) {
          console.error(`exec error: ${error}`)
          return res.status(500).json({ error: 'Failed to restart network services' })
        }
        res.status(200).json(settings)
      })
    } catch (error) {
      res.status(500).json({ error: 'Failed to update network settings' })
    }
  } else if (req.method === 'GET') {
    try {
      const settings = await prisma.networkSettings.findFirst()
      res.status(200).json(settings)
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch network settings' })
    }
  } else {
    res.status(405).end()
  }
}

