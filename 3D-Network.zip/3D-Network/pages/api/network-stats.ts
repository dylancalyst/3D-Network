import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const stats = await prisma.networkStat.findMany({
        orderBy: {
          timestamp: 'desc'
        },
        take: 24 // Last 24 data points
      })

      const formattedStats = stats.map(stat => ({
        timestamp: stat.timestamp.toISOString(),
        bandwidth: stat.bandwidth
      }))

      res.status(200).json(formattedStats.reverse()) // Reverse to get chronological order
    } catch (error) {
      console.error('Failed to fetch network stats:', error)
      res.status(500).json({ error: 'Failed to fetch network stats' })
    }
  } else {
    res.status(405).end()
  }
}

