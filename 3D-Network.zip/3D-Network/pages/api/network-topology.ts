import { NextApiRequest, NextApiResponse } from 'next'
import { detectTopology } from '@/services/topologyDetection'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const networkRange = process.env.NETWORK_RANGE || '192.168.1.0/24'
      const { devices, links } = await detectTopology(networkRange)

      const nodes = devices.map((device: any) => ({
        id: device.ip,
        name: device.hostname || device.ip,
        type: device.type,
      }))

      const edges = links.map((link: any) => ({
        source: link.source,
        target: link.target,
      }))

      res.status(200).json({ nodes, links: edges })
    } catch (error) {
      console.error('Error detecting network topology:', error)
      res.status(500).json({ error: 'Failed to detect network topology' })
    }
  } else {
    res.status(405).end()
  }
}

