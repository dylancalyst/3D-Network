import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    try {
      const { minLength, requireUppercase, requireLowercase, requireNumbers, requireSpecialChars, expirationDays } = req.body
      const policy = await prisma.passwordPolicy.upsert({
        where: { id: 1 },
        update: { minLength, requireUppercase, requireLowercase, requireNumbers, requireSpecialChars, expirationDays },
        create: { minLength, requireUppercase, requireLowercase, requireNumbers, requireSpecialChars, expirationDays },
      })
      res.status(200).json(policy)
    } catch (error) {
      res.status(500).json({ error: 'Failed to update password policy' })
    }
  } else if (req.method === 'GET') {
    try {
      const policy = await prisma.passwordPolicy.findFirst()
      res.status(200).json(policy)
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch password policy' })
    }
  } else {
    res.status(405).end()
  }
}

