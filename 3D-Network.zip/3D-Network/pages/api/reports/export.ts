import { NextApiRequest, NextApiResponse } from 'next'
import { authMiddleware } from '@/middleware/authMiddleware'
import { PrismaClient } from '@prisma/client'
import PDFDocument from 'pdfkit'

const prisma = new PrismaClient()

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    const { type } = req.query

    if (!type) {
      return res.status(400).json({ error: 'Report type is required' })
    }

    try {
      const doc = new PDFDocument()
      res.setHeader('Content-Type', 'application/pdf')
      res.setHeader('Content-Disposition', `attachment; filename=${type}-report.pdf`)

      doc.pipe(res)

      doc.fontSize(25).text(`Relatório: ${type}`, 100, 80)

      switch (type) {
        case 'network-status':
          await generateNetworkStatusReport(doc)
          break
        case 'device-inventory':
          await generateDeviceInventoryReport(doc)
          break
        case 'alert-history':
          await generateAlertHistoryReport(doc)
          break
        default:
          throw new Error('Invalid report type')
      }

      doc.end()
    } catch (error) {
      console.error('Error generating report:', error)
      res.status(500).json({ error: 'Failed to generate report' })
    }
  } else {
    res.status(405).end()
  }
}

async function generateNetworkStatusReport(doc: PDFKit.PDFDocument) {
  const devices = await prisma.device.findMany()
  doc.fontSize(14).text('Status dos Dispositivos:', 100, 120)
  devices.forEach((device, index) => {
    doc.fontSize(12).text(`${device.name}: ${device.status}`, 120, 150 + index * 20)
  })
}

async function generateDeviceInventoryReport(doc: PDFKit.PDFDocument) {
  const devices = await prisma.device.findMany()
  doc.fontSize(14).text('Inventário de Dispositivos:', 100, 120)
  devices.forEach((device, index) => {
    doc.fontSize(12).text(`${device.name} (${device.type}) - IP: ${device.ip}`, 120, 150 + index * 20)
  })
}

async function generateAlertHistoryReport(doc: PDFKit.PDFDocument) {
  const alerts = await prisma.alert.findMany({ orderBy: { createdAt: 'desc' }, take: 20 })
  doc.fontSize(14).text('Histórico de Alertas (últimos 20):', 100, 120)
  alerts.forEach((alert, index) => {
    doc.fontSize(12).text(`${alert.createdAt.toLocaleString()}: ${alert.message}`, 120, 150 + index * 20)
  })
}

export default authMiddleware(handler)

