import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query

  if (req.method === 'PUT') {
    try {
      const { name, description, enabled, config } = req.body
      const policy = await prisma.securityPolicy.update({
        where: { id: String(id) },
        data: { name, description, enabled, config },
      })
      res.status(200).json(policy)
    } catch (error) {
      res.status(500).json({ error: 'Failed to update security policy' })
    }
  } else if (req.method === 'DELETE') {
    try {
      await prisma.securityPolicy.delete({ where: { id: String(id) } })
      res.status(204).end()
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete security policy' })
    }
  } else {
    res.status(405).end()
  }
}

