import { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'
import { hash } from 'bcryptjs'

const prisma = new PrismaClient()

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const users = await prisma.user.findMany({
        select: { id: true, name: true, email: true, role: true, permissions: true, twoFactorEnabled: true }
      })
      res.status(200).json(users)
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch users' })
    }
  } else if (req.method === 'POST') {
    try {
      const { name, email, role, permissions, twoFactorEnabled } = req.body
      const hashedPassword = await hash('defaultPassword', 10) // You should implement a proper password generation/email system
      const user = await prisma.user.create({
        data: { name, email, password: hashedPassword, role, permissions, twoFactorEnabled }
      })
      res.status(201).json(user)
    } catch (error) {
      res.status(500).json({ error: 'Failed to create user' })
    }
  } else {
    res.status(405).end()
  }
}

