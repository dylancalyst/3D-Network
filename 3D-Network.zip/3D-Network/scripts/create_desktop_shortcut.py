import os
import sys
import platform
import shutil

def create_windows_shortcut():
    import winshell
    from win32com.client import Dispatch

    desktop = winshell.desktop()
    path = os.path.join(desktop, "3D Network Monitor.lnk")
    target = "http://localhost:3000"  # Adjust this URL if needed

    icon_path = os.path.join(os.getcwd(), "public", "3d_network_monitor_icon.ico")
    if not os.path.exists(icon_path):
        print("Warning: Icon file not found. Using default icon.")
        icon_path = ""

    shell = Dispatch('WScript.Shell')
    shortcut = shell.CreateShortCut(path)
    shortcut.Targetpath = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
    shortcut.Arguments = target
    shortcut.IconLocation = icon_path
    shortcut.save()

def create_linux_shortcut():
    home = os.path.expanduser("~")
    desktop = os.path.join(home, "Desktop")
    shortcut_path = os.path.join(desktop, "3D Network Monitor.desktop")

    icon_path = os.path.join(os.getcwd(), "public", "3d_network_monitor_icon.png")
    if not os.path.exists(icon_path):
        print("Warning: Icon file not found. Using default icon.")
        icon_path = ""

    shortcut_content = f"""[Desktop Entry]
Version=1.0
Type=Application
Name=3D Network Monitor
Comment=Open 3D Network Monitor in web browser
Exec=xdg-open http://localhost:3000
Icon={icon_path}
Terminal=false
StartupNotify=false
"""

    with open(shortcut_path, 'w') as f:
        f.write(shortcut_content)

    os.chmod(shortcut_path, 0o755)

def copy_icon_files():
    source_dir = os.path.join(os.getcwd(), "public")
    icon_files = ["3d_network_monitor_icon.ico", "3d_network_monitor_icon.png"]
    
    for icon_file in icon_files:
        source_path = os.path.join(source_dir, icon_file)
        if os.path.exists(source_path):
            shutil.copy(source_path, os.getcwd())
            print(f"Copied {icon_file} to the current directory.")
        else:
            print(f"Warning: {icon_file} not found in the public directory.")

def main():
    system = platform.system()
    
    copy_icon_files()
    
    if system == "Windows":
        create_windows_shortcut()
        print("Desktop shortcut created successfully for Windows.")
    elif system == "Linux":
        create_linux_shortcut()
        print("Desktop shortcut created successfully for Linux.")
    else:
        print(f"Unsupported operating system: {system}")
        sys.exit(1)

if __name__ == "__main__":
    main()

