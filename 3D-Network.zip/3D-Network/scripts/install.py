import os
import sys
import subprocess
import getpass
import secrets
from sqlalchemy import create_engine, text
import time

# ... (previous code remains unchanged)

def create_desktop_shortcut():
    print("\nCriando atalho na área de trabalho...")
    run_command("python scripts/create_desktop_shortcut.py")

def main():
    print("Bem-vindo à instalação do 3D Network Monitor!")

    # Instalar dependências
    install_dependencies()

    # Configurar banco de dados
    db_name = input("Digite o nome do banco de dados (padrão: networkmonitor3d): ") or "networkmonitor3d"
    username = input("Digite o nome de usuário para o banco de dados: ")
    password = getpass.getpass("Digite a senha para o banco de dados: ")

    if not create_database(db_name, username, password):
        print("A instalação não pode continuar devido a erros na criação do banco de dados.")
        sys.exit(1)

    # Gerar chave secreta e atualizar .env
    secret_key = generate_secret_key()
    update_env_file(db_name, username, password, secret_key)

    # Executar migrações
    run_migrations()

    # Criar superusuário
    create_superuser()

    # Create desktop shortcut
    create_desktop_shortcut()

    print("\nInstalação concluída com sucesso!")
    print("Você pode iniciar o servidor executando: python manage.py runserver")
    print("Ou clique no ícone '3D Network Monitor' na sua área de trabalho para abrir o sistema no navegador.")

if __name__ == "__main__":
    main()

