import { PrismaClient } from '@prisma/client'
import { hash } from 'bcrypt'

const prisma = new PrismaClient()

async function main() {
  console.log('Starting database setup...')

  // Create admin user
  const adminPassword = await hash('admin123', 10)
  const admin = await prisma.user.upsert({
    where: { email: 'admin@example.com' },
    update: {},
    create: {
      email: 'admin@example.com',
      name: 'Admin User',
      password: adminPassword,
      role: 'ADMIN',
    },
  })
  console.log('Admin user created:', admin.email)

  // Create some sample devices
  const devices = [
    { name: 'Router 1', type: 'ROUTER', ip: '192.168.1.1', status: 'ONLINE' },
    { name: 'Switch 1', type: 'SWITCH', ip: '192.168.1.2', status: 'ONLINE' },
    { name: 'Server 1', type: 'SERVER', ip: '192.168.1.10', status: 'ONLINE' },
    { name: 'Workstation 1', type: 'WORKSTATION', ip: '192.168.1.100', status: 'OFFLINE' },
  ]

  for (const device of devices) {
    const createdDevice = await prisma.device.upsert({
      where: { ip: device.ip },
      update: {},
      create: {
        ...device,
        lastSeen: new Date(),
        cpuUsage: Math.random() * 100,
        memoryUsage: Math.random() * 100,
        diskUsage: Math.random() * 100,
      },
    })
    console.log('Device created:', createdDevice.name)

    // Create some sample performance data for each device
    for (let i = 0; i < 10; i++) {
      await prisma.devicePerformance.create({
        data: {
          deviceId: createdDevice.id,
          timestamp: new Date(Date.now() - i * 60000), // Every minute for the last 10 minutes
          cpuUsage: Math.random() * 100,
          memoryUsage: Math.random() * 100,
          diskUsage: Math.random() * 100,
        },
      })
    }
    console.log('Performance data created for:', createdDevice.name)
  }

  console.log('Database setup completed successfully!')
}

main()
  .catch((e) => {
    console.error('Error setting up database:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })

