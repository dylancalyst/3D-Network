import os
import secrets
import subprocess
import getpass
from sqlalchemy import create_engine, text

def generate_secret_key():
    return secrets.token_hex(32)

def create_database(db_name, username, password):
    # Connect to PostgreSQL
    engine = create_engine(f'postgresql://{username}:{password}@localhost/postgres')
    
    with engine.connect() as conn:
        conn.execute(text("COMMIT"))
        # Create database
        conn.execute(text(f"CREATE DATABASE {db_name}"))
        
        # Create user and grant privileges
        conn.execute(text(f"CREATE USER {username} WITH ENCRYPTED PASSWORD '{password}'"))
        conn.execute(text(f"GRANT ALL PRIVILEGES ON DATABASE {db_name} TO {username}"))

def update_env_file(db_name, username, password, secret_key):
    env_content = f"""
DATABASE_URL=postgresql://{username}:{password}@localhost/{db_name}
SECRET_KEY={secret_key}
"""
    with open('.env', 'w') as f:
        f.write(env_content)

def main():
    print("Bem-vindo à configuração do banco de dados do 3D Network Monitor!")
    
    db_name = input("Digite o nome do banco de dados (padrão: networkmonitor3d): ") or "networkmonitor3d"
    username = input("Digite o nome de usuário para o banco de dados: ")
    password = getpass.getpass("Digite a senha para o banco de dados: ")
    
    secret_key = generate_secret_key()
    
    try:
        create_database(db_name, username, password)
        update_env_file(db_name, username, password, secret_key)
        print("Banco de dados criado com sucesso!")
        print("Arquivo .env atualizado com as configurações.")
    except Exception as e:
        print(f"Erro ao criar o banco de dados: {e}")
        return

    # Run database migrations
    try:
        subprocess.run(["python", "manage.py", "migrate"], check=True)
        print("Migrações do banco de dados aplicadas com sucesso!")
    except subprocess.CalledProcessError:
        print("Erro ao aplicar as migrações do banco de dados.")

if __name__ == "__main__":
    main()

