import { PrismaClient } from '@prisma/client'
import nodemailer from 'nodemailer'

const prisma = new PrismaClient()

const transporter = nodemailer.createTransport({
  host: 'smtp.example.com',
  port: 587,
  secure: false,
  auth: {
    user: 'your-email@example.com',
    pass: 'your-password'
  }
})

export async function checkAlerts() {
  const devices = await prisma.device.findMany({
    include: { alerts: true }
  })

  for (const device of devices) {
    for (const alert of device.alerts) {
      if (isAlertTriggered(device, alert)) {
        await createAlertLog(device.id, alert.id)
        await sendAlertNotification(device, alert)
      }
    }
  }
}

function isAlertTriggered(device: any, alert: any): boolean {
  switch (alert.metric) {
    case 'cpuLoad':
      return device.cpuLoad > alert.threshold
    case 'memoryUsed':
      return device.memoryUsed > alert.threshold
    case 'status':
      return device.status === 'offline'
    default:
      return false
  }
}

async function createAlertLog(deviceId: string, alertId: string) {
  await prisma.alertLog.create({
    data: {
      deviceId,
      alertId,
      timestamp: new Date()
    }
  })
}

async function sendAlertNotification(device: any, alert: any) {
  const mailOptions = {
    from: 'your-email@example.com',
    to: 'admin@example.com',
    subject: `Alert: ${alert.name} for device ${device.name}`,
    text: `The ${alert.metric} for device ${device.name} (${device.ip}) has exceeded the threshold of ${alert.threshold}.`
  }

  try {
    await transporter.sendMail(mailOptions)
    console.log(`Alert notification sent for device ${device.name}`)
  } catch (error) {
    console.error('Error sending alert notification:', error)
  }
}

// Run alert checks every 5 minutes
setInterval(checkAlerts, 5 * 60 * 1000)

