import nmap from 'node-nmap'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function detectTopology(networkRange: string) {
  const devices = await scanNetwork(networkRange)
  const links = await detectLinks(devices)

  await saveTopology(devices, links)

  return { devices, links }
}

async function scanNetwork(networkRange: string): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const scan = new nmap.NmapScan(networkRange, '-sn -T4') // Increased speed with -T4

    scan.on('complete', (results) => {
      resolve(results)
    })

    scan.on('error', (error) => {
      reject(new Error(`Network scan failed: ${error}`)) //Improved error handling
    })

    scan.startScan()
  })
}

async function detectLinks(devices: any[]): Promise<any[]> {
  const links: any[] = []
  const deviceIps = devices.map(device => device.ip);

  for (const device of devices) {
    //Avoid redundant scans by checking if already scanned
    if(device.connectedIps){
        device.connectedIps.forEach((ip: string) => {
          const targetDevice = devices.find(d => d.ip === ip)
          if (targetDevice) {
            links.push({ source: device.ip, target: ip })
          }
        })
        continue;
    }

    const scan = new nmap.NmapScan(device.ip, '-sn -O -T4') //Increased speed with -T4

    try{
        const results = await new Promise((resolve, reject) => {
            scan.on('complete', (results) => {
              resolve(results)
            })
            scan.on('error', (error) => {
              console.error(`Error detecting links for device ${device.ip}:`, error)
              resolve([]) //Resolve with empty array on error
            })
            scan.startScan()
        })
        const connectedIps = results[0]?.connectedIps || []
        connectedIps.forEach((ip: string) => {
          const targetDevice = devices.find(d => d.ip === ip)
          if (targetDevice) {
            links.push({ source: device.ip, target: ip })
          }
        })
        devices.find(d => d.ip === device.ip).connectedIps = connectedIps; //Store connected ips for later use
    } catch(error){
        console.error(`Error detecting links for device ${device.ip}:`, error)
    }
  }

  return links
}

async function saveTopology(devices: any[], links: any[]) {
  for (const device of devices) {
    await prisma.device.upsert({
      where: { ip: device.ip },
      update: { name: device.hostname, type: detectDeviceType(device) },
      create: { ip: device.ip, name: device.hostname, type: detectDeviceType(device) },
    })
  }

  for (const link of links) {
    const sourceDevice = await prisma.device.findUnique({ where: { ip: link.source } })
    const targetDevice = await prisma.device.findUnique({ where: { ip: link.target } })

    if (sourceDevice && targetDevice) {
      await prisma.networkLink.upsert({
        where: {
          sourceDeviceId_targetDeviceId: {
            sourceDeviceId: sourceDevice.id,
            targetDeviceId: targetDevice.id,
          },
        },
        update: {},
        create: {
          sourceDeviceId: sourceDevice.id,
          targetDeviceId: targetDevice.id,
          type: 'ethernet',
          status: 'active',
        },
      })
    }
  }
}

function detectDeviceType(device: any): string {
  // Improved device type detection using additional nmap data
  if (device.os && device.os.name) {
    if (device.os.name.toLowerCase().includes('cisco')) {
      return 'router';
    } else if (device.os.name.toLowerCase().includes('linux')) {
      return 'linux-server';
    } else if (device.os.name.toLowerCase().includes('windows')) {
      return 'windows-server';
    }
  }
  if (device.openPorts.includes(80) || device.openPorts.includes(443)) {
    return 'web-server';
  }
  return 'unknown';
}

