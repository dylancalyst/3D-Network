export interface Device {
 id: string
 name: string
 status: string
 ip: string
 lastCheckin: string
 cpuUsage: number
 memoryUsage: number
 diskUsage: number
}

export interface DeviceDetails {
 id: string
 name: string
 type: string
 ip: string
 status: string
 lastSeen: string
 cpuUsage: number
 memoryUsage: number
 diskUsage: number
 uptime: string
 firmwareVersion: string
}

