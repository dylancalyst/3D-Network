import { processDataWithLambda } from './cloudServices'

interface DeviceData {
  id: string
  cpuUsage: number
  memoryUsage: number
  diskUsage: number
  timestamp: Date
}

export async function detectAnomalies(deviceData: DeviceData[]) {
  try {
    const result = await processDataWithLambda({
      action: 'detectAnomalies',
      data: deviceData,
    })

    return result.anomalies
  } catch (error) {
    console.error('Anomaly detection failed:', error)
    return []
  }
}

