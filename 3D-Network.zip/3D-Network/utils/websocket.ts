import { io, Socket } from 'socket.io-client'

let socket: Socket | null = null

export const initializeWebSocket = (): Socket => {
 if (!socket) {
   socket = io(process.env.NEXT_PUBLIC_WEBSOCKET_URL || 'http://localhost:3001', {
     // Include JWT with the connection if available
     auth: {
       token: localStorage.getItem('token') || null
     }
   });

   socket.on('connect', () => {
     console.log('WebSocket connected')
   })

   socket.on('disconnect', () => {
     console.log('WebSocket disconnected')
   })

   socket.on('connect_error', (err) => {
     console.error('WebSocket connection error:', err)
     if (err.message === 'Invalid credentials') {
       // Handle invalid token, e.g., by redirecting to login
     }
   });
 }
 return socket as Socket
}

export const getSocket = (): Socket => {
 if (!socket) {
   throw new Error('WebSocket not initialized')
 }
 return socket
}

